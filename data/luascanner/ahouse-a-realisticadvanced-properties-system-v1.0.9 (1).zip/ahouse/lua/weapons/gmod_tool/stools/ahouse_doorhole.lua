
TOOL.Category = "AHouse"
TOOL.Name = "Door Hole"
TOOL.Command = nil
TOOL.ConfigName = "" --Setting this means that you do not have to create external configuration files to define the layout of the tool config-hud

function TOOL:LeftClick( trace )
	if ( !trace.Entity || !ahouse.HouseData.IsDoor(trace.Entity) ) then return false end

	if ( CLIENT ) then return true end

	local e = trace.Entity

	if e.ahouse_doorhole then
		ahouse.doorsHoles.RemoveDoor(e)
	else
		ahouse.doorsHoles.AddDoor(e, self:GetOwner():GetPos())
	end

	return true
end

function TOOL:RightClick( trace )
end

if CLIENT then
    language.Add("Tool.ahouse_doorhole.name", TOOL.Name)
    language.Add("Tool.ahouse_doorhole.desc", "Add/Remove a door hole to any door on your map")
    language.Add("Tool.ahouse_doorhole.0", "Left click: Add/Remove a door hole")

	function TOOL.BuildCPanel( CPanel )
		CPanel:AddControl( "Header", { Description = "#tool.ahouse_doorhole.desc" } )
	end
end