AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/sterling/akulla_receiptprinter.mdl")
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:DropToFloor()
	self.count = 0
end

function ENT:PrintContract(creator, target, houseid, rent, rent_days, commissionPrice)
	if self.printing then
		ahouse.Notify(creator, "printer_already", 1)
		return
	end

	if self.count >= 3 then
		ahouse.Notify(creator, "printer_toomuch", 1)
		return
	end

	hook.Run("ahouse_printer", creator)

	self.printing = true
	self.count = self.count + 1

	self:EmitSound( "akulla/ahouse/printer.wav", 65)

	timer.Simple(1, function()
		self.printing = false
		self.count = self.count - 1
		if !IsValid(self) or !IsValid(creator) or
			!IsValid(target) then return end

		local e = ents.Create("ahouse_paper")
		e:SetPos(self:GetPos() + Vector(0, 0, self:OBBMaxs().y*1.5))
		e:SetAngles(self:GetAngles())

		e.rent = rent
		e.houseid = houseid
		e.target = target
		e.seller = creator
		e.rent_days = rent_days
		e.commissionPrice = commissionPrice or 0

		function e:OnRemove()
			if IsValid(self) then
				self.count = self.count - 1
			end
		end

		timer.Simple(90, function()
			if IsValid(e) then
				e:Remove()
			end
		end)

		e:Spawn()
	end)
end

ahouse.SafeNet("printer", function(ply)
	local e = net.ReadEntity()

	if IsValid(e.target) and IsValid(e) and ply == e.target and e:GetClass() == "ahouse_paper" then
		local refuse = net.ReadBool()

		if refuse then
			e:Remove()
			return
		end

		if ahouse.HouseData.Buy(e.target, e.houseid, e.rent, e.rent_days, nil, e.commissionPrice) then
			if !IsValid(e.seller) then e:Remove() return end

			e.seller:addMoney(e.commissionPrice)
			e:Remove()
		end

	end
end, 0.1)