include("shared.lua")

ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

local angles = Angle(0, 90, 0)

function ENT:Draw(f)
    //self:DrawModel(f)
end

local w, h = 400, 240
local paint = ahouse.UI.Background(nil, w, h, 30)
local margin = h*0.07

local function display_coowners(t)
    local firstDoor = ahouse.HouseData.FirstSafeDoor(t.houseid)

    if !IsValid(firstDoor) then return end

    if player.GetCount() <= 1 then
        notification.AddLegacy(ahouse.lang.l.notif_noplayers, 1, 5)
        return
    end

    local p = vgui.Create("ahouse_coowners")
    p:SetSize(ScrW() / 4, ScrH() / 2)
    p:MakePopup()
    p:Center()
    p:Build(t.houseid)
end

function ENT:DrawTranslucent( flags )
	self:Draw(flags)
    self:DestroyShadow()

    if !ahouse.HouseData.EntToHouse then return end

    local t = ahouse.HouseData.EntToHouse[self:EntIndex()]

    if t and ui3d2d.startDraw(self:GetPos(), self:LocalToWorldAngles(angles), .05, self) then
        --Draw your UI here
        paint()
        local txtH = margin

        for k, v in ipairs({
            {"u", "ahouse_Logo3D2D_40", color_white},
            {t.name or "", "ahouse_3D2D_33", color_white},
            {ahouse.HouseData.List[t.houseid] and ahouse.HouseData.PropertyPrice(LocalPlayer(), t.houseid, false, true) or 0, "ahouse_3D2D_33", ahouse.Config.Colors.LightGreen}
        }) do
            txtH = txtH + (select(2, draw.SimpleText(v[1], v[2], w/2, txtH, v[3], 1, 0)))
        end

        txtH = txtH + ahouse.GetMargin(0.25)

        local fd = ahouse.HouseData.FirstSafeDoor(t.houseid)

        if IsValid(fd) and fd:isMasterOwner(LocalPlayer()) then
            draw.SimpleText(ahouse.lang.l.ringbell, "ahouse_3D2D_33", margin, txtH, ahouse.Config.Colors["White"], 0, 0)
            txtH = txtH + ahouse.GetMargin(0.25)
            local _, txtHButton = draw.SimpleText("d", "ahouse_Logo3D2D_25", w - margin, txtH,
            ahouse.Config.Colors[!t.disabledbell and "LightGreen" or "SubBackground"], 2, 0)

            if ui3d2d.isHovering(0, txtH, w, txtHButton) and ui3d2d.isPressed() then --Check if the box is being hovered
                net.Start("ahouse_house_manage")
                net.WriteEntity(self)
                net.WriteUInt(t.houseid, 10)
                net.WriteUInt(0, 4)
                net.SendToServer()
            end

            txtH = txtH + txtHButton

            surface.SetFont("ahouse_3D2D_33")
            local txtWButton, txtHButton = surface.GetTextSize(ahouse.lang.l.coowners)

            if ui3d2d.isHovering(0, txtH, w, txtHButton) then
                local left = ui3d2d.isHovering(margin, txtH, txtWButton, txtHButton)

                draw.SimpleText(ahouse.lang.l.coowners, "ahouse_3D2D_33", margin, txtH, ahouse.Config.Colors[left and "LightGreen" or "White"], 0, 0)
                draw.SimpleText(ahouse.lang.l.sell, "ahouse_3D2D_33", w - margin, txtH, ahouse.Config.Colors[!left and "LightGreen" or "White"], 2, 0)

                if ui3d2d.isPressed() then
                    if left then
                        display_coowners(t)
                    else
                        // Send net to sell
                        net.Start("ahouse_house_manage")
                            net.WriteEntity(self)
                            net.WriteUInt(t.houseid, 10)
                            net.WriteUInt(2, 4)
                        net.SendToServer()
                    end
                end
            else
                draw.SimpleText(ahouse.lang.l.coowners, "ahouse_3D2D_33", margin, txtH, ahouse.Config.Colors.White, 0, 0)
                draw.SimpleText(ahouse.lang.l.sell, "ahouse_3D2D_33", w - margin, txtH, ahouse.Config.Colors.White, 2, 0)
            end

            txtH = txtH + txtHButton

            surface.SetFont("ahouse_3D2D_33")
            txtWButton, txtHButton = surface.GetTextSize("Close")

            if ui3d2d.isHovering(w / 2 - margin, txtH, w / 2, txtHButton) then
                local isClose = ui3d2d.isHovering(w - margin - txtWButton, txtH, txtWButton, txtHButton)
                draw.SimpleText(ahouse.lang.l.close, "ahouse_3D2D_33", w - margin, txtH, ahouse.Config.Colors[isClose and "LightGreen" or "White"], 2, 0)
                local wT, _ = draw.SimpleText("/", "ahouse_3D2D_33", w - margin - txtWButton, txtH, ahouse.Config.Colors.White, 2, 0)
                draw.SimpleText(ahouse.lang.l.open, "ahouse_3D2D_33", w - margin - txtWButton - wT, txtH, ahouse.Config.Colors[!isClose and "LightGreen" or "White"], 2, 0)

                if ui3d2d.isPressed() then
                    net.Start("ahouse_house_manage")
                        net.WriteEntity(self)
                        net.WriteUInt(t.houseid, 10)
                        net.WriteUInt(isClose and 6 or 5, 4)
                    net.SendToServer()
                end
            else
                draw.SimpleText(ahouse.lang.l.open .. "/" .. ahouse.lang.l.close, "ahouse_3D2D_33", w - margin, txtH, ahouse.Config.Colors.White, 2, 0)
            end

            draw.SimpleText(ahouse.lang.l.alldoors, "ahouse_3D2D_33", margin, txtH, ahouse.Config.Colors.White60, 0, 0)
        elseif IsValid(fd) and fd:isKeysOwned() then
            surface.SetFont("ahouse_3D2D_33")
            local txtWButton, txtHButton = surface.GetTextSize(ahouse.lang.l.ringbell)
            draw.SimpleText(ahouse.lang.l.ringbell, "ahouse_3D2D_33", w/2, txtH, ahouse.Config.Colors[ui3d2d.isHovering(0, txtH, w, txtHButton) and "LightGreen" or "White"], 1, 0)
            
            if ui3d2d.isPressed() then
                // send net to ringbell
                net.Start("ahouse_house_manage")
                    net.WriteEntity(self)
                    net.WriteUInt(t.houseid, 10)
                    net.WriteUInt(4, 4)
                net.SendToServer()
            end
        else
            surface.SetFont("ahouse_3D2D_33")
            local txtWButton, txtHButton = surface.GetTextSize(ahouse.lang.l.buy)

            if ui3d2d.isHovering(0, txtH, w, txtHButton) then
                local left = ui3d2d.isHovering(margin, txtH, txtWButton, txtHButton)

                draw.SimpleText(ahouse.lang.l.buy, "ahouse_3D2D_33", margin, txtH, ahouse.Config.Colors[left and "LightGreen" or "White"], 0, 0)
                draw.SimpleText(ahouse.lang.l.ringbell, "ahouse_3D2D_33", w - margin, txtH, ahouse.Config.Colors[!left and "LightGreen" or "White"], 2, 0)

                if ui3d2d.isPressed() then
                    if left then
                        net.Start("ahouse_house_manage")
                            net.WriteEntity(self)
                            net.WriteUInt(t.houseid, 10)
                            net.WriteUInt(3, 4)
                        net.SendToServer()
                    else
                        // send net to ringbell
                        net.Start("ahouse_house_manage")
                            net.WriteEntity(self)
                            net.WriteUInt(t.houseid, 10)
                            net.WriteUInt(4, 4)
                        net.SendToServer()
                    end
                end
            else
                draw.SimpleText(ahouse.lang.l.buy, "ahouse_3D2D_33", margin, txtH, ahouse.Config.Colors.White, 0, 0)
                draw.SimpleText(ahouse.lang.l.ringbell, "ahouse_3D2D_33", w - margin, txtH, ahouse.Config.Colors.White, 2, 0)
            end
        end

        ui3d2d.endDraw()
    end
end