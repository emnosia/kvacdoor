AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/props_phx/construct/metal_plate1.mdl")
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetCollisionBounds( Vector(-1, -1, -1), Vector(4, 2, 1) )
	self:SetMoveType(0)
	self:SetModelScale(0.1)
end

function ENT:Use(ply)
end