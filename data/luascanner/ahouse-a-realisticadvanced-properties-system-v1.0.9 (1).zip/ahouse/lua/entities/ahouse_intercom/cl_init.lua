include("shared.lua")

function ENT:Draw(f)
    self:DrawModel(f)

    local rt = CurTime() - (self.ahouse_startglow or 0)

    if rt < 5 then
        local rat = 1

        if rt < 0.5 then
            rat = rt * 2
        elseif rt > 4.5 then
            rat = 1 - (rt - 4.5) * 2
        end

        render.SetColorMaterial()
        render.DrawSphere( self:GetPos() + Vector(0, 0, 2.5) + self:GetAngles():Forward() * 0.7,
            0.25,
            10,
            10, Color(0, 147, 255, 255 * rat)
        )
    end
end

function ENT:DrawTranslucent( flags )
    self:Draw(flags)
end

net.Receive("ahouse_intercom", function()
    if net.ReadBool() then
        local e = net.ReadEntity()
        e.ahouse_startglow = CurTime()
    else
        local u = net.ReadUInt(5)
        local snd = ahouse.Config.RingbellSounds[u]

        if !snd then return end

        sound.PlayFile( "sound/akulla/ahouse/doorbell" .. snd, "", function( station, errCode, errStr )
            if ( IsValid( station ) ) then
                station:SetVolume(0.5)
                station:Play()
            end
        end )
    end
end)