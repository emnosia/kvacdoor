local AddCSLuaFile = AddCSLuaFile
local include = include
local net = net

AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Use(ply)
    if !self.active then return end

    ply.ahouse_doorhole = self

    net.Start("ahouse_doorholes")
        net.WriteEntity(self)
        net.WriteEntity(self.ahouse_door)
    net.Send(ply)
end

function ENT:Initialize()
    self:SetModel("models/sterling/akulla_peephole.mdl")
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
end