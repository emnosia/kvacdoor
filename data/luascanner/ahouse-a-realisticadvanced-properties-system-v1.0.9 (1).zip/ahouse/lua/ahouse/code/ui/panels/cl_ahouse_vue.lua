local PANEL = {}

local mat = Material("akulla/ahouse/pattern.png", "smooth noclamp")
local grad = Material("gui/gradient_up")

function PANEL:Build(parent, realW, realH)
    local selectedHouse, actualView, ownShowedProperty, selectedCam

    local l = ahouse.HouseData.List
    local ply = LocalPlayer()

    local margin = ahouse.GetMargin(0.75)
    local margin2 = ahouse.GetMargin(0.5)
    local margin4 = ahouse.GetMargin(0.25)

    local buttonTall = ahouse.getfontheight("ahouse_16") + ahouse.getfontheight("ahouse_12") + margin2
    local buttonMargin = buttonTall / 4
    local alphaLoad = {}

    local left = vgui.Create("EditablePanel", self)
    left:Dock(LEFT)
    left:SetWide(realW * 0.19)
    left:DockMargin(0, 0, margin, 0)

    // Back Header
    local backHeader = parent.header:Add("DButton")
    backHeader:Dock(LEFT)
    backHeader:SetPaintBackground(false)
    backHeader:SetFont("ahouse_32")
    backHeader:SetTextColor(ahouse.Config.Colors.White)
    backHeader:SetText(ahouse.lang.l.ui_back)
    backHeader:SetWide(left:GetWide())
    backHeader:SetContentAlignment(1)
    backHeader:SetAlpha(0)
    backHeader:AlphaTo(255, 0.25, 0.75)

    // Back Header
    local ownedHeader = parent.header:Add("DButton")
    ownedHeader:Dock(FILL)
    ownedHeader:SetPaintBackground(false)
    ownedHeader:SetFont("ahouse_32")
    ownedHeader:SetTextColor(ahouse.Config.Colors.White)
    ownedHeader:SetText("")
    ownedHeader:SetContentAlignment(1)
    ownedHeader:SetAlpha(0)
    ownedHeader:DockMargin(margin, 0, 0, 0)
    table.insert(alphaLoad, ownedHeader)
    
    function backHeader:DoClick()
        parent:Unload()

        ownedHeader:AlphaTo(0, 0.25, 0, function(_, pnl)
            pnl:Remove()
        end)

        self:AlphaTo(0, 0.25, 0, function(_, pnl)
            pnl:Remove()
        end)
    end

    local leftBottom = vgui.Create("DPanel", left)
    leftBottom:DockMargin(0, margin2, 0, 0)
    leftBottom:Dock(BOTTOM)
    leftBottom:SetTall(buttonTall)
    leftBottom:SetContentAlignment(4)
    leftBottom:DockPadding(margin4*1.5, margin4, margin4, margin4)

    function leftBottom:Paint(w, h)
        draw.RoundedBox(ahouse.GetCorner(), 0, 0, w, h,
            ahouse.UI.ColorTo(ahouse.Config.Colors.SubBackground, ahouse.Config.Colors.BlackGreen, self.perc))
    end

    ahouse.UI.AddHoverTimer(leftBottom, 3, true)

    local leftBottomSearch = vgui.Create("DTextEntry", leftBottom)
    leftBottomSearch:Dock(FILL)
    leftBottomSearch:SetTextColor(ahouse.Config.Colors.White)
    leftBottomSearch:SetFont("ahouse_16")
    leftBottomSearch:SetPlaceholderText(ahouse.lang.l.search)
    leftBottomSearch:SetPaintBackground(false)
    leftBottomSearch:SetDrawLanguageID(false)
    leftBottomSearch:SetUpdateOnType( true )

    // Left Top
    local leftList = vgui.Create("DScrollPanel", left)
    leftList:Dock(FILL)
    local vbar = leftList:GetVBar()

    vbar:SetHideButtons(true)

    function vbar.btnGrip:Paint(w, h)
        surface.SetDrawColor(ahouse.Config.Colors.SubBackground)
        surface.DrawRect(w-4, 0, 4, h)
    end

    function vbar:Paint() end

    local containerRight = vgui.Create("EditablePanel", self)
    containerRight:Dock(FILL)

    /*
        For jobs
    */
    local panels = {}

    function leftBottomSearch:OnChange()
        local t = string.lower(self:GetText())

        local first = false

        for k, v in ipairs(panels) do
            local b = string.StartWith(string.lower(v[2]), t)
            v[1]:SetTall(b and buttonTall or 0)
            v[1]:Dock(TOP)

            if b then
                v[1]:DockMargin(0, !first and 0 or margin4, 0, 0)
                first = true
            else
                v[1]:DockMargin(0, 0, 0, 0)
            end
        end

        ahouse.HouseData.Owned = ahouse.HouseData.Owned or {}

        leftList:InvalidateLayout(true)
    end

    local rightBottom = vgui.Create("DPanel", containerRight)
    rightBottom:Dock(BOTTOM)
    rightBottom:SetTall(leftBottom:GetTall())
    rightBottom:DockMargin(leftBottom:GetDockMargin())
    rightBottom:SetPaintBackground(false)

    local rightDisplay = vgui.Create("EditablePanel", containerRight)
    rightDisplay:Dock(FILL)
    rightDisplay:DockPadding(margin2, margin2, margin2, margin2)

    function rightDisplay:Paint(w, h)
        draw.RoundedBox(8, 0, 0, w, h, ahouse.Config.Colors.SubBackground)
    end

    local rightDisplayBottom = vgui.Create("EditablePanel", rightDisplay)
    rightDisplayBottom:Dock(BOTTOM)
    rightDisplayBottom:SetTall(leftBottom:GetTall()*1)

    local rightDisplayMain = vgui.Create("EditablePanel", rightDisplay)
    rightDisplayMain:Dock(FILL)
    rightDisplayMain:DockMargin(0, 0, 0, margin2)

    local mainStencil
    function rightDisplayMain:Paint(w, h)
        if selectedHouse then
            if !mainStencil then
                mainStencil = ahouse.UI.RoundedBox(0, 0, w, h, ahouse.GetCorner())
            end

            local tex, _, av = ahouse.UI.WriteHouseTexture(selectedHouse, ahouse.UI.CreateRT("main", w, h), specificCam)
            actualView = av

            if !tex then
                draw.RoundedBox(ahouse.GetCorner(), 0, 0, w, h, ahouse.Config.Colors.SubBackground)
            else
                ahouse.StartStencil()
                    surface.SetDrawColor(color_black)
                    draw.NoTexture()
                    surface.DrawPoly(mainStencil)
                ahouse.ReplaceStencil(1)
                    surface.SetMaterial(tex)
                    surface.SetDrawColor(color_white)
                    surface.DrawTexturedRect(0, 0, w, h)
                ahouse.EndStencil()
            end
        else
            draw.RoundedBox(ahouse.GetCorner(), 0, 0, w, h, ahouse.Config.Colors.Background)
        end
    end

    local surfaceRT = ahouse.UI.RoundedBox(0, 0, rightDisplayBottom:GetTall() * 1.77, rightDisplayBottom:GetTall(), ahouse.GetCorner())
    local corner, corner2
    local butSizeW, butSizeH
    local rtList = {}

    for i=1, 4 do
        local rtButton = vgui.Create("DButton", rightDisplayBottom)
        rtButton:SetText("")
        rtButton:Dock(RIGHT)
        rtButton:SetWide(rightDisplayBottom:GetTall() * 1.77)
        rtButton:DockMargin(margin4, 0, 0, 0)

        butSizeW, butSizeH = rtButton:GetWide(), rightDisplayBottom:GetTall()
        // selectedCam
        rtList[i] = ahouse.UI.WriteHouseTexture(id, ahouse.UI.CreateRT("placeholder_" .. i, butSizeW, butSizeH), i)

        function rtButton:DoClick()
            if specificCam == i then
                specificCam = nil
            else
                specificCam = i
            end
        end

        function rtButton:Paint(w, h)
            if !rtList[i] then
                draw.RoundedBox(ahouse.GetCorner(), 0, 0, w, h,
                    ahouse.Config.Colors.Background)
            else
                if !corner then
                    corner = {
                        {x=w-15, y=h},
                        {x=w, y=h-15},
                        {x=w, y=h}
                    }
                end

                local now = actualView == i

                ahouse.StartStencil()
                    surface.SetDrawColor(ahouse.Config.Colors.Background)
                    draw.NoTexture()
                    surface.DrawPoly(surfaceRT)
                ahouse.ReplaceStencil(1)
                    surface.SetMaterial(rtList[i])
                    surface.SetDrawColor(color_white)
                    surface.DrawTexturedRect(0, 0, w, h)

                    if now then
                        draw.NoTexture()
                        surface.SetDrawColor(ahouse.Config.Colors.BlackGreen)
                        surface.DrawPoly(corner)

                        draw.NoTexture()
                        surface.SetDrawColor( ahouse.Config.Colors.SubBackground )
                        surface.DrawTexturedRectRotated( w-7, h-7, 100, 4, 45 )
                    end
                ahouse.EndStencil()
            end
        end
    end

    local infosButtons = {}

    local listinfos = vgui.Create("DIconLayout", rightDisplayBottom)
    listinfos:SetSpaceX(5)
    listinfos:SetSpaceY(5)
    listinfos:Dock(FILL)

    for k, v in ipairs({"K", "j", "u", "q"}) do
        local container = vgui.Create("EditablePanel", listinfos)

        local b = vgui.Create("DLabel", container)
        b:SetText(v)
        b:SetFont("ahouse_Icon_20")
        b:SetTextColor(ahouse.Config.Colors.LightGreen)
        b:Dock(LEFT)
        b:SetWide(b:GetContentSize())
        b:SetAlpha(0)

        local t = vgui.Create("DLabel", container)
        t:Dock(LEFT)
        t:SetText("Placeholder")
        t:SetFont("ahouse_16")
        t:SetTextColor(ahouse.Config.Colors.White)
        t:DockMargin(margin4, 0, margin2, 0)
        t:SetWide(t:GetContentSize())
        t:SetAlpha(0)

        container:SetSize(b:GetWide(), select(2, b:GetContentSize()))

        container.add = b:GetContentSize() + margin4 + margin2
        infosButtons[k] = {container, t}

        table.insert(alphaLoad, b)
        table.insert(alphaLoad, t)
    end


    /*
        Buy button
    */
    local buy = rightBottom:Add("DButton")
    buy:DockPadding(buttonMargin*1.5, buttonMargin, buttonMargin*1.5, buttonMargin)
    buy:Dock(RIGHT)
    buy:SetFont("ahouse_16")
    buy:SetText(ahouse.lang.l.buy)
    buy:SetTextInset(buttonMargin*1.5, 0)
    buy:SetWide(left:GetWide()/2)
    buy:SetContentAlignment(5)
    buy:SetTextColor(ahouse.Config.Colors.White60)

    function buy:Paint(w, h)
        draw.RoundedBox(8, 0, 0, w, h, ahouse.UI.ColorTo(ahouse.Config.Colors.SubBackground, ahouse.Config.Colors.BlackGreen, self.perc))
        self:SetTextColor(ahouse.UI.ColorTo(ahouse.Config.Colors.White60, ahouse.Config.Colors.White, self.perc))
    end

    function buy:DoClick()
        if !selectedHouse then return end

        net.Start("ahouse_shop")
            net.WriteUInt(ownShowedProperty and 2 or 0, 3)
            net.WriteUInt(selectedHouse, 10)
        net.SendToServer()

        parent:Remove()
    end

    ahouse.UI.AddHoverTimer(buy, 3)

    local rent = rightBottom:Add("DButton")
    rent:DockPadding(0, 0, margin2, 0)
    rent:DockMargin(0, 0, margin, 0)
    rent:Dock(RIGHT)
    rent:SetFont("ahouse_16")
    rent:SetText(ahouse.lang.l.rent)
    rent:SetTextInset(buttonMargin*1.5, 0)
    rent:SetCaretPos(buttonMargin*1.5)
    rent:SetWide(left:GetWide()/2)
    rent:SetContentAlignment(5)
    rent:SetTextColor(ahouse.Config.Colors.White60)

    function rent:Paint(w, h)
        draw.RoundedBox(8, 0, 0, w, h, ahouse.UI.ColorTo(ahouse.Config.Colors.SubBackground, ahouse.Config.Colors.BlackGreen, self.perc))
        self:SetTextColor(ahouse.UI.ColorTo(ahouse.Config.Colors.White60, ahouse.Config.Colors.White, self.perc))
    end

    function rent:DoClick()
        if !selectedHouse then return end

        ahouse.UserProperties = ahouse.UserProperties or {}
        if ahouse.UserProperties[selectedHouse] then
            local c = ahouse.Config.PermanentHousing

            local rest = ahouse.UserProperties[selectedHouse].time
            local cut = math.ceil(c.BuyTime / ahouse.Config.RentTime) - math.ceil(rest / ahouse.Config.RentTime)

            local p = vgui.Create("ahouse_AskInput")
            p:SetTitle(ahouse.lang.l.ui_extra)
            p:SetTextButton(ahouse.lang.l.re_rent)
            p:CreateEntry(ahouse.FormatLanguage("timeday", ahouse.UI.DominantFormatTime(ahouse.Config.RentTime), cut), true)
            p:SetWide(ScrW()/4*2)
            p:Center()

            p:SetCallback(function(but, p, ...)
                local entries = {...}
                local r = tonumber(entries[1][2])
                
                if r < 1 or r > cut then
                    entries[1][1]:SetText(ahouse.lang.l.invalid_value)
                    return
                end
    
                net.Start("ahouse_shop")
                    net.WriteUInt(4, 3)
                    net.WriteUInt(selectedHouse, 10)
                    net.WriteUInt(r, 16)
                net.SendToServer()
            end)
        
            return
        end

        if ahouse.Config.PermanentHousing.Enabled then
            local p = vgui.Create("ahouse_AskInput")
            p:SetTitle(ahouse.lang.l.ui_rentdays)
            p:SetTextButton(ahouse.lang.l.rent)
            p:CreateEntry(ahouse.FormatLanguage("timeday", ahouse.UI.DominantFormatTime(ahouse.Config.RentTime), math.ceil(ahouse.Config.PermanentHousing.BuyTime / ahouse.Config.RentTime)), true)
            p:SetWide(ScrW()/4*2)
            p:Center()

            p:SetCallback(function(but, p, ...)
                local entries = {...}
                local r = tonumber(entries[1][2])
                
                if r < 1 or r > math.ceil(ahouse.Config.PermanentHousing.BuyTime / ahouse.Config.RentTime) then
                    entries[1][1]:SetText(ahouse.lang.l.invalid_value)
                    return
                end
    
                net.Start("ahouse_shop")
                    net.WriteUInt(1, 3)
                    net.WriteUInt(selectedHouse, 10)
                    net.WriteUInt(r, 16)
                net.SendToServer()
            end)
        else
            net.Start("ahouse_shop")
                net.WriteUInt(1, 3)
                net.WriteUInt(selectedHouse, 10)
            net.SendToServer()
        end

        parent:Remove()
    end

    ahouse.UI.AddHoverTimer(rent, 3)

    local gps = rightBottom:Add("DButton")
    gps:DockPadding(buttonMargin*1.5, buttonMargin, buttonMargin*1.5, buttonMargin)
    gps:Dock(LEFT)
    gps:SetWide(left:GetWide())
    gps:SetText(ahouse.lang.l.ui_gps)
    gps:SetTextInset(buttonMargin*1.5, 0)
    gps:SetCaretPos(buttonMargin*1.5)
    gps:SetContentAlignment(4)
    gps:SetTextColor(ahouse.Config.Colors.White60)
    gps:SetFont("ahouse_16")
    gps.Paint = buy.Paint

    function gps:DoClick()
        if !selectedHouse then return end
        -- Draw logo
        local house = ahouse.HouseData.List[selectedHouse]
        local houseGps = (house.vecs[2] - house.vecs[1]) / 2 + house.vecs[1]
        local p = LocalPlayer()

        timer.Create("aradio_GPSShow", 300, 1, function()
            hook.Remove("HUDPaint", "aradio_GPSShow")
        end)

        hook.Add("HUDPaint", "aradio_GPSShow", function()
            local s = houseGps:ToScreen()

            if s.visible then
                local d = p:GetPos():Distance(houseGps)
                local dist = math.floor(d / 52.49) .. "m"

                if d < 400 then
                    hook.Remove("HUDPaint", "aradio_GPSShow")
                end

                local _, txtH = draw.SimpleText(house.name, "ahouse_16", s.x, s.y, color_white, 1, 1)
                txtH = txtH + select(2, draw.SimpleText(dist, "ahouse_16", s.x, s.y+txtH, white_trans, 1, 1))
                draw.SimpleText("O", "ahouse_Icon_28", s.x, s.y + txtH + math.sin(CurTime()*1.5)*8, color_white, 1, 0)
            end
        end)
    end

    ahouse.UI.AddHoverTimer(gps, 3)


    /*
        For jobs
    */

    local jobSpecific
    if ahouse.Config.Jobs[team.GetName(LocalPlayer():Team())] then
        jobSpecific = rightBottom:Add("DButton")
        jobSpecific:DockPadding(0, 0, margin2, 0)
        jobSpecific:DockMargin(margin, 0, 0, 0)
        jobSpecific:Dock(LEFT)
        jobSpecific:SetFont("ahouse_16")
        jobSpecific:SetText(ahouse.lang.l.printcontract)
        jobSpecific:SetTextInset(buttonMargin*1.5, 0)
        jobSpecific:SetCaretPos(buttonMargin*1.5)
        jobSpecific:SetWide(left:GetWide())
        jobSpecific:SetContentAlignment(4)
        jobSpecific:SetTextColor(ahouse.Config.Colors.White60)

        jobSpecific.Paint = buy.Paint
    
        function jobSpecific:DoClick()
            if !selectedHouse then return end

            local p = vgui.Create("ahouse_AskInput")
            p:SetWide(ScrW()/4*2)
            p:SetTitle(ahouse.lang.l.contract_options)
            p:SetTextButton(ahouse.lang.l.create)
            p:SetWide(ScrW()/4*2)
            p:Center()

            if ahouse.Config.PermanentHousing.Enabled then
                p:CreateEntry("(" .. ahouse.lang.l.rent .. ") " ..  ahouse.FormatLanguage("timeday", ahouse.UI.DominantFormatTime(ahouse.Config.RentTime), math.floor((ahouse.Config.PermanentHousing.BuyTime / ahouse.Config.RentTime))), true)
            end

            local commission = p:CreateEntry(ahouse.lang.l.contract_commission, true)

            local t = p:CreateEntryComboBox()
            t:AddChoice(ahouse.lang.l.direct_buy)
            t:AddChoice(ahouse.lang.l.renting)

            local playerCombo = p:CreateEntryComboBox()

            for k, v in ipairs(player.GetAll()) do
                playerCombo:AddChoice(v:Nick(), v)
            end

            p:SetCallback(function(but, p, ...)
                local entries = {...}
                local is_rent = t:GetSelectedID() == 2

                if ahouse.Config.PermanentHousing.Enabled and is_rent then
                    local r = tonumber(entries[1][2])
                    if !r or r < 1 or r > math.floor((ahouse.Config.PermanentHousing.BuyTime / ahouse.Config.RentTime)) then
                        entries[1][1]:SetText(ahouse.lang.l.invalid_value)
                        return
                    end
                end

                local commissionPrice = tonumber(commission:GetText())
                local target = select(2, playerCombo:GetSelected())
                local willPrice = ahouse.HouseData.PropertyPrice(target, selectedHouse,
                    is_rent, false, (ahouse.Config.PermanentHousing.Enabled and is_rent) and tonumber(entries[1][2]) or nil)

                if !commissionPrice or willPrice < commissionPrice then
                    commission:SetText(ahouse.FormatLanguage("price_inferior", DarkRP.formatMoney(willPrice)))
                    return
                end
    
                net.Start("ahouse_shop")
                    net.WriteUInt(3, 3)
                    net.WriteUInt(selectedHouse, 10)
                    net.WriteEntity(target)
                    net.WriteUInt(commissionPrice, 24)
                    net.WriteBool(is_rent)

                    if ahouse.Config.PermanentHousing.Enabled and is_rent then
                        net.WriteUInt(tonumber(entries[1][2]), 16)
                    end

                    p:Remove()
                net.SendToServer()
                parent:Remove()
            end)
        end
    
        ahouse.UI.AddHoverTimer(jobSpecific, 3)
    end

    local first = false
    ahouse.HouseData.Owned = ahouse.HouseData.Owned or {}

    for i, v in pairs(l) do
        local d = ahouse.HouseData.Owned[i] and ahouse.HouseData.Owned[i] != LocalPlayer()

        if d and ahouse.Config.HideOwnedProperties then continue end

        local b = leftList:Add("DButton")
        b:Dock(TOP)
        b:DockPadding(margin4*1.5, margin4, margin4, margin4)
        b:SetText("")
        b:SetTall(buttonTall)
        b:DockMargin(0, !first and 0 or margin4, 0, 0)

        table.insert(panels, {b, v.name})

        function b:Paint(w, h)
            self.forceanim = selectedHouse == i
            draw.RoundedBox(ahouse.GetCorner(), 0, 0, w, h,
                ahouse.UI.ColorTo(ahouse.Config.Colors[ahouse.HouseData.Owned[i] and "Background" or "SubBackground"], ahouse.Config.Colors.BlackGreen, self.perc))
        end
    
        ahouse.UI.AddHoverTimer(b, 3)

        first = true

        local title = vgui.Create("DLabel", b)
        title:Dock(TOP)
        title:SetText(v.name)
        title:SetTextColor(ahouse.Config.Colors.White)
        title:SetFont("ahouse_16")
        title:SetTall(select(2, title:GetContentSize()))

        local formattedPrice = ahouse.HouseData.PropertyPrice(ply, i, nil, true)
        local price = vgui.Create("DLabel", b)
        price:Dock(TOP)
        price:SetText(formattedPrice)
        price:SetTextColor(ahouse.Config.Colors.White60)
        price:SetFont("ahouse_12")
        price:SetTall(select(2, price:GetContentSize()))
        // getHouseDoors(id)

        function b:DoClick()
            if alphaLoad[1]:GetAlpha() == 0 then
                for k, v in ipairs(alphaLoad) do
                    v:AlphaTo(255, 0.5, 0)
                end
            end

            buy:SetVisible(!d)
            rent:SetVisible(!d)

            selectedHouse = i
            specificCam = nil

            ahouse.HouseData.Owned = ahouse.HouseData.Owned or {}
            local owner = ahouse.HouseData.Owned[i]
            if owner and owner == ply then
                ownShowedProperty = true
                buy:SetText(ahouse.lang.l.sell)

                if ahouse.Config.PermanentHousing.Enabled then
                    rent:SetText(ahouse.lang.l.re_rent)
                else
                    rent:SetAlpha(0)
                end
            else
                buy:SetText(ahouse.lang.l.buy)
                rent:SetAlpha(255)
                rent:SetText(ahouse.lang.l.rent)
                // ownShowedProperty
            end

            if ply:isCP() and owner then
                ownedHeader:SetText(ahouse.FormatLanguage("property_of", owner:Nick()))
            else
                ownedHeader:SetText("")
            end

            for loop = 1, 4 do
                rtList[loop] = ahouse.UI.WriteHouseTexture(i, ahouse.UI.CreateRT("placeholder_" .. loop, butSizeW, butSizeH), loop)
            end

            infosButtons[1][2]:SetText(formattedPrice)
            infosButtons[2][2]:SetText(ahouse.HouseData.PropertyPrice(ply, i, true, true))
            infosButtons[3][2]:SetText(ahouse.lang.l["property_" .. v.type])
            infosButtons[4][2]:SetText(ahouse.lang.l["alarm_" .. (v.have_alarm and ahouse.Config.Alarm.Enable and "with" or "without")])

            for k, v in ipairs(infosButtons) do
                v[2]:SetWide(v[2]:GetContentSize())
                v[1]:SetWide(v[2]:GetWide() + v[1].add)

                v[1]:InvalidateLayout(true)
            end

            listinfos:InvalidateLayout(true)
            rightDisplayBottom:InvalidateLayout(true)

            net.Start("ahouse_askdisplay")
                net.WriteUInt(i, 24)
            net.SendToServer()
        end
    end
end

function PANEL:Init() end

derma.DefineControl( "ahouse_vue", "", PANEL, "EditablePanel" )