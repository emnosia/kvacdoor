local RTs = {

}

local function createRT(uid, w, h)
    local n = "ahouse_RT_" .. w .. "_" .. h .. uid

    if RTs[n] then return RTs[n] end

    local rt = GetRenderTarget(n, w or ScrW(), h or ScrH())
    local tex = CreateMaterial(n, "UnlitGeneric", {
        ["$basetexture"] = n,
        ["$translucent"] = 1,
    })
    local d = {
        rt, tex
    }

    RTs[n] = d

    return d
end

ahouse.UI.CreateRT = createRT

local function lerpAngleAux(ratio, ang1, ang2)
    return Angle(
        ang1.p + Lerp(ratio, 0, math.AngleDifference( ang2.p, ang1.p )),
        ang1.y + Lerp(ratio, 0, math.AngleDifference( ang2.y, ang1.y )),
        ang1.r + Lerp(ratio, 0, math.AngleDifference( ang2.r, ang1.r ))
    )
end

function ahouse.UI.DominantFormatTime(t)
    local h = math.floor(t / 3600)

    t = t - h*3600
    local m = math.floor(t / 60)

    t = t - m*60
    local s = t % 60

    local txt = ""

    if h != 0 then
        txt = txt .. h .. "h"
    end

    if m != 0 then
        txt = txt .. m .. "min"
    end

    if s != 0 then
        txt = txt .. s .. "s"
    end

    return txt
end

function ahouse.UI.WriteHouseTexture(id, rt, specificView, time)
    local data = ahouse.HouseData.List[id]
    if !data then return end

    local t = (time or UnPredictedCurTime()) % data.totalViewTime

    // specificView
    for k, v in ipairs(data.viewList) do
        if (v.rendertime >= t and !specificView) or k == specificView then
            if v.no_move then
                ahouse.UI.UpdateRT(rt[1], rt[2], v.pos, v.ang)
            else
                local ratio

                if specificView then
                    ratio = 0.5
                else
                    ratio = t / v.rendertime
                end

                local vec = LerpVector(ratio, v.pos, v.endpos)

                // The LerpAngle is bad
                // If a angle axis is -179 and 179, it will does from -179 to 179 and not just -179 to -180 to 179
                local ang = lerpAngleAux(ratio, v.ang, v.endang)
                local ratioB

                if !specificView then
                    if t < 0.5 then
                        ratioB = 1 - t * 2
                    elseif v.rendertime - t < 0.5 then
                        ratioB = 1 - ((v.rendertime - t) * 2)
                    end
                end

                ahouse.UI.UpdateRT(rt[1], rt[2], vec, ang, ratioB)
            end

            return rt[2], t, k
        elseif !specificView then
            t = t - v.rendertime
        end
    end
end

local queue = {}

hook.Add("PostRender", "ahouse_fixrt", function()
    for k, v in ipairs(queue) do
        render.PushRenderTarget(v[1])
            render.Clear(255, 255, 255, 255)

            local w = v[2]:Width()
            local h = v[2]:Height()

            render.RenderView( {
                origin = v[3],
                angles = v[4],
                drawviewmodel = false,
            } )

            if v[5] then
                cam.Start2D()
                    surface.SetDrawColor(0, 0, 0, v[5] * 255)
                    surface.DrawRect(0, 0, w, h)
                cam.End2D()
            end
        render.PopRenderTarget()
    end

    queue = {}
end)

function ahouse.UI.UpdateRT(rt, tex, pos, ang, addblack)
    table.insert(queue, {
        rt, tex, pos, ang, addblack
    })
end

function ahouse.UI.CachedCircle(x, y, radius, seg, radiusX)
    local cir = {}

    table.insert( cir, { x = x, y = y, u = 0.5, v = 0.5 } )
    for i = 0, seg do
        local a = math.rad( ( i / seg ) * -360 )
        table.insert( cir, { x = x + math.sin( a ) * (radiusX or radius), y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )
    end

    local a = math.rad( 0 )
    table.insert( cir, { x = x + math.sin( a ) * (radiusX or radius), y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )

    return cir
end

function ahouse.UI.RoundedBox(x, y, w, h, r)
    local pts = {}
    -- Top right
    local x_corner = (x + w) - r
    local y_corner = y + r

    for i = 270, 360 do
        table.insert(pts, {
            x = x_corner + math.cos(math.rad(i * 360) / 360) * r,
            y = y_corner + math.sin(math.rad(i * 360) / 360) * r
        })
    end

    -- Bottom Right
    x_corner = (x + w) - r
    y_corner = (y + h) - r

    for i = 0, 90 do
        table.insert(pts, {
            x = x_corner + math.cos(math.rad(i * 360) / 360) * r,
            y = y_corner + math.sin(math.rad(i * 360) / 360) * r
        })
    end

    -- Bottom Left
    x_corner = x + r
    y_corner = (y + h) - r

    for i = 90, 180 do
        table.insert(pts, {
            x = x_corner + math.cos(math.rad(i * 360) / 360) * r,
            y = y_corner + math.sin(math.rad(i * 360) / 360) * r
        })
    end

    -- Top Left
    x_corner = x + r
    y_corner = y + r

    for i = 180, 270 do
        table.insert(pts, {
            x = x_corner + math.cos(math.rad(i * 360) / 360) * r,
            y = y_corner + math.sin(math.rad(i * 360) / 360) * r
        })
    end

    return pts
end

// Flux shenanigans
local ft = FrameTime

function ahouse.UI.AddHoverTimer(pnl, ratio, parentCheck)
    pnl.perc = 0
    ratio = ratio or 1

    local oldPaint = pnl.Paint

    function pnl:Paint(w, h)
        local rft = ft() * ratio

        if self:IsHovered() or self.forceanim or (parentCheck and self:IsChildHovered()) then
            self.perc = self.perc + rft

            if self.perc >= 1 then
                self.perc = 0.999
            end
        else
            self.perc = (self.perc or 0) - rft

            if self.perc < 0 then
                self.perc = 0
            end
        end

        self.renderTime = rft

        oldPaint(self, w, h)
    end
end

local l = Lerp
local c = Color
function ahouse.UI.ColorTo(clr1, clr2, ratio)
    if ratio == 0 then return clr1 end
    if ratio == 1 then return clr2 end

    return c(
        l(ratio, clr1.r, clr2.r),
        l(ratio, clr1.g, clr2.g),
        l(ratio, clr1.b, clr2.b),
        l(ratio, clr1.a or 255, clr2.a or 255)
    )
end

function ahouse.UI.QuitOnClick(pnl)
    local t = pnl.Think
    pnl.c2 = CurTime()

    function pnl:Think()
        if t then
            t(self)
        end

        if !pnl.noquit and input.IsMouseDown(107) and (!self:IsChildHovered() and !self:IsHovered()) and CurTime() - self.c2 > 1 then
            self:Remove()
        end
    end
end

local mat = Material("akulla/ahouse/pattern.png", "smooth noclamp")
local amt = 60

function ahouse.UI.Background(pnl, w, h, overrideamt)
    local corner = ahouse.GetCorner()
    local r = ahouse.UI.RoundedBox(0, 0, w, h, corner)
    local amt = overrideamt or amt
    local a = math.floor(amt * (w / h))

    if pnl then
        function pnl:PaintOver(w, h)
            ahouse.EndStencil()
        end
    end

    return function()
        ahouse.StartStencil()
            surface.SetDrawColor(ahouse.Config.Colors.Background)
            draw.NoTexture()
            surface.DrawPoly(r)
        ahouse.ReplaceStencil(1)
            surface.SetMaterial(mat)
            surface.SetDrawColor(ahouse.Config.Colors.BlackGreenPattern)
            surface.DrawTexturedRectUV(0, 0, w, h, 0, 0, a, amt)

        if !pnl then
            ahouse.EndStencil()
        end
    end
end