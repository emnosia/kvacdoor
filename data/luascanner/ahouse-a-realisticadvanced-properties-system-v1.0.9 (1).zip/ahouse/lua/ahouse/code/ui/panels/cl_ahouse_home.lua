local PANEL = {}
local id
local incr = 0
local availableHouses, aHSize = {}, 0
local renderTime
local time = UnPredictedCurTime()

local optionsList = {
    {
        name = ahouse.lang.l.home_buy,
        desc = ahouse.lang.l.home_buy_desc,
        class = "ahouse_vue",
        logo = "K",
    },

    {
        name = ahouse.lang.l.home_manage,
        desc = ahouse.lang.l.home_manage_desc,
        class = "ahouse_property"
    },

    {
        name = ahouse.lang.l.home_settings,
        desc = ahouse.lang.l.home_settings_desc,
        logo = "&",
        class = "ahouse_params"
    }
}

function PANEL:ChangeView()
    if aHSize < 1 then return end

    incr = incr + 1
    id = availableHouses[incr]

    if !id then
        incr = 0
        self:ChangeView()
        return
    end

    net.Start("ahouse_askdisplay")
        net.WriteUInt(id, 24)
    net.SendToServer()

    renderTime = -1
    time = UnPredictedCurTime()
end

function PANEL:Build(parent, realW, realH)
    aHSize = 0
    for k, v in pairs(ahouse.HouseData.List) do
        if !ahouse.HouseData.Owned[k] then
            table.insert(availableHouses, k)
            aHSize = aHSize + 1
        end
    end

    self.parent = parent

    incr = math.random(0, aHSize - 1)
    self:ChangeView()

    local options = vgui.Create("EditablePanel", self)
    options:Dock(BOTTOM)
    options:SetSize(realW, realH*0.30)

    local margin = ahouse.GetMargin(1)
    local m = ahouse.GetMargin(0.5)
    local subW = (realW - margin * 2)/3

    for i, v in ipairs(optionsList) do
        local s = vgui.Create("DButton", options)
        s:DockMargin(i == 1 and 0 or margin, 0, 0, 0)
        s:Dock(LEFT)
        s:SetWide(subW)
        s:DockPadding(m, m, m, m)
        s:SetText("")

        local desc = vgui.Create("DLabel", s)
        desc:SetText(v.desc)
        desc:Dock(BOTTOM)
        desc:SetFont("ahouse_16")
        desc:SetTextColor(ahouse.Config.Colors.White60)
        desc:SetTall(select(2, desc:GetContentSize()))
        desc:SetContentAlignment(5)
        desc:SetMouseInputEnabled(false)

        local title = vgui.Create("DLabel", s)
        title:SetText(v.name)
        title:Dock(BOTTOM)
        title:SetFont("ahouse_24")
        title:SetTextColor(ahouse.Config.Colors.White)
        title:SetTall(select(2, title:GetContentSize()))
        title:SetContentAlignment(5)
        title:SetMouseInputEnabled(false)

        local icon = vgui.Create("DLabel", s)
        icon:SetText(v.logo or "u")
        icon:Dock(FILL)
        icon:SetFont("ahouse_Icon_64")
        icon:SetTextColor(ahouse.Config.Colors.White60)
        icon:SetTall(select(2, icon:GetContentSize()))
        icon:SetContentAlignment(5)
        icon:SetMouseInputEnabled(false)

        function s:Paint(w, h)
            draw.RoundedBox(8, 0, 0, w, h, 
                ahouse.UI.ColorTo(ahouse.Config.Colors.SubBackground, ahouse.Config.Colors.BlackGreen, self.perc))

            if self.perc != 0 then
                icon:SetTextColor(ahouse.UI.ColorTo(ahouse.Config.Colors.White60, ahouse.Config.Colors.White, self.perc))
            end
        end

        function s:DoClick()
            parent:LoadPanel(v.class)
        end

        ahouse.UI.AddHoverTimer(s, 3)
    end
end

function PANEL:Init() end

local grad = Material("gui/gradient_up")
local patternHome = Material("akulla/ahouse/patternhome.png", "smooth noclamp")
local endCinematicH = ahouse.Config.PatternCount * 0.66 / ahouse.Config.PatternCount
local rW, rH = 0.05, 0.4
local rGradH = 8 / ahouse.Config.PatternCount
local cA = ColorAlpha(ahouse.Config.Colors.Background, 60)
// Imagine if we could do a simple opacity gradient in glua...

function PANEL:Paint(w, h)
    if !id then return end
    local tex, rtAct = ahouse.UI.WriteHouseTexture(id, ahouse.UI.CreateRT("main", w, h * endCinematicH), nil, UnPredictedCurTime() - time)

    if !tex then return end

    if rtAct < renderTime then
        self:ChangeView()
        tex = ahouse.UI.WriteHouseTexture(id, ahouse.UI.CreateRT("main", w, h * endCinematicH), nil, UnPredictedCurTime() - time)
    end

    renderTime = rtAct

    local a = math.floor(ahouse.Config.PatternCount * (w / h))

    surface.SetDrawColor(color_black)
    surface.DrawRect(0, 0, w, h * endCinematicH)

    surface.SetDrawColor(color_white)
    surface.SetMaterial(tex)
    surface.DrawTexturedRect(0, 0, w, h * endCinematicH)

    surface.SetDrawColor(cA)
    surface.DrawRect(0, 0, w, h * endCinematicH)

    local _, hTxt = draw.SimpleText(ahouse.lang.l.startPhrase, "ahouse_32", rW * w, rH * h, ahouse.Config.Colors.White, 0, TEXT_ALIGN_BOTTOM)
    draw.SimpleText(ahouse.lang.l.startPhrase2, "ahouse_48", rW * w, rH * h, ahouse.Config.Colors.LightGreen2, 0, TEXT_ALIGN_TOP)

    surface.SetMaterial(grad)
    surface.SetDrawColor(ahouse.Config.Colors.Background)
    surface.DrawTexturedRect(0, h*endCinematicH - h*rGradH, w, h*rGradH)

    surface.SetMaterial(patternHome)
    surface.SetDrawColor(ahouse.Config.Colors.BlackGreenPattern)
    surface.DrawTexturedRectUV(0, h*endCinematicH - h*rGradH, w, h*rGradH, 0, 0, a, 1)
end

derma.DefineControl( "ahouse_home", "", PANEL, "EditablePanel" )