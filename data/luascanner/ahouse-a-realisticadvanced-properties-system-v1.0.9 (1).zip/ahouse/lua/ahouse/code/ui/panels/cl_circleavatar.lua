local PANEL = {}

local stencil_writemask = render.SetStencilWriteMask
local stencil_testmask = render.SetStencilTestMask
local stencil_id = render.SetStencilReferenceValue
local stencil_fail = render.SetStencilFailOperation
local stencil_zfail = render.SetStencilZFailOperation
local stencil_compare = render.SetStencilCompareFunction
local stencil_pass = render.SetStencilPassOperation

function PANEL:Init()
	self.avatar = vgui.Create("AvatarImage", self)
	self.avatar:SetPaintedManually(true)
	self.avatar:Dock(FILL)
	self.avatar:SetMouseInputEnabled(false)
	self:SetMouseInputEnabled(false)
end

function PANEL:SetPlayer(p, s)
	self.avatar:SetPlayer(p, s)
end

function PANEL:PerformLayout()
	self.border_poly = nil
end

local stencil_clr = Color(1, 1, 1, 1)
function PANEL:Paint(w, h)
	if !self.border_poly then
		if self.roundedValue then
			self.border_poly = ahouse.UI.RoundedBox(0, 0, w, h, 8)
		end
	end

	// Reset
	render.SetStencilEnable(true)
	
	stencil_writemask( 0xFF )
	stencil_testmask( 0xFF )
	stencil_fail( STENCIL_KEEP )
	stencil_zfail( STENCIL_KEEP )
	stencil_id( 2 )
	
	// Stencil
	stencil_compare( STENCIL_ALWAYS )
	stencil_pass( STENCIL_REPLACE)
	
	draw.NoTexture()
	surface.SetDrawColor(stencil_clr)
	surface.DrawPoly(self.border_poly)
	
	stencil_id(2)
	stencil_pass(STENCIL_DECR)
	stencil_compare(STENCIL_EQUAL)
	
	self.avatar:PaintManual()
	
	// Get settings back
	// Ignore stencil is only used in call panel actually
	render.SetStencilEnable(false)
end

vgui.Register("ahouse_CircleAvatar", PANEL)