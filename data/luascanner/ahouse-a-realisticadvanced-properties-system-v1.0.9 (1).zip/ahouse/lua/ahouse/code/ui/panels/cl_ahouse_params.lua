local PANEL = {}

function PANEL:Build(parent, realW, realH)
    local margin = ahouse.GetMargin(0.75)
    local margin2 = ahouse.GetMargin(0.5)

    local buttonTall = ahouse.getfontheight("ahouse_16") + ahouse.getfontheight("ahouse_12") + margin2

    local rb = vgui.Create("EditablePanel", self)
    rb:Dock(TOP)
    rb:SetTall(buttonTall)

    local rbTitle = vgui.Create("DLabel", rb)
    rbTitle:SetText("Ringbell Sound")
    rbTitle:SetFont("ahouse_16")
    rbTitle:Dock(LEFT)
    rbTitle:SetWide(rbTitle:GetContentSize())

    local rbSelect = vgui.Create("DComboBox", rb)
    rbSelect:Dock(RIGHT)
    rbSelect:SetWide(realW*0.05)
    rbSelect:SetTextColor(ahouse.Config.Colors.White)
    rbSelect:SetPaintBackground(false)
    rbSelect:SetFont("ahouse_16")

    // Back Header
    local backHeader = parent.header:Add("DButton")
    backHeader:Dock(LEFT)
    backHeader:SetPaintBackground(false)
    backHeader:SetFont("ahouse_32")
    backHeader:SetTextColor(ahouse.Config.Colors.White)
    backHeader:SetText(ahouse.lang.l.ui_back)
    backHeader:SetWide(realW*0.5)
    backHeader:SetContentAlignment(1)
    backHeader:SetAlpha(0)
    backHeader:AlphaTo(255, 0.25, 0.75)

    function backHeader:DoClick()
        parent:Unload()

        self:AlphaTo(0, 0.25, 0, function(_, pnl)
            pnl:Remove()
        end)
    end

    for k, v in ipairs(ahouse.Config.RingbellSounds) do
        rbSelect:AddChoice(k)
    end

    function rbSelect:Paint(w, h)
        draw.RoundedBox(8, 0, 0, w, h, ahouse.Config.Colors.SubBackground)
    end

    rbSelect:ChooseOptionID(ahouse.plyconfig and ahouse.plyconfig.ringbell or 1)

    function rbSelect:OnSelect(index, value)
        net.Start("ahouse_plyconfig")
            net.WriteUInt(index, 5)
        net.SendToServer()

        sound.PlayFile( "sound/akulla/ahouse/doorbell" .. ahouse.Config.RingbellSounds[index], "", function( station, errCode, errStr )
            if ( IsValid( station ) ) then
                station:SetVolume(0.5)
                station:Play()
            end
        end )
    end
end

function PANEL:Init() end

derma.DefineControl( "ahouse_params", "", PANEL, "EditablePanel" )