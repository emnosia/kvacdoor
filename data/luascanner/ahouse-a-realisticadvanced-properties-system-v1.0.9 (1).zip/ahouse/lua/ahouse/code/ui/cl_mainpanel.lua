local PANEL = {}
local m = ahouse.GetMargin(1)

local mat = Material("akulla/ahouse/pattern.png", "smooth noclamp")

function PANEL:Unload()
    if self.stack:Size() == 0 then
        error("[AHouse] Panel stack empty but trying to unload")
    end

    local p = self.stack:Pop()
    p:MoveTo(0, self:GetTall(), 1, 0, 0.5, function(_, pnl)
        pnl:Remove()
    end)

    local p2 = self.stack:Top()
    p2:MoveTo(0, 0, 1, 0, 0.5)
end

function PANEL:LoadPanel(class)
    self.header:Clear()

    local p = vgui.Create(class, self)
    p:SetSize(self:GetWide(), self:GetTall())

    if self.stack:Size() != 0 then
        local p2 = self.stack:Top()
        p2:MoveTo(0, -self:GetTall(), 1, 0, 0.5)

        p:SetPos(0, self:GetTall())
        p:MoveTo(0, 0, 1, 0, 0.5)
    else
        p:SetPos(0, 0)
    end

    p:DockPadding(m, m * 1.5 + self.realHeader:GetTall(), m, m)
    p:Build(self, self:GetWide() - m*2, self:GetTall() - (m * 1.5 + self.realHeader:GetTall()))

    self.realHeader:MoveToFront()

    self.stack:Push(p)
end

function PANEL:Init()
    local sw, sh = ScrW(), ScrH()
    m = ahouse.GetMargin(1)

    self:MakePopup()
    self:SetSize(sw * 0.6, sh * 0.6)
    self:Center()
    self:SetMouseInputEnabled(true)
    self:SetKeyboardInputEnabled(true)

    self:DockPadding(m, m, m, m)

    local realHeader = vgui.Create("EditablePanel", self)
    realHeader:Dock(TOP)
    realHeader:SetTall(ahouse.getfontheight("ahouse_24") + ahouse.getfontheight("ahouse_16"))
    realHeader:DockMargin(0, 0, 0, m/2)
    realHeader:MoveToFront()
    self.realHeader = realHeader

    function realHeader:Paint(w, h)
        local _, txtH = draw.SimpleText(LocalPlayer():Nick(), "ahouse_24", w - h - m / 2, 0, ahouse.Config.Colors.White, 2, 0)
        draw.SimpleText(DarkRP.formatMoney(LocalPlayer():getDarkRPVar("money")), "ahouse_16", w - h - m / 2, txtH, ahouse.Config.Colors.LightGreen, 2, 0)
    end

    local avatar = vgui.Create("ahouse_CircleAvatar", realHeader)
    avatar.roundedValue = ahouse.GetCorner()
    avatar:Dock(RIGHT)
    avatar:SetWide(realHeader:GetTall())
    avatar:SetPlayer(LocalPlayer(), 184)

    self.header = vgui.Create("EditablePanel", realHeader)
    self.header:DockMargin(0, 0, m * 2, 0)
    self.header:Dock(FILL)
    
    self.stack = util.Stack()

    ahouse.UI.QuitOnClick(self)
    self:LoadPanel("ahouse_home")
end

function PANEL:Paint(w, h)
    if !self.bgahouse then
        self.bgahouse = ahouse.UI.Background(self, w, h)
    end
    self.bgahouse()
end

net.Receive("ahouse_openui", function()
    if ahouse.HouseData.List then
        vgui.Create("ahouse_mainpanel")
    else
        notification.AddLegacy("[AHouse] Create properties before using the NPCs or command", 1, 4)
    end
end)


derma.DefineControl( "ahouse_mainpanel", "", PANEL, "EditablePanel" )