local IsValid = IsValid
local ScrW = ScrW
local ScrH = ScrH
local vgui = vgui
local select = select
local draw = draw

local PANEL = {}
local oldAskBox

function PANEL:Init()
    if oldAskBox and IsValid(oldAskBox) then
        oldAskBox:Remove()
    end

    local w = ScrW() * 0.27

    self:SetSize(w, ScrH() * 0.12)
    self:MakePopup()
    self:Center()
    self:DockPadding(w * 0.03, w * 0.03, w * 0.03, w * 0.03)

    local title = vgui.Create("DLabel", self)
    title:SetFont("ahouse_24")
    title:SetText("Sans titre")
    title:Dock(TOP)
    title:SetTall(select(2, title:GetContentSize()))
    title:SetContentAlignment(5)

    self.title = title

    local title2 = vgui.Create("DLabel", self)
    title2:SetFont("ahouse_16")
    title2:SetText("")
    title2:SetContentAlignment(5)
    title2:Dock(TOP)
    title2:SetTall(select(2, title:GetContentSize()))
    self.desc = title2

    local container = vgui.Create("EditablePanel", self)
    container:Dock(BOTTOM)

    container:SetTall(ahouse.getfontheight("ahouse_24"))

    local buttonValid = vgui.Create("DButton", container)
    buttonValid:Dock(RIGHT)
    buttonValid:SetWide(self:GetWide() / 2)
    buttonValid:SetFont("ahouse_Icon_20")
    buttonValid:SetText("r")
    function buttonValid:Paint(w, h)
        if self.perc != 0 then
            self:SetTextColor(ahouse.UI.ColorTo(ahouse.Config.Colors.White60, ahouse.Config.Colors.White, self.perc))
        end
    end
    ahouse.UI.AddHoverTimer(buttonValid, 3)

    function buttonValid:Paint() end

    local buttonCancel = vgui.Create("DButton", container)
    buttonCancel:Dock(RIGHT)
    buttonCancel:SetWide(self:GetWide() / 2)
    buttonCancel:SetFont("ahouse_Icon_20")
    buttonCancel:SetText("S")

    function buttonCancel:Paint(w, h)
        if self.perc != 0 then
            self:SetTextColor(ahouse.UI.ColorTo(ahouse.Config.Colors.White60, ahouse.Config.Colors.White, self.perc))
        end
    end
    ahouse.UI.AddHoverTimer(buttonCancel, 3)

    local oldSelf = self
    function buttonCancel:DoClick()
        if oldSelf.OnRefuse then
            oldSelf:OnRefuse()
        end

        oldSelf:Remove()
    end

    function buttonValid:DoClick()
        if oldSelf.OnAccept then
            oldSelf:OnAccept()
        end

        oldSelf:Remove()
    end

    function buttonCancel:Paint() end
    function buttonValid:Paint() end

    oldAskBox = self

    ahouse.UI.QuitOnClick(self)
end

function PANEL:Paint(w, h)
    if !self.bgahouse then
        self.bgahouse = ahouse.UI.Background(self, w, h, 10)
    end
    self.bgahouse()
end

function PANEL:OnAccept()
end

vgui.Register("ahouse_AskBox", PANEL, "EditablePanel")