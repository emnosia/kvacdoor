local PANEL = {}

function PANEL:Build(parent, realW, realH)
    local selectedHouse
    local l = {}
    local ply = LocalPlayer()

    for k, v in pairs(ahouse.HouseData.Owned or {}) do
        if v == ply then
            l[k] = ahouse.HouseData.List[k]
        end
    end

    local margin = ahouse.GetMargin(0.75)
    local margin2 = ahouse.GetMargin(0.5)
    local margin4 = ahouse.GetMargin(0.25)

    local buttonMargin = margin4
    local buttonTall = ahouse.getfontheight("ahouse_16") + ahouse.getfontheight("ahouse_12") + margin2

    local left = vgui.Create("EditablePanel", self)
    left:Dock(LEFT)
    left:SetWide(realW * 0.19)
    left:DockMargin(0, 0, margin, 0)

    // Back Header
    local backHeader = parent.header:Add("DButton")
    backHeader:Dock(LEFT)
    backHeader:SetPaintBackground(false)
    backHeader:SetFont("ahouse_32")
    backHeader:SetTextColor(ahouse.Config.Colors.White)
    backHeader:SetText(ahouse.lang.l.ui_back)
    backHeader:SetWide(left:GetWide())
    backHeader:SetContentAlignment(1)
    backHeader:SetAlpha(0)
    backHeader:AlphaTo(255, 0.25, 0.75)
    
    // Back Header
    local ownedHeader = parent.header:Add("DButton")
    ownedHeader:Dock(FILL)
    ownedHeader:SetPaintBackground(false)
    ownedHeader:SetFont("ahouse_32")
    ownedHeader:SetTextColor(ahouse.Config.Colors.White)
    ownedHeader:SetText(ahouse.lang.l.ui_manageproperty)
    ownedHeader:SetContentAlignment(1)
    ownedHeader:SetAlpha(0)
    ownedHeader:DockMargin(margin, 0, 0, 0)
    ownedHeader:AlphaTo(255, 0.25, 0.75)

    function backHeader:DoClick()
        parent:Unload()

        ownedHeader:AlphaTo(0, 0.25, 0, function(_, pnl)
            pnl:Remove()
        end)

        self:AlphaTo(0, 0.25, 0, function(_, pnl)
            pnl:Remove()
        end)
    end

    // Left Top
    local leftList = vgui.Create("DScrollPanel", left)
    leftList:Dock(FILL)

    local containerRight = vgui.Create("EditablePanel", self)
    containerRight:Dock(FILL)

    /*
        For jobs
    */
    local panels = {}

    for i, v in pairs(l) do
        local b = leftList:Add("DButton")
        b:DockPadding(buttonMargin*1.5, buttonMargin, buttonMargin, buttonMargin)
        b:Dock(TOP)
        b:SetText("")
        b:SetTall(buttonTall)
        b:DockMargin(0, !first and 0 or margin4, 0, 0)

        function b:Paint(w, h)
            self.forceanim = selectedHouse == i
            draw.RoundedBox(ahouse.GetCorner(), 0, 0, w, h,
                ahouse.UI.ColorTo(ahouse.Config.Colors.SubBackground, ahouse.Config.Colors.BlackGreen, self.perc))
        end

        table.insert(panels, {b, v.name})
    
        ahouse.UI.AddHoverTimer(b, 3)

        first = true

        local title = vgui.Create("DLabel", b)
        title:Dock(TOP)
        title:SetText(v.name)
        title:SetTextColor(ahouse.Config.Colors.White)
        title:SetFont("ahouse_16")
        title:SetTall(select(2, title:GetContentSize()))

        local formattedPrice = ahouse.HouseData.PropertyPrice(ply, i, nil, true)
        local price = vgui.Create("DLabel", b)
        price:Dock(TOP)
        price:SetText(formattedPrice)
        price:SetTextColor(ahouse.Config.Colors.White60)
        price:SetFont("ahouse_12")
        price:SetTall(select(2, price:GetContentSize()))
        // getHouseDoors(id)

        function b:DoClick()
            selectedHouse = i
            specificCam = nil
            ahouse.HouseData.Owned = ahouse.HouseData.Owned or {}

            containerRight:Clear()

            local coowner = vgui.Create("EditablePanel", containerRight)
            coowner:Dock(LEFT)
            coowner:SetWide(realW * 0.35)

            local title = vgui.Create("DLabel", coowner)
            title:SetText(ahouse.lang.l.coowners)
            title:Dock(TOP)
            title:SetFont("ahouse_16")
            title:SetTextColor(ahouse.Config.Colors.White60)

            local p = vgui.Create("ahouse_coowners", coowner)
            p:Dock(LEFT)
            p:SetWide(coowner:GetWide())

            p.Paint = function() end
            p:Build(i, true)
            p.Think = function() end

            local right = vgui.Create("EditablePanel", containerRight)
            right:Dock(RIGHT)
            right:SetWide(realW * 0.35)

            local containerTopRight = vgui.Create("EditablePanel", right)
            containerTopRight:Dock(TOP)
            containerTopRight:SetTall(realH * 0.5)

            local function createPropConfiguration()
                containerTopRight:Clear()
                local t2 = vgui.Create("DLabel", containerTopRight)
                t2:SetText(ahouse.lang.l.propconfig)
                t2:Dock(TOP)
                t2:SetFont("ahouse_16")
                t2:SetTextColor(ahouse.Config.Colors.White60)
                local configs = ahouse.UserConfigs[i] or {}

                for k, v in pairs(configs) do
                    local t = vgui.Create("DButton", containerTopRight)
                    t:SetText(v.name)
                    t:SetFont("ahouse_16")
                    t:SetPaintBackground(false)
                    t:SetTextColor(ahouse.Config.Colors.White60)
                    t:SetContentAlignment(4)
                    t:Dock(TOP)

                    local del = vgui.Create("DButton", t)
                    del:Dock(RIGHT)
                    del:SetFont("ahouse_Icon_12")
                    del:SetTextColor(ahouse.Config.Colors.White)
                    del:SetText("S")
                    del:SetVisible(false)
                    del:SetPaintBackground(false)
                    del:SetWide(del:GetContentSize())
    
                    function t:DoClick()
                        net.Start("ahouse_house_config")
                            net.WriteUInt(selectedHouse, 10)
                            net.WriteUInt(1, 4)
                            net.WriteUInt(k, 24)
                        net.SendToServer()
                    end

                    function t:Paint(w, h)
                        if self.perc != 0 then
                            t:SetTextColor(ahouse.UI.ColorTo(ahouse.Config.Colors.White60, ahouse.Config.Colors.White, self.perc))
                        end

                        del:SetVisible(self:IsChildHovered() or self:IsHovered())
                    end

                    function del:DoClick()
                        net.Start("ahouse_house_config")
                            net.WriteUInt(selectedHouse, 10)
                            net.WriteUInt(2, 4)
                            net.WriteUInt(k, 24)
                        net.SendToServer()
                    end
    
                    ahouse.UI.AddHoverTimer(t, 3)
                end
    
                if table.Count(configs) < 3 then
                    local create = vgui.Create("DButton", containerTopRight)
                    create:SetText(ahouse.lang.l.propconfig_new)
                    create:SetFont("ahouse_16")
                    create:SetTextColor(color_white)
                    create:SetPaintBackground(false)
                    create:SetContentAlignment(4)
                    create:Dock(TOP)
    
                    function create:DoClick()
                        parent.noquit = true
                        local p = vgui.Create("ahouse_AskInput")
                        p:SetTitle(ahouse.lang.l.propconfig_new)
                        p:SetTextButton(ahouse.lang.l.create)
                        p:CreateEntry(ahouse.lang.l.name, true, 4, 20)

                        function p:OnRemove()
                            if IsValid(parent) then
                                parent.noquit = false
                            end
                        end
            
                        p:SetCallback(function(but, p, ...)
                            local entries = {...}
                            local r = entries[1][2]

                            if !r or string.len(r) < 4 or string.len(r) > 20 then
                                entries[1][1]:SetText("Invalid length")
                                return
                            end
                
                            net.Start("ahouse_house_config")
                                net.WriteUInt(selectedHouse, 10)
                                net.WriteUInt(0, 4)
                                net.WriteString(r)
                            net.SendToServer()

                            if IsValid(parent) then
                                parent.noquit = false
                            end
                        end)
                    end
                end
            end
            createPropConfiguration()

            hook.Add("ahouse_ReceiveConfig", "refreshpanel", function()
                if !IsValid(containerTopRight) then return end
                createPropConfiguration()
            end)

            local t3 = vgui.Create("DLabel", right)
            t3:SetText(ahouse.lang.l.propconfig)
            t3:Dock(TOP)
            t3:SetFont("ahouse_16")
            t3:SetTextColor(ahouse.Config.Colors.White60)

            local rb = vgui.Create("DButton", right)
            rb:SetText("")
            rb:Dock(TOP)
            rb:SetFont("ahouse_16")
            rb:SetTextColor(ahouse.Config.Colors.White60)
            rb:SetContentAlignment(4)
            rb:SetTextInset(0, 0)
            rb:SetPaintBackground(false)

            function rb:Think()
                local b = ahouse.Config.Colors[v.disabledbell and "White60" or "White"]
                rb:SetTextColor(b)
                rb:SetText(ahouse.lang.l[v.disabledbell and "ringbell_off" or "ringbell_on"])
            end
            
            function rb:DoClick()
                net.Start("ahouse_house_config")
                    net.WriteUInt(i, 10)
                    net.WriteUInt(3, 4)
                net.SendToServer()
            end
        end
    end
end

function PANEL:Init() end

derma.DefineControl( "ahouse_property", "", PANEL, "EditablePanel" )