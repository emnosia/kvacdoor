// Flux shenanigans once again

local ScrH = ScrH
local ScrW = ScrW
local surface = surface
local createfonts = createfonts
local hook = hook

local w, h = ScrW(), ScrH()
local ratio_h = h / 1080
local ratio_w = w / 1920
local ratio = ratio_h < ratio_w and ratio_h or ratio_w
local cornerRes = ahouse.Config.RoundCorner * ratio

function ahouse.GetSize(n)
    return n * ratio
end

function ahouse.GetMargin(rat)
    return ahouse.GetSize(h*0.0333 * rat)
end

function ahouse.GetCorner()
    return cornerRes
end

// I searched 1h to debug this,
// https://github.com/Facepunch/garrysmod/blob/master/garrysmod/lua/includes/modules/draw.lua#L33-L49
// The cache doesn't reset when you change screen size ...
local CachedFontHeights = {}
function ahouse.getfontheight(font)
	if ( CachedFontHeights[ font ] != nil ) then
		return CachedFontHeights[ font ]
	end

	surface.SetFont( font )
	local w, h = surface.GetTextSize( "W" )
	CachedFontHeights[ font ] = h

	return h
end

local fontList = {
    {
        font = "Inter Bold",
        prefix = "ahouse_",
        size = {
            [-1] = {48, 32, 24, 20, 16, 12},
        },
    },

    {
        font = "Inter Bold",
        prefix = "ahouse_3D2D_",
        ["3D2D"] = true,
        size = {
            [-1] = {33, 64},
        },
    },


    {
        font = "Akulla_SVG1",
        prefix = "ahouse_Logo3D2D_",
        ["3D2D"] = true,
        size = {
            [-1] = {40, 25},
        },
    },

    {
        font = "Akulla_SVG1",
        prefix = "ahouse_Icon_",
        size = {
            [-1] = {64, 20, 24, 28, 12}
        }
    },
}

// antialias
function createfonts()
    for _, fontInfo in pairs(fontList) do
        for weight, sizeTable in pairs(fontInfo.size) do
            for _, size in ipairs(sizeTable) do
                local name = fontInfo.prefix .. size

                if weight != -1 then
                    name = name .. "_" .. weight
                end

                local _, err = pcall(function()
                    surface.CreateFont(name, {
                        antialias = true,
                        size = fontInfo["3D2D"] and size or ahouse.GetSize(size),
                        font = fontInfo.font,
                        underline = fontInfo.underline
                    })
                end)

                if err then
                    print("[AHouse] Couldn't load the font " .. name .. " composed of : " .. fontInfo.font)
                    skip = true
                    break
                end
            end
        end
    end
end

createfonts()

function ahouse.UI.GetScreen()
    return w, h
end

hook.Add("OnScreenSizeChanged", "ahouse_RefreshFont", function()
    w, h = ScrW(), ScrH()
    ratio_h = h / 1080
    ratio_w = w / 1920
    ratio = (ratio_h < ratio_w and ratio_h or ratio_w)
    createfonts()
    cornerRes = ahouse.Config.RoundCorner * ratio
end)