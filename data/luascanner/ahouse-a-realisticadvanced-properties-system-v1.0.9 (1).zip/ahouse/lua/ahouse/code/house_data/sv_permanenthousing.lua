ahouse.permanentHousing = ahouse.permanentHousing or {
    data = {},
}

hook.Add("ahouse_houseloaded", "permanent_properties", function()
    local t = os.time() - ahouse.Config.SellAfterInactivityDays * 24 * 60 * 60

    ahouse.SQL.query('DELETE FROM ahouse_permanentproperties WHERE time < ' .. os.time() .. ' OR lastconnection < ' .. t, function()
        ahouse.SQL.query('SELECT * FROM ahouse_permanentproperties, ahouse_houses WHERE ahouse_permanentproperties.house = ahouse_houses.houseid AND map = ' .. ahouse.SQL.escape(game.GetMap()), function(q)
            local l = {}

            for k, v in ipairs(q or {}) do
                l[tonumber(v.house)] = {
                    house = tonumber(v.house),
                    owner = v.owner,
                    time = tonumber(v.time)
                }
            end
    
            ahouse.permanentHousing.data = l
        end)
    end)
end)

hook.Add("ahouse_canbuy", "permanent_properties", function(ply, houseid, is_rent, price, first_door)
    local l = ahouse.permanentHousing.data[houseid]
    if l and l.time > os.time() and l.owner != ply:SteamID64() then
        return ""
    end
end)

local t = os.time()
hook.Add("ahouse_afterbuy", "permanent_properties", function(ply, houseid, is_rent, rent_time, skip_buy)
    if !ahouse.Config.PermanentHousing.Enabled or skip_buy then return end

    local time = os.time()
    local rel

    if is_rent then
        rel = ahouse.Config.RentTime * rent_time
    else
        rel = ahouse.Config.PermanentHousing.BuyTime
    end

    time = time + rel

    ahouse.permanentHousing.data[houseid] = {
        house = houseid,
        owner = ply:SteamID64(),
        time = time,
        relativeTime = rel,
    }

    local qu = 'INSERT INTO ahouse_permanentproperties(house, owner, time, lastconnection) VALUES(%s, "%s", %s, %s)'
    qu = string.format(qu, houseid, ply:SteamID64(), time, os.time())
    ahouse.SQL.query(qu)

    net.Start("ahouse_housedata")
        net.WriteUInt(7, 8)
        net.WriteUInt(1, 8)

        net.WriteUInt(houseid, 10)
        net.WriteUInt(rel, 20)
    net.Send(ply)
end)

timer.Create("RefreshAhouseProperties", 10, 0, function()
    if !ahouse.Config.PermanentHousing.Enabled then return end

    local t = os.time()
    for k, v in pairs(ahouse.permanentHousing.data) do
        if v.time < t then
            ahouse.permanentHousing.data[k] = nil
            ahouse.HouseData.Sell(ply, k)
        end
    end
end)

hook.Add("PlayerInitialSpawn", "ahouse_permanent_properties", function(ply)
    // Wait a bit, we need darkrp to initialize
    timer.Simple(5, function()
        local l = {}
        for k, v in pairs(ahouse.permanentHousing.data) do
            if v.owner == ply:SteamID64() then
                ahouse.HouseData.Buy(ply, k, true, false, true)
                v.relativeTime = v.time - t
                l[k] = v
            end
        end

        ahouse.SQL.query('UPDATE ahouse_permanentproperties SET lastconnection = ' .. os.time() .. " WHERE owner = '" .. ply:SteamID64() .. "'")

        if ahouse.Config.PermanentHousing.Enabled then
            net.Start("ahouse_housedata")
                net.WriteUInt(7, 8)
                net.WriteUInt(table.Count(l), 8)

                for k, v in pairs(l) do
                    net.WriteUInt(k, 10)
                    net.WriteUInt(v.relativeTime, 20)
                end
            net.Send(ply)
        end
    end)
end)

hook.Add("ahouse_sell", "removeperm", function(ply, id)
    ahouse.permanentHousing.data[id] = nil

    net.Start("ahouse_housedata")
        net.WriteUInt(8, 8)
        net.WriteUInt(id, 10)
    net.Send(ply)
    ahouse.SQL.query('DELETE FROM ahouse_permanentproperties WHERE house = ' .. id)
end)