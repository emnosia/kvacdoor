// ONLY USE IT WHEN WE ARE AROUND THE PROPERTY IF CLIENTSIDE
local doorsIDs = {}
local function getHouseDoors(id)
    if !ahouse.HouseData.List[id] then return end
    doorsIDs[id] = {}

    local infoTable = ahouse.HouseData.List[id]

    // Seems like FindInBox doesn't return dormant entities ?
    // But they won't move, since these are doors
    for k, v in ipairs(ents.GetAll()) do
        local p = v:GetPos()

        if p:WithinAABox(infoTable.vecs[1], infoTable.vecs[2]) then
            if !ahouse.HouseData.IsDoor(v) then continue end
            table.insert(doorsIDs[id], v)
            v.ahouse_groupID = id
        end
    end
end
ahouse.doorIDs = doorsIDs

local function refreshDoors()
    if ahouse.HouseData.List then
        for k, v in pairs(ahouse.HouseData.List) do
            getHouseDoors(k)
        end
    end
end

hook.Add("OnReloaded", "ahouse_refreshdooors", refreshDoors)
hook.Add("OnCleanup", "ahouse_refreshdoors", refreshDoors)
hook.Add("ahouse_houseloaded", "ahouse_refreshdoors", refreshDoors)
hook.Add("ahouse_inithouse", "load_doors", function(id)
    getHouseDoors(id)
end)

hook.Add("PostCleanupMap", "ahouse_refreshOnCleanup", function()
    if ahouse.HouseData.List then
        for k, v in pairs(ahouse.HouseData.List) do
            hook.Run("ahouse_inithouse", k)
        end
    end
end)

refreshDoors()

// Create entity
function ahouse.HouseData.GetDoors(id)
    local doors = doorsIDs[id]

    if !doors or table.IsEmpty(doors) then
        getHouseDoors(id)
    end

    return doorsIDs[id] or {}
end

function ahouse.HouseData.SafeLoop(id, func)
    for k, v in ipairs(ahouse.HouseData.GetDoors(id)) do
        if IsValid(v) then
            func(v)
        end
    end
end

local tbl = {
    ["func_door"] = true,
    ["func_door_rotating"] = true,
    ["prop_door_rotating"] = true
}

function ahouse.HouseData.IsDoor(ent)
    return tbl[ent:GetClass()]
end

function ahouse.HouseData.PropertyPrice(ply, id, rent_price, format, count, addMoney)
    local p = ahouse.HouseData.List[id][rent_price and "rent_price" or "price"] * (ahouse.Config.DiscountRanks[ply:GetUserGroup()] or 1)
    p = p * GetGlobalFloat("ahouse_float", 1)
    addMoney = addMoney or 0

    if rent_price and count then
        p = p * count
    end

    if !format then return p + addMoney end
    p = p + addMoney

    local m = DarkRP.formatMoney(math.floor(p))
    if !rent_price then
        return m
    end

    if count then
        return ahouse.FormatLanguage("format_withdays", m, ahouse.UI.DominantFormatTime(ahouse.Config.RentTime * (count or 1)))
    else
        return m .. "/" .. ahouse.UI.DominantFormatTime(ahouse.Config.RentTime)
    end
end

function ahouse.HouseData.FirstSafeDoor(id)
    for k, v in ipairs(ahouse.HouseData.GetDoors(id)) do
        if IsValid(v) then
            return v
        end
    end
end

function ahouse.HouseData.VecInHouse(id, pos)
    local data = ahouse.HouseData.List[id].vecs

    return pos:WithinAABox(data[1], data[2])
end

function ahouse.HouseData.GetEntsInHouse(id, filter)
    local data = ahouse.HouseData.List[id].vecs
    if !filter then
        return ents.FindInBox(data[1], data[2])
    end

    local t = {}
    for k, v in ipairs(ents.FindInBox(data[1], data[2])) do
        if filter(v) then
            table.insert(t, v)
        end
    end

    return t
end