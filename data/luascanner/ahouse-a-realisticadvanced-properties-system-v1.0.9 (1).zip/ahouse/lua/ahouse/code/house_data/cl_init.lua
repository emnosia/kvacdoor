net.Receive("ahouse_housedata", function()
    local uid = net.ReadUInt(8)

    if uid == 0 or uid == 1 then
        if uid == 0 then
            ahouse.HouseData.List = {}
            ahouse.HouseData.EntToHouse = {}
        else
            ahouse.HouseData.EntToHouse = ahouse.HouseData.EntToHouse or {}
            ahouse.HouseData.List = ahouse.HouseData.List or {}
        end

        ahouse.HouseData.Owned = ahouse.HouseData.Owned or {}

        for i = 1, (uid == 1 and 1 or net.ReadUInt(10)) do
            local t = ahouse.HouseData.ReadHouseStruct()

            if !t then continue end

            local totalTime = 0
            for k, v in ipairs(t.viewList) do
                totalTime = totalTime + v.rendertime
            end
            t.totalViewTime = totalTime

            ahouse.HouseData.List[t.houseid] = t

            for k, v in pairs(t.ents or {}) do
                ahouse.HouseData.EntToHouse[k] = t
            end
        end
    elseif uid == 2 then
        // For UI display, else we can't know the owner without atleast
        // One pvs, I wanted to wait the PVS sent after chosing a property
        // however. On high ping servers, it would wait ~150ms to render
        ahouse.HouseData.Owned = ahouse.HouseData.Owned or {}
        ahouse.HouseData.Owned[net.ReadUInt(10)] = net.ReadEntity()
    elseif uid == 3 then
        ahouse.HouseData.Owned = ahouse.HouseData.Owned or {}
        ahouse.HouseData.Owned[net.ReadUInt(10)] = nil
    elseif uid == 4 then
        local id = net.ReadUInt(10)
        local tbl = ahouse.HouseData.List[id]

        if !tbl then return end

        tbl.name = net.ReadString()
        tbl.rent_price = net.ReadUInt(24)
        tbl.price = net.ReadUInt(24)
        tbl.type = net.ReadUInt(2)
        tbl.have_alarm = net.ReadBool()
    elseif uid == 5 then
        local id = net.ReadUInt(10)

        ahouse.HouseData.List[id] = nil
        ahouse.HouseData.EntToHouse[id] = nil
    elseif uid == 6 then
        ahouse.HouseData.List[net.ReadUInt(10)].disabledbell = net.ReadBool()
    elseif uid == 7 then
        ahouse.UserProperties = ahouse.UserProperties or {}

        for i=1, net.ReadUInt(8) do
            local id = net.ReadUInt(10)

            ahouse.UserProperties[id] = {
                house = id,
                time = net.ReadUInt(20)
            }
        end
    elseif uid == 8 then
        ahouse.UserProperties = ahouse.UserProperties or {}
        ahouse.UserProperties[net.ReadUInt(10)] = nil
    end
end)

function ahouse.HouseData.ReadHouseStruct()
    if !net.ReadBool() then return end

    local t = {
        houseid = net.ReadUInt(10),
        name = net.ReadString(),
        price = net.ReadUInt(32),
        rent_price = net.ReadUInt(32),
        type = net.ReadUInt(2),
        viewList = {},
        ents = {},
    }

    for i = 1, net.ReadUInt(3) do
        local renderorder = net.ReadUInt(8)
        t.viewList[renderorder] = {
            renderorder = renderorder,
            pos = net.ReadVector(),
            ang = net.ReadAngle(),
            endpos = net.ReadVector(),
            endang = net.ReadAngle(),
            rendertime = net.ReadUInt(8)
        }

        if t.viewList[renderorder].pos:Distance(t.viewList[renderorder].endpos) < 200 then
            t.viewList[renderorder].no_move = true
        end
    end

    for i = 1, net.ReadUInt(3) do
        t.ents[net.ReadUInt(13)] = true
    end

    t.firstDoorIndex = net.ReadUInt(13)

    t.disabledbell = net.ReadBool()
    t.vecs = {
        net.ReadVector(),
        net.ReadVector()
    }

    t.have_alarm = net.ReadBool()

    return t
end

net.Receive("ahouse_plyconfig", function()
    ahouse.plyconfig = ahouse.plyconfig or {}
    ahouse.plyconfig.ringbell = net.ReadUInt(5)
end)

hook.Add("HUDDrawDoorData", "ahouse_preventdoormeta", function(ent)
    if ahouse.HouseData.IsDoor(ent) and ahouse.Config.HideOwnerOnDoors and ent:isKeysOwned() then
        return true
    end
end)