hook.Add("ahouse_inithouse", "doorbell", function(id)
    local l = ahouse.HouseData.List[id]
    if !l then return end
    
    // Shouldn't happens
    if IsValid((l.ents or {}).doorbell) then
        l.ents.doorbell:Remove()
    end

    if l.rPos then
        local e = ents.Create("ahouse_intercom")
        e:SetAngles(Angle(0, l.rAng, 0))
        e:SetPos(l.rPos)

        e:SetPos(e:LocalToWorld(e:GetAngles():Forward()))
        e:Activate()
        e:Spawn()

        l.ents = l.ents or {}
        l.ents.doorbell = e

        e.houseid = id
    end
end)