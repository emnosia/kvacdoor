net.Receive("ahouse_doorholes", function()
    local realHole = net.ReadEntity()
    local door = net.ReadEntity()

    if !IsValid(realHole) then
        net.Start("ahouse_doorholes")
        net.SendToServer()
        return
    end

    local cam_x = 0
    local cam_y = 0

    local ply = LocalPlayer()

    hook.Add("PreDrawViewModel", "ahouse_hole", function() return true end)
    hook.Add("DrawPhysgunBeam", "ahouse_hole", function() return false end)

    local a = ply:EyeAngles()
    hook.Add("CreateMove", "ahouse_hole", function(cmd)
        if cmd:KeyDown(IN_ATTACK) or cmd:KeyDown(IN_ATTACK2) or !IsValid(realHole) or ply:GetEyeTrace().Entity != realHole then
            hook.Remove("CreateMove", "ahouse_hole")
            hook.Remove("PreDrawViewModel", "ahouse_hole")
            hook.Remove("DrawPhysgunBeam", "ahouse_hole")
            hook.Remove("CalcView", "ahouse_hole")
            hook.Remove("RenderScreenspaceEffects", "ahouse_hole")
            hook.Remove("HUDPaint", "ahouse_hole")

            net.Start("ahouse_doorholes")
            net.SendToServer()

            return
        else
            cam_x = math.Clamp(cam_x + cmd:GetMouseY() / 40, -15, 15)
            cam_y = math.Clamp(cam_y + cmd:GetMouseX() / 40 * -1, -15, 15)
            cmd:SetViewAngles(a)
            cmd:ClearMovement()
            cmd:ClearButtons()
        end
    end)

    local cpy = door:WorldToLocal(realHole:GetPos() + realHole:OBBCenter())
    local diff = Vector(cpy.x, cpy.y, cpy.z)

    local a = realHole:GetAngles()
    a:RotateAroundAxis(a:Up(), 0)
    a:RotateAroundAxis(a:Right(), 270)

    hook.Add("CalcView", "ahouse_hole", function(ply, origin, angles, fov)
        local a = realHole:GetAngles()
        a:RotateAroundAxis(a:Up(), 180)

        return {
            // Flip this like a burger to get the other side of the door
            origin = door:LocalToWorld(diff) + a:Forward() * 10,
            angles = a + Angle(cam_x, cam_y, 0),
            drawviewer = false,
        }
    end)

    hook.Add( "RenderScreenspaceEffects", "ahouse_hole", function()
        DrawMaterialOverlay( "models/props_c17/fisheyelens", -0.06 )
    end)

    local circle = ahouse.UI.CachedCircle(ScrW() / 2, ScrH() / 2, ScrH() / 2, 90)

    hook.Add( "HUDPaint", "ahouse_hole", function()
        ahouse.StartStencil()
            surface.SetDrawColor(1, 1, 1, 1)
            draw.NoTexture()
            surface.DrawPoly(circle)
        ahouse.ReplaceStencil(0)
            surface.SetDrawColor(color_black)
            surface.DrawRect(0, 0, ScrW(), ScrH())
        ahouse.EndStencil()
    end)
end)