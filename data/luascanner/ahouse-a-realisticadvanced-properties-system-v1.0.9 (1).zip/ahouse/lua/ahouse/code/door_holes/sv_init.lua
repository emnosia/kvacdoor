ahouse.doorsHoles = ahouse.doorsHoles or {}

util.AddNetworkString("ahouse_doorholes")

local doorsModel = {}

// Remove vision
net.Receive("ahouse_doorholes", function(_, ply)
    ply.ahouse_doorhole = nil
end)

local function getHolePos(e)
    // Calculate 3D2D pos
    if doorsModel[e:GetPos()] then
        return doorsModel[e:GetPos()]
    end

    local size = e:OBBMaxs() - e:OBBMins()
    local pts

    if size.z < size.x and size.z < size.y then
        pts = e:GetUp() * size.z
        sideSize = size.y
    elseif size.y < size.x then
        pts = e:GetRight() * size.y
        sideSize = size.x
    else
        pts = e:GetForward() * size.x
        sideSize = size.y
    end

    doorsModel[e:GetPos()] = pts
    return pts
end

ahouse.doorsHoles.GetHolePos = getHolePos

local function initDoorHole(ent, is_front)
    for k, v in ipairs(ent.ahouse_doorhole or {}) do
        if IsValid(v) then
            v:Remove()
            return
        end
    end

    ent.ahouse_doorhole = {}

    local dPos = getHolePos(ent)
    local rPos = ent:OBBCenter()
    is_front = is_front and 1 or -1

    for i = -1, 1, 2 do
        local p = Vector(dPos) * i

        local tr = util.TraceLine({
            start = ent:LocalToWorld(rPos) + p,
            endpos = ent:LocalToWorld(rPos),
        })

        local p2 = tr.HitPos + p:GetNormalized()

        local a = tr.Normal:Angle()
        a:RotateAroundAxis(a:Up(), 180)

        // Fix height
        p2.z = ent:LocalToWorld(ent:OBBMins()).z + 64

        local hole = ents.Create("ahouse_hole")
        hole:SetPos(p2)
        hole:SetAngles(a)
        hole:SetParent(ent)
        hole:Activate()
        hole.active = is_front == i
        hole:Spawn()

        table.insert(ent.ahouse_doorhole, hole)
        hole.ahouse_pairPos = dPos * (i * -1)
        hole.ahouse_door = ent
    end
end

ahouse.ent = initDoorHole

function ahouse.doorsHoles.AddDoor(ent, relativePos)
    if ent.ahouse_doorhole then return end

    local front = getHolePos(ent)

    local is_front = relativePos:DistToSqr(ent:LocalToWorld(front)) < relativePos:DistToSqr(ent:LocalToWorld(-front))

    ahouse.SQL.query('INSERT INTO ahouse_doorholes(map, mapid, is_front) VALUES("' .. game.GetMap() .. '",' .. ent:MapCreationID() .. ', ' .. (is_front and 1 or 0) .. ')')

    initDoorHole(ent, is_front)
end

function ahouse.doorsHoles.RemoveDoor(ent)
    if !ent.ahouse_doorhole then return end

    ahouse.SQL.query('DELETE FROM ahouse_doorholes WHERE map = "' .. game.GetMap() .. '" AND mapid = ' .. ent:MapCreationID())

    for k, v in ipairs(ent.ahouse_doorhole or {}) do
        if IsValid(v) then
            v:Remove()
        end
    end

    ent.ahouse_doorhole = nil
end

hook.Add("ahouse_houseloaded", "doorholes", function()
    ahouse.SQL.query('SELECT mapid, is_front FROM ahouse_doorholes WHERE map = "' .. game.GetMap() .. '"', function(q)
        for k, v in ipairs(q or {}) do
            local e = ents.GetMapCreatedEntity(v.mapid)
            if IsValid(e) then
                initDoorHole(e, tobool(tonumber(v.is_front)))
            end
        end
    end)
end)

hook.Add("PhysgunPickup", "ahouse_holes", function(ply, ent)
    if ent:GetClass() == "ahouse_hole" then
        return false
    end
end)