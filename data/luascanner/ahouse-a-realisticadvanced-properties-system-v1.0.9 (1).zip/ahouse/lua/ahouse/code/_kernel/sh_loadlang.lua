ahouse.lang.StrToID = {}
ahouse.lang.IDToStr = {}

for k, v in pairs(ahouse.lang.l) do
	local place = #ahouse.lang.IDToStr + 1
	ahouse.lang.IDToStr[place] = k
	ahouse.lang.StrToID[k] = place
end

function ahouse.FormatLanguage(info, ...)
    local str = ahouse.lang.IDToStr[info] or info

    if !ahouse.lang.l[str] then
        print("[AHouse] Not found: " .. str)
        return "[AHouse] Not found: " .. str
    else
        return string.format(ahouse.lang.l[str], ...)
    end
end