ahouse.SQL = ahouse.SQL or {}
local db

if ahouse.SQL.db then
    db = ahouse.SQL.db
end

local function q(q, c)
    if !ahouse.Config.MySQL.enable then
        sql.m_strError = nil
        local d = sql.Query(q)

        if sql.m_strError then
            print("[AHouse] SQLite error: " .. sql.m_strError)
        end
        if c then
            c(d)
            return
        end
    else
        if db:status() != mysqloo.DATABASE_CONNECTED then
            print("[AHouse] Unexcepted MySQL Behavior, query without connection/internal error, query will wait the connection")
        else
            local db_query = db:query(q)

            function db_query:onSuccess(data)
                if c then
                    data = !table.IsEmpty(data) and data or nil
                    c(data, self)
                end
            end

            function db_query:onError(err, s)
                if !string.find(err, "Duplicate column name") then
                    debug.Trace()
                    print("[AHouse] SQL Error: ", err, s)
                else
                    print("[AHouse] SQL Error: ", err, s)
                end
            end

            db_query:start()
            return db_query
        end
    end
end

local function createTables()
    q([[
        CREATE TABLE IF NOT EXISTS `ahouse_houses` (
            `houseid` INTEGER PRIMARY KEY ]] .. (ahouse.Config.MySQL.enable and "AUTO_INCREMENT" or "AUTOINCREMENT") .. [[,
            `name` text NOT NULL,
            `map` text NOT NULL,
            `price` INTEGER NOT NULL,
            `rent_price` INTEGER NOT NULL,
            `type` INTEGER,
            `rpos_x` INTEGER,
            `rpos_y` INTEGER,
            `rpos_z` INTEGER,
            `rang` INTEGER,
            `display_pos_x` INTEGER,
            `display_pos_y` INTEGER,
            `display_pos_z` INTEGER,
            `display_ang` INTEGER,
            
            `letterbox_pos_x` INTEGER,
            `letterbox_pos_y` INTEGER,
            `letterbox_pos_z` INTEGER,
            `letterbox_ang` INTEGER,
            `letterbox_ground` INTEGER,

            `min_x` INTEGER NOT NULL,
            `min_y` INTEGER NOT NULL,
            `min_z` INTEGER NOT NULL,

            `max_x` INTEGER NOT NULL,
            `max_y` INTEGER NOT NULL,
            `max_z` INTEGER NOT NULL,

            `have_alarm` INTEGER
        );

        CREATE TABLE IF NOT EXISTS `ahouse_doorholes` (
            `map` text NOT NULL,
            `mapid` INTEGER,
            `is_front` INTEGER
        );

        CREATE TABLE IF NOT EXISTS `ahouse_playerinfos` (
            `owner` TEXT NOT NULL,
            `ringbell_id` INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS `ahouse_viewpoints` (
            `vp_x` INTEGER NOT NULL,
            `vp_y` INTEGER NOT NULL,
            `vp_z` INTEGER NOT NULL,

            `vp_a_r` INTEGER NOT NULL,
            `vp_a_y` INTEGER NOT NULL,
            `vp_a_p` INTEGER NOT NULL,
                
            `vp_f_x` INTEGER NOT NULL,
            `vp_f_y` INTEGER NOT NULL,
            `vp_f_z` INTEGER NOT NULL,

            `vp_fa_r` INTEGER NOT NULL,
            `vp_fa_y` INTEGER NOT NULL,
            `vp_fa_p` INTEGER NOT NULL,

            `rendertime` INTEGER,
            `renderorder` INTEGER,
            `house` INTEGER,
            FOREIGN KEY (house) REFERENCES ahouse_houses(houseid) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS `ahouse_playerhouseprops` (
            `owner` TEXT NOT NULL,
            `name` text NOT NULL,
            `configid` INTEGER PRIMARY KEY ]] .. (ahouse.Config.MySQL.enable and "AUTO_INCREMENT" or "AUTOINCREMENT") .. [[,
            `house` INTEGER,
            FOREIGN KEY (house) REFERENCES ahouse_houses(houseid) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS `ahouse_playerprops` (
            `x` INTEGER NOT NULL,
            `y` INTEGER NOT NULL,
            `z` INTEGER NOT NULL,

            `a_r` INTEGER NOT NULL,
            `a_y` INTEGER NOT NULL,
            `a_p` INTEGER NOT NULL,

            `model` text NOT NULL,

            `configid` INTEGER NOT NULL,
            FOREIGN KEY (configid) REFERENCES ahouse_playerhouseprops(configid) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS `ahouse_permanentproperties` (
            `house` INTEGER,
            `owner` TEXT NOT NULL,
            `lastconnection` BIGINT NOT NULL,
            `time` BIGINT NOT NULL,
            FOREIGN KEY (house) REFERENCES ahouse_houses(houseid) ON DELETE CASCADE
        );
    ]], function()
        ahouse.HouseData.Load()
    end)
end

local function escape(str)
    return (ahouse.MySQL and mysqloo) and ("'" .. db:escape(str) .. "'") or SQLStr(str)
end

local function conn()
    if db then return end

    if !ahouse.Config.MySQL or !ahouse.Config.MySQL.enable then
        print("[AHouse] Connected to SQLite")
        createTables()
        return
    end

    require("mysqloo")
    if !mysqloo then
        print("[AHouse] Couldn't load the mysqloo module, will prevent the addon from loading.")
        return
    end

    local d = mysqloo.connect(ahouse.Config.MySQL.host, ahouse.Config.MySQL.user,
    ahouse.Config.MySQL.password, ahouse.Config.MySQL.database, ahouse.Config.MySQL.port or 3306)

    function d:onConnectionFailed(err)
        print("[AHouse] Failed DB Connection, error : " .. err)
        print("[AHouse] Failed MySQL connection, will prevent the addon from loading. Error: ", err)
        return
    end

    function d:onConnected()
        print("[AHouse] Connected to MYSQL")
        createTables()
    end

    db = d
    d:connect()
    d:wait()
end

hook.Add("ahouse_loaded", "load_data", conn)

ahouse.SQL = {
    query = q,
    escape = escape
}