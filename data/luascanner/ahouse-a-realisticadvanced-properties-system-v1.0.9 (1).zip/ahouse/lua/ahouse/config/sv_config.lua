ahouse.Config = ahouse.Config or {}

/*
	Your MYSQL credentials, you don't need to touch this part if you don't know what mysql is
*/
ahouse.Config.MySQL = {
	enable = false,
	host = "127.0.0.1",
	user = "root",
	password = "",
	database = "akulla",
	port = 3306
}

/*
	Avoid using the mailbox system on certain entity categories
*/
ahouse.Config.DeliveryBox = {
	["Ammo"] = true,
	["Entity"] = true,
	["Shipment"] = true,
	["Pistol"] = true,
}

/*
	Delay between each use of ringbell/intercom
*/
ahouse.Config.IntercomWaitTime = 5

/*
	Do we put the co-owners in co-owners directly or they will have to do F2 on the doors
*/
ahouse.Config.NoForceOwner = false

/*
	0 = Everybody can spawn prop anywhere
	1 = Can't spawn props in others players houses
	2 = Can't spawn prop if it's not in his own houses
*/

ahouse.Config.LimitPropSpawnToHouse = 0

/*
	Rank that can avoid the limit above
*/
ahouse.Config.BypassPropLimiter = {
    ["superadmin"] = false
}

// Chat command, used with ! or / in front of the command
ahouse.Config.Command = "ahouse"

// Hide NPCs if there a player in the seller jobs. Related to ahouse.Config.Jobs
ahouse.Config.HideNPCOnSeller = true

// If true, player can't buy a door from any house with F2 or the 3D2D, he need to use the
// ahouse UI
ahouse.Config.BlockDirectBuy = false

// If false, only estate seller can use the chat command
ahouse.Config.AllowCommandUI = true

// The maximum distance a vendor can be from the printer
ahouse.Config.MaxDistToPrinter = 500

// How many properties can the players have?
ahouse.Config.MaxProperties = 1

// Shall we put the prices on rotation ?
ahouse.Config.RotatePrice = {
	Enabled = true, // Self-explaining
	Time = 3600, // How long do we wait to rotate (in seconds)
	Min = 0.95, // Min percent of the original price
	Max = 1.1 // Max percent of the original price
}

// Entities we won't put in the mailbox
ahouse.Config.Mailbox_Whitelist = {
	// ["money_printer"] = true,
}

/*
	How long do we wait before removing the properties of inactive players?
	This value is in days
*/
ahouse.Config.SellAfterInactivityDays = 3