ahouse.lang = {}

local l = {
    cantBuy = "You cannot buy this property",
    alreadyowned = "One person already owns this property",
    toomuchProperties = "You have too many residences",
    startPhrase = "Everyone deserves a home,",
    startPhrase2 = "Get yours today !",

    home_settings = "Options",
    home_settings_desc = "Change your settings",

    home_buy = "Buy, Sell, Rent",
    home_buy_desc = "It's free real estate",

    home_manage = "Manage your property",
    home_manage_desc = "Done with doorbell parties ?",

    printer_away = "Printer is too far away",
    printer_already = "The printer is already printing a contract",
    printer_toomuch = "You must wait for a contract to disappear (90sec)",

    rent_price = "%s every %s",

    contrat_notyours = "This contract does not concern you",
    NPCName = "Real Estate Salesman",
    gotonpc = "Please speak with a real estate salesperson to purchase this residence",

    closed_doors = "You have closed the doors of your residence",
    open_doors = "You have opened the doors of your residence",

    property_0 = "House",
    property_1 = "Apartment",
    property_2 = "Building",

    ringbell = "Doorbell",
    ringbell_on = "Doorbell on",
    ringbell_off = "Doorbell off",
    alldoors = "Doors",
    close = "Close",
    open = "Open",

    contract_finish = "Finalize the contract",
    contract_finishbad = "Refuse the contract",
    contract_title = "REAL ESTATE SALES CONTRACT",
    contract_purchase = "PURCHASE OFFER",
    contract_date = "DATE:",
    contract_draw = "Witness the buyer's signature (Sign to confirm agreement!)",

    format_withdays = "%s for %s",

    alarm_with = "With alarm",
    alarm_without = "Without alarm",

    ui_back = "Back to home",
    ui_manageproperty = "Manage your properties",
    ui_extra = "How many more days to rent",
    ui_rentdays = "How many days to rent",
    ui_gps = "Activate GPS ( 5 minutes )",
    printcontract = "Print contract",
    contract_options = "Contract options",
    contract_commission = "Your commission (less than the price of the property)",
    re_rent = "Re-rent",
    search = "Search",
    coowners = "Co-Owners",
    propconfig = "Prop configuration",
    propconfig_new = "New configuration",
    name = "Name",
    create = "Create",
    timeday = "Days (=%s) ( Between 1 and %s )",
    invalid_value = "Invalid value",
    price_inferior = "The price must be less than %s",

    buy = "Buy",
    rent = "Rent",
    direct_buy = "Direct buy",
    renting = "Renting",
    sell = "Sell",
    property_of = "Property of %s",

    blogs_alarm = "{1} used the alarm of the property %s",
    blogs_printer = "{1} printed a contract",
    blogs_buy = "{1} purchased the property %s",
    blogs_sell = "{1} sold the property %s",
    blogs_coowners_add = "{1} added {2} to the property %s",
    blogs_coowners_remove = "{1} removed {2} from the property %s",

    notif_noplayers = "No players to add as co-owners",

    propspawn_1 = "You can't spawn props outside your properties",
    propspawn_2 = "You can't spawn props in other people's properties",

    // This is markup, DON'T TRANSLATE font and colour
    contract = [[
<font=ahouse_12><colour=0,0,0>
Name of Buyer(s): <font=ahouse_12>%s</font>
Name of Seller(s): <font=ahouse_12>%s</font>

Buyer(s), whether one or more, hereby agrees to purchase and, Seller(s), whether one or more, hereby agrees to sell the following described real estate "%s"

The property agreed to be sold includes heating and cooling system, door bells, mantels, mailboxes, fire screens, water heaters, plumbing fixtures, light fixtures, ceiling fans, wall to wall carpeting, built-in appliances, fences, outbuildings, tree, shrubbery, window coverings, and window hardware, if any, on the premises at the execution of this contract.

<font=ahouse_16>1. PURCHASE PRICE</font>
The total purchase price of the property shall be %s

if the earnest money check is not honored by the Buyer's bank, the Buyer(s) agrees to make the check good within two business days, and to pay a handling charge to the listing broker of the maximum allowed by law. Upon failure to do so, this contract shall become voidable and the listing broker and Seller(s) may pursue remedies against the Buyer(s) which are available under law.

<font=ahouse_16>2. FINANCING:</font>
Buyer will pay cash or obtain a loan for the Property with no financing contingency.

<font=ahouse_16>3. CONTRACT ENTIRE AGREEMENT</font>
This contract constitutes the entire agreement between Buyer and Seller regarding the Property, and supersedes all prior discussions, negotiations and agreements between Buyer and Seller, whether oral or written. Neither Buyer, Seller, nor any broker or sales associate shall be bound by any understanding, agreement, promise or representation concerning the Property, expressed or implied, not specified herein. Time is of the essence. All parties are advised to seek the advice of legal counsel about any of the terms hereof which may not be understood, prior to signing the Contract. By signing this Contract, the parties acknowledge that they understand this agreement creates legal obligations as well as legal rights which can be enforced in a court of law. THIS DOCUMENT IS INTENDED TO BE A LEGALLY BINDING CONTRACT. ( Once signed, this document is a legally binding contract.)
</colour></font>
    ]]
}

ahouse.lang.l = l