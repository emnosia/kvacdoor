ahouse.lang = {}

local l = {
    cantBuy = "Du kannst diese Immobilie nicht kaufen",
    alreadyowned = "Eine Person besitzt diese Immoblilie bereits",
    toomuchProperties = "Du hast zu viele Wohnsitze",
    startPhrase = "Jeder verdient ein Zuhause,",
    startPhrase2 = "Hol dir deins noch heute !",

    home_settings = "Optionen",
    home_settings_desc = "Änder deine Einstellungen",

    home_buy = "Kaufen, Verkaufen, Mieten",
    home_buy_desc = "It's free real estate", -- | Wouldn't recommend translating this since its a common Meme

    home_manage = "Verwalte deine Immobilie",
    home_manage_desc = "Done with doorbell parties ?",

    printer_away = "Der Drucker ist zu weit entfernt",
    printer_already = "Der Drucker druckt bereits einen Vertrag",
    printer_toomuch = "Warte bis der Vertrag verschwunden ist (90sek)",

    rent_price = "%s jede %s",

    contrat_notyours = "Dieser Vertrag geht dich nichts an",
    NPCName = "Immobilienmakler",
    gotonpc = "Sprich mit einem Immobilienmakler um diese Immobilie zu kaufen",

    closed_doors = "Du hast die Türen der Immobilie geschlossen",
    open_doors = "Du hast die Türen der Immobilie geöffnet",

    property_0 = "Haus",
    property_1 = "Wohnung",
    property_2 = "Gebäude",

    ringbell = "Klingel",
    ringbell_on = "Klingel an",
    ringbell_off = "Klingel aus",
    alldoors = "Türen",
    close = "Schließen",
    open = "Öffnen",

    contract_finish = "Vertrag abschließen",
    contract_finishbad = "Vertrag ablehnen",
    contract_title = "IMMOBILIENVERKAUFSVERTRAG",
    contract_purchase = "KAUFANGEBOT",
    contract_date = "DATUM:",
    contract_draw = "Unterschrift des Käufers (Unterschreiben um den Vertrag abzuschließen!)",

    format_withdays = "%s für %s",

    alarm_with = "mit Alarm",
    alarm_without = "ohne Alarm",

    ui_back = "Zurück zu Home",
    ui_manageproperty = "Verwalte deine Immobilien",
    ui_extra = "Wie viele Tage länger mieten",
    ui_rentdays = "Wie viele Tage mieten",
    ui_gps = "GPS aktivieren ( 5 minuten )",
    printcontract = "Vertrag ausdrucken",
    contract_options = "Vertrag optionen",
    contract_commission = "Deine Provision (weniger als der Preis der Immobilie)",
    re_rent = "Erneut Mieten",
    search = "Suchen",
    coowners = "Miteigentümer",
    propconfig = "Prop Konfiguration",
    propconfig_new = "Neue Konfiguration",
    name = "Name",
    create = "Erstellen",
    timeday = "Tage (=%s) ( Zwischen 1 und %s )",
    invalid_value = "Ungültiger Wert",
    price_inferior = "Der Preis muss weniger als %s sein",

    buy = "Kaufen",
    rent = "Mieten",
    direct_buy = "Direkt Kaufen",
    renting = "Mieten",
    sell = "Verkaufen",
    property_of = "Immobilie von %s",

    blogs_alarm = "{1} benutzte den Alarm des Grundstücks %s",
    blogs_printer = "{1} hat einen Vertrag gedruckt",
    blogs_buy = "{1} hat die Immobilie %s gekauft",
    blogs_sell = "{1} hat die Immobilie %s verkauft",
    blogs_coowners_add = "{1} hat {2} zu der Immobilie %s hinzugefügt",
    blogs_coowners_remove = "{1} hat {2} von der Immobilie %s entfernt",

    notif_noplayers = "Keine Spieler zum hinzufügen gefunden",

    propspawn_1 = "Du kannst keine Props außerhalb deiner Immobilien spawnen",
    propspawn_2 = "Du kannst keine Props in Immobilien von anderen Leuten spawnen",

    // This is markup, DON'T TRANSLATE font and colour
    contract = [[
<font=ahouse_12><colour=0,0,0>
Name des Käufers: <font=ahouse_12>%s</font>
Name des Verkäufers: <font=ahouse_12>%s</font>

Käufer, ob einer oder mehrere, erklären sich hiermit einverstanden, und Verkäufer, ob einer oder mehrere, erklären sich hiermit einverstanden, die nachfolgend beschriebenen Immobilien zu verkaufen: "%s"

Die zu verkaufende Immobilie umfasst Heiz- und Kühlsysteme, Türklingeln, Kaminsimse, Briefkästen, Feuerschutzgitter, Warmwasserbereiter, Sanitärarmaturen, Beleuchtungskörper, Deckenventilatoren, Teppichböden, Einbaugeräte, Zäune, Nebengebäude, Bäume, Gebüsch, Fensterabdeckungen und Fensterbeschläge, falls vorhanden, auf dem Gelände bei der Ausführung dieses Vertrags.

<font=ahouse_16>1. KAUF PREIS</font>
Der Gesamtkaufpreis der Immobilie beträgt %s

Wenn der Barzahlungsscheck von der Bank des Käufers nicht eingelöst wird, verpflichtet sich der/die Käufer, den Scheck innerhalb von zwei Werktagen einzulösen und dem Immobilienmakler eine Bearbeitungsgebühr in Höhe des gesetzlich zulässigen Höchstbetrags zu zahlen. Andernfalls wird dieser Vertrag anfechtbar und der Makler und der/die Verkäufer können Rechtsbehelfe gegen den/die Käufer geltend machen, die gesetzlich verfügbar sind.

<font=ahouse_16>2. FINANZIERUNG:</font>
Der Käufer zahlt bar oder erhält ein Darlehen für die Immobilie ohne Finanzierungsrisiko.

<font=ahouse_16>3. VERTRAG GESAMTE VEREINBARUNG</font>
Dieser Vertrag stellt die gesamte Vereinbarung zwischen Käufer und Verkäufer in Bezug auf das Grundstück dar und ersetzt alle vorherigen Gespräche, Verhandlungen und Vereinbarungen zwischen Käufer und Verkäufer, ob mündlich oder schriftlich. Weder Käufer, Verkäufer noch Makler oder Vertriebspartner sind an Vereinbarungen, Vereinbarungen, Versprechen oder Zusicherungen in Bezug auf das Eigentum gebunden, ausdrücklich oder stillschweigend, die hier nicht angegeben sind. Zeit ist von entscheidender Bedeutung. Allen Parteien wird empfohlen, vor der Unterzeichnung des Vertrags den Rat eines Rechtsbeistands zu einer der Bestimmungen dieser Vereinbarung einzuholen, die möglicherweise nicht verstanden werden. Durch die Unterzeichnung dieses Vertrags erkennen die Parteien an, dass sie verstehen, dass diese Vereinbarung sowohl gesetzliche Verpflichtungen als auch gesetzliche Rechte schafft, die vor Gericht durchgesetzt werden können. DIESES DOKUMENT SOLL EIN RECHTSVERBINDLICHER VERTRAG DARSTELLEN. (Nach Unterzeichnung ist dieses Dokument ein rechtsverbindlicher Vertrag.)
</colour></font>
    ]]
}

ahouse.lang.l = l