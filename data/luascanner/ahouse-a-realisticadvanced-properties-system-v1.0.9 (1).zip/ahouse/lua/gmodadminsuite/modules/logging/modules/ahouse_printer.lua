local MODULE = GAS.Logging:MODULE()

MODULE.Category = "AHouse"
MODULE.Name = "Printer"
MODULE.Colour = ahouse.Config.Colors.BlackGreen

MODULE:Setup(function()
	MODULE:Hook("ahouse_printer", "Blogs", function(ply)
        MODULE:Log(ahouse.lang.l.blogs_printer,
            GAS.Logging:FormatPlayer(ply))
	end)
end)

GAS.Logging:AddModule(MODULE) // This function adds the module object to the registry.