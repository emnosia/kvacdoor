local MODULE = GAS.Logging:MODULE()

MODULE.Category = "AHouse"
MODULE.Name = "Buy"
MODULE.Colour = ahouse.Config.Colors.BlackGreen

MODULE:Setup(function()
	MODULE:Hook("ahouse_afterbuy", "Blogs", function(ply, id)
        MODULE:Log(ahouse.FormatLanguage("blogs_buy", ahouse.HouseData.List[id].name),
            GAS.Logging:FormatPlayer(ply))
	end)
end)

GAS.Logging:AddModule(MODULE) // This function adds the module object to the registry.