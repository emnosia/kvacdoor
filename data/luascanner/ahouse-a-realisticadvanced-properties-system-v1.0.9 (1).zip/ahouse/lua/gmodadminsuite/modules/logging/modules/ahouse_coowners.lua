local MODULE = GAS.Logging:MODULE()

MODULE.Category = "AHouse"
MODULE.Name = "Co-Owners"
MODULE.Colour = ahouse.Config.Colors.BlackGreen

MODULE:Setup(function()
	MODULE:Hook("ahouse_coowners", "Blogs", function(id, owner, ply, is_remove)
        local t = is_remove and "blogs_coowners_remove" or "blogs_coowners_add"

        MODULE:Log(ahouse.FormatLanguage(t, ahouse.HouseData.List[id].name),
            GAS.Logging:FormatPlayer(owner), GAS.Logging:FormatPlayer(ply))
	end)
end)

GAS.Logging:AddModule(MODULE) // This function adds the module object to the registry.