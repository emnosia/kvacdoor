
TOOL.Category = "AHouse"
TOOL.Name = "Modify Property"
TOOL.Command = nil
TOOL.ConfigName = ""

local ply

function TOOL:LeftClick( trace )
	if CLIENT then
		
		return true
	end
end

local clrs = {}
local houseTarget

for i=0, 9 do
	clrs[i] = HSVToColor(360/9*i, 0.66, 1)
	clrs[i].a = 30
end

local enabled = false
function TOOL:Deploy()
	if not CLIENT then return end

	enabled = true
	ply = LocalPlayer()

	hook.Add("PostDrawTranslucentRenderables", "ahouse_tool", function()
		houseTarget, housePos = nil

		for k, v in pairs(ahouse.HouseData.List or {}) do
			render.SetColorMaterial()
			render.DrawBox( v.vecs[1], Angle(), Vector(), (v.vecs[2] - v.vecs[1]), clrs[k % 10], true)

			if util.IntersectRayWithOBB( EyePos(), EyeVector()*10000, v.vecs[1], Angle(), Vector(), v.vecs[2] - v.vecs[1]) 
				and (!housePos or ((v.vecs[2] - v.vecs[1])/2 + v.vecs[1]):DistToSqr(EyePos()) < housePos:DistToSqr(EyePos())) then
				houseTarget = k
				housePos = (v.vecs[2] - v.vecs[1])/2 + v.vecs[1]
			end
		end
	
		if houseTarget then
			local v = ahouse.HouseData.List[houseTarget]
			draw.NoTexture()
			render.DrawWireframeBox( v.vecs[1], Angle(), Vector(), (v.vecs[2] - v.vecs[1]), color_white, true)
		end
	end)
end

function TOOL:RightClick()
	if SERVER or !houseTarget or !IsFirstTimePredicted() then return end

	local fSub = vgui.Create("ahouse_AskBox")
	fSub.title:SetText("Are you sure to delete this property ?")
	fSub.desc:SetText("You will need to recreate the property.")

	function fSub:OnRefuse() end

	function fSub:OnAccept()
		net.Start("ahouse_housedata")
			net.WriteUInt(2, 4)
			net.WriteUInt(houseTarget, 10)
		net.SendToServer()
		fSub:Remove()
	end
end

function TOOL:LeftClick()
	if CLIENT and IsFirstTimePredicted() and houseTarget then
		local data = ahouse.HouseData.List[houseTarget]

		local p = vgui.Create("ahouse_AskInput")
		p:SetTitle("Register the property")
		p:SetTextButton("Modify")

		local t = p:CreateEntryComboBox()
		t:AddChoice(ahouse.lang.l.alarm_with)
		t:AddChoice(ahouse.lang.l.alarm_without)

		t:ChooseOptionID(2)

		p:CreateEntry("Renting price", true):SetText(data.rent_price)
		p:CreateEntry("Buy Price", true):SetText(data.price)

		local t = p:CreateEntryComboBox()

		for i=0, 2 do
			t:AddChoice(ahouse.lang.l["property_" .. i])
		end
		t:ChooseOptionID( 1 )

		p:CreateEntry("Name", false, 1, 24):SetText(data.name)
	
		p:SetCallback(function(but, p, ...)
			local entries = {...}
			local name = entries[5][2]
			local type = entries[4][1]
			local price = tonumber(entries[3][2])
			local rent = tonumber(entries[2][2])
			local have_alarm = entries[1][1]:GetSelectedID() == 1

			if rent < 1 or rent > 10000000 then
				entries[2][1]:SetText("Invalid rent price")
				return
			end

			if price < 1 or price > 10000000 then
				entries[3][1]:SetText("Invalid price")
				return
			end

			net.Start("ahouse_housedata")
				net.WriteUInt(1, 4)
				net.WriteUInt(houseTarget, 10)
				net.WriteString(name)
				net.WriteUInt(rent, 24)
				net.WriteUInt(price, 24)
				net.WriteUInt(type:GetSelectedID() - 1, 2)
				net.WriteBool(have_alarm)
			net.SendToServer()

			data = {}
			stageID = 1
		end)
	end
end

function TOOL:Holster()
	enabled = false
	hook.Remove("PostDrawTranslucentRenderables", "ahouse_tool")
end

function TOOL:DrawHUD()
	if !ply or !enabled then
		self:Deploy()
	end

	for k, v in pairs(ahouse.HouseData.List or {}) do
		local center = (v.vecs[2] - v.vecs[1])/2 + v.vecs[1]
		local houseToScreen = center:ToScreen()

		if houseToScreen.visible then
			local _, ht = draw.SimpleText(v.name, "ahouse_16", houseToScreen.x, houseToScreen.y, color_white, 1, 1)
			draw.SimpleText(ahouse.HouseData.PropertyPrice(ply, k, nil, true), "ahouse_16", houseToScreen.x, houseToScreen.y + ht, ColorAlpha(clrs[(k + 4) % 10], 255), 1, 1)
		end
	end
end

if CLIENT then
    language.Add("Tool.ahouse_modifyhouse.name", TOOL.Name)
    language.Add("Tool.ahouse_modifyhouse.desc", "Modify or delete a property")
    language.Add("Tool.ahouse_modifyhouse.0", "Left click: Modify. Right click: Delete")

	function TOOL.BuildCPanel( CPanel )
		CPanel:AddControl( "Header", { Description = "#tool.ahouse_doorhole.desc" } )
	end
end