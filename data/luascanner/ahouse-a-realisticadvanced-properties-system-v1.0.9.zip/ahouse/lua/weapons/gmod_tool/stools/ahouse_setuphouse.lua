
TOOL.Category = "AHouse"
TOOL.Name = "Add Property"
TOOL.Command = nil
TOOL.ConfigName = ""

ahouse.toolconfig = {
	stageID = 1,
	data = {},
}

local ply
local clientmodel

local stages = {
	{
		name = "House coordinates",
		todo = "Right Click to put the 2 positions, these should cover the whole house and be at each extremity",

		pair = true,
		vecNums = {1, 1},
		postRender = function()
			if !ahouse.toolconfig.data[1] then return end

			local t = CurTime()*3 % 2
			local c = ahouse.UI.ColorTo(
				ahouse.Config.Colors.BlackGreen,
				ahouse.Config.Colors.LightGreen2,
				(t < 1 and t or 1 - (t - 1))
			)

			//c.a = 100

			local v1, v2 = ahouse.toolconfig.data[1][1], ahouse.toolconfig.data[1][2]

			if !v1 then
				return
			end

			local firstVec = v1[1]
			local secondVec = v2 and v2[1] or ply:EyePos() + ply:EyeAngles():Forward()*10

			if firstVec then
				render.DrawWireframeBox(firstVec, Angle(), Vector(), secondVec - firstVec, color_white, true)
			end

			for k, v in ipairs(ents.FindInBox(firstVec, secondVec)) do
				if ahouse.HouseData.IsDoor(v) then
					//v:SetColor(color_white)
					//v:SetRenderMode(1)
					//v:DrawModel()
					//v:SetColor(prev)
					//v:SetRenderMode(prevType)
				end
			end
		end
	},

	{
		name = "Views",
		todo = "Right Click to put a view for the house display. TIP: Take inside and outside positions",
		vecNums = {1, 4},
		pair = true,
		postRender = function()
			for i=1, table.Count(ahouse.toolconfig.data[2]), 2 do
				local v1, v2 = ahouse.toolconfig.data[2][i], ahouse.toolconfig.data[2][i+1]

				if !v1 or !v2 then return end

				render.DrawLine(v1[1], v2[1], color_white, true)
			end
		end
	},

	{
		name = "Doorbell/Intercom",
		todo = "Right click to put a Doorbell/Intercom.",
		model = "models/sterling/akulla_doorcamera.mdl",
		vecNums = {0, 1}
	},

	{
		name = "Letterbox",
		todo = "Right click to put a Letterbox",
		model = "models/props_borealis/mooring_cleat01.mdl",
		vecNums = {0, 1}
	},

	{
		name = "Control Display",
		todo = "Left click to put a Display",
		vecNums = {0, 1},
		postRender = function()
			local tr = ply:GetEyeTrace()
			local a = tr.HitNormal:Angle()

			local w, h = 400, 230
			render.DrawWireframeBox(tr.HitPos, Angle(0, a.y, 0), Vector(), Vector(1, 400/20, -230/20), color_white, true)
		end
	}
}

local enabled = false
function TOOL:Deploy()
	if CLIENT and IsValid(LocalPlayer()) then
		enabled = true
		ply = LocalPlayer()

		hook.Add("PreDrawOpaqueRenderables", "ahouse_tool", function()
			render.SetColorMaterial()
			render.SuppressEngineLighting(true)
	
			local stageConfig = stages[ahouse.toolconfig.stageID]

			if !stageConfig then return end
	
			if stageConfig.postRender then
				stageConfig.postRender()
			end

			render.SuppressEngineLighting(false)
		end)
	end
end

function TOOL:Holster()
	enabled = false
	hook.Remove("PreDrawOpaqueRenderables", "ahouse_tool")

	if IsValid(clientmodel) then
		clientmodel:Remove()
	end
end

function TOOL:LeftClick( trace )
	if CLIENT and IsFirstTimePredicted() then
		ahouse.toolconfig.data[ahouse.toolconfig.stageID] = ahouse.toolconfig.data[ahouse.toolconfig.stageID] or {}

		local s = table.Count(ahouse.toolconfig.data[ahouse.toolconfig.stageID]) + 1
		local stage = stages[ahouse.toolconfig.stageID]

		if stage.pair then
			s = math.floor(s/2)
		end

		if s > stage.vecNums[2] then
			return
		end

		local p = ply:EyePos()

		if ahouse.toolconfig.stageID == 1 or ahouse.toolconfig.stageID == 2 then
			table.insert(ahouse.toolconfig.data[ahouse.toolconfig.stageID], {p + ply:EyeAngles():Forward()*10, ply:EyeAngles()})
		else
			table.insert(ahouse.toolconfig.data[ahouse.toolconfig.stageID], {IsValid(clientmodel) and clientmodel:GetPos() or trace.HitPos, trace.HitNormal:Angle()})
		end
		return true
	end
end

function TOOL:RightClick( trace )
	if CLIENT and IsFirstTimePredicted() then
		ahouse.toolconfig.data[ahouse.toolconfig.stageID] = ahouse.toolconfig.data[ahouse.toolconfig.stageID] or {}
		local d = ahouse.toolconfig.data[ahouse.toolconfig.stageID]

		local s = table.Count(d)
		local stage = stages[ahouse.toolconfig.stageID]
	
		if stage.pair then
			s = math.floor(s/2)
		end
	
		if s >= stage.vecNums[1] && s <= stage.vecNums[2] then
			ahouse.toolconfig.stageID = ahouse.toolconfig.stageID + 1

			ahouse.toolconfig.data[ahouse.toolconfig.stageID] = {}
		end

		local stage = stages[ahouse.toolconfig.stageID]

		if IsValid(clientmodel) then
			clientmodel:Remove()
		end

		if stage and stage.model then
			clientmodel = ClientsideModel(stage.model)
		end

		/*
		Every stage is empty or with a array struct like this:
		[1] = Vector,
		[2] = Angle
		*/
		// You did it !
		if !stage then
			ahouse.toolconfig.stageID = ahouse.toolconfig.stageID - 1

			local p = vgui.Create("ahouse_AskInput")
			p:SetTitle("Register the property")
			p:SetTextButton("Create")
			local t = p:CreateEntryComboBox()
			t:AddChoice(ahouse.lang.l.alarm_with)
			t:AddChoice(ahouse.lang.l.alarm_without)
			t:ChooseOptionID(2)

			p:CreateEntry("Renting price", true)
			p:CreateEntry("Buy Price", true)
			local t = p:CreateEntryComboBox()

			for i=0, 2 do
				t:AddChoice(ahouse.lang.l["property_" .. i])
			end
			t:ChooseOptionID( 1 )

			p:CreateEntry("Name", false, 4, 24)
		
			p:SetCallback(function(but, p, ...)
				local entries = {...}
				local name = entries[5][2]
				local type = entries[4][1]
				local price = tonumber(entries[3][2])
				local rent = tonumber(entries[2][2])
				local have_alarm = entries[1][1]:GetSelectedID() == 1

				if rent < 1 or rent > 10000000 then
					entries[2][1]:SetText("Invalid rent price")
					return
				end

				if price < 1 or price > 10000000 then
					entries[3][1]:SetText("Invalid price")
					return
				end

				if !name or string.len(name) < 4 or string.len(name) > 20 then
					entries[5][1]:SetText("Invalid name")
					return
				end
	
				net.Start("ahouse_housedata")
					net.WriteUInt(0, 4)
					net.WriteString(name)
					net.WriteUInt(rent, 24)
					net.WriteUInt(price, 24)

					net.WriteVector(ahouse.toolconfig.data[1][1][1])
					net.WriteVector(ahouse.toolconfig.data[1][2][1])

					net.WriteUInt(type:GetSelectedID() - 1, 2)

					// Views
					local l = math.floor(table.Count(ahouse.toolconfig.data[2])/2)
					net.WriteUInt(l, 3)

					for i = 1, l do
						net.WriteVector(ahouse.toolconfig.data[2][i][1])
						net.WriteVector(ahouse.toolconfig.data[2][i+1][1])
						net.WriteAngle(ahouse.toolconfig.data[2][i][2])
						net.WriteAngle(ahouse.toolconfig.data[2][i+1][2])
					end

					for i = 3, 5 do
						if table.IsEmpty(ahouse.toolconfig.data[i]) then
							net.WriteBool(false)
						else
							net.WriteBool(true)
							net.WriteVector(ahouse.toolconfig.data[i][1][1])
							net.WriteAngle(ahouse.toolconfig.data[i][1][2])
						end
					end

					net.WriteBool(have_alarm)
				net.SendToServer()

				ahouse.toolconfig.data = {}
				ahouse.toolconfig.stageID = 1
			end)
		end
	end
end

local v = Vector(0, 1, 0)
function TOOL:Think()
	if !enabled then
		self:Deploy()
	end

	if IsValid(clientmodel) then
		local tr = ply:GetEyeTrace()

		if tr.Hit then
			local a = tr.HitNormal:Angle()

			local bMin, bMax = clientmodel:GetModelBounds()
			if ahouse.toolconfig.stageID == 4 then
				if a.x > 245 and a.x < 295 then
					clientmodel:SetModel("models/sterling/akulla_mailbox.mdl")
					clientmodel:SetPos(tr.HitPos)
				else
					clientmodel:SetModel("models/sterling/akulla_wallmailbox.mdl")
					clientmodel:SetPos(tr.HitPos + clientmodel:GetAngles():Forward() * 3)
				end
			elseif ahouse.toolconfig.stageID == 3 then
				clientmodel:SetPos(tr.HitPos + clientmodel:GetAngles():Forward() * bMax.y)
			end

			clientmodel:SetAngles(Angle(0, a.y, 0))
		end
	end
end

function TOOL:Reload()
	if CLIENT then
		ahouse.toolconfig.data[ahouse.toolconfig.stageID] = {}
	end
end

function TOOL:DrawHUD()
	if !ply then
		self:Deploy()
	end

	local w = ScrW()/2
	local h = ScrH()

	local hStart = h/4*3

	local _, t = draw.SimpleTextOutlined("If the current setup is green, you can do Right Click and go to the second step", 
		"ahouse_32", w, hStart - h*0.1, color_white, 1, 1, 2, color_black)

	draw.SimpleTextOutlined("If you wanna remake the current setup, press Reload", "ahouse_32", w, hStart - h*0.1 + t, color_white, 1, 1, 2, color_black)

	for k, v in pairs(ahouse.HouseData.List or {}) do
		local center = (v.vecs[2] - v.vecs[1])/2 + v.vecs[1]
		local houseToScreen = center:ToScreen()

		if houseToScreen.visible then
			local _, ht = draw.SimpleText(v.name, "ahouse_16", houseToScreen.x, houseToScreen.y, color_white, 1, 1)
			draw.SimpleText(ahouse.HouseData.PropertyPrice(ply, k, nil, true), "ahouse_16", houseToScreen.x, houseToScreen.y + ht, ahouse.Config.Colors.BlackGreen, 1, 1)
		end
	end

	for k, v in ipairs(stages) do
		local _, hTxt

		if k == ahouse.toolconfig.stageID then
			if v.postRender2D then
				v.postRender2D()
			end

			local clr = color_white
			ahouse.toolconfig.data[ahouse.toolconfig.stageID] = ahouse.toolconfig.data[ahouse.toolconfig.stageID] or {}

			local s = table.Count(ahouse.toolconfig.data[ahouse.toolconfig.stageID])

			if v.pair then
				s = math.floor(s/2)
			end

			if s >= v.vecNums[1] && s <= v.vecNums[2] then
				clr = ahouse.Config.Colors.LightGreen
			end

			_, hTxt = draw.SimpleTextOutlined("Current setup: " .. v.name, "ahouse_48", w, hStart + 10, clr, 1, 1, 2, color_black)
			hTxt = hTxt + select(2, draw.SimpleTextOutlined(v.todo, "ahouse_32", w, hStart + hTxt, color_white, 1, 1, 2, color_black))
			hTxt = hTxt + 10
		else
			_, hTxt = draw.SimpleText(v.name, "ahouse_32", w, hStart, ahouse.Config.Colors.White60, 1, 1)
		end

		hStart = hStart + hTxt
	end
end

function TOOL.BuildCPanel( CPanel )
	local but = vgui.Create("DButton")
	but:SetText("Reset to the first step")

	function but:DoClick()
		ahouse.toolconfig.stageID = 1
		ahouse.toolconfig.data = {}
	end

	but:SetMouseInputEnabled( true )
	CPanel:AddItem(but)

	function but:DoClick()
		ahouse.toolconfig.stageID = 1
		ahouse.toolconfig.data = {}
	end
end


if CLIENT then
    language.Add("Tool.ahouse_setuphouse.name", TOOL.Name)
    language.Add("Tool.ahouse_setuphouse.desc", "Follow instructions at the center bottom of your screen")
	language.Add("Tool.ahouse_setuphouse.0", "")
end