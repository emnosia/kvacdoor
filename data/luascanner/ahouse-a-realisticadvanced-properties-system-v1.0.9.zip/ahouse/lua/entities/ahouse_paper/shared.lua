ENT.Base = "base_entity"
ENT.Type = "anim"
ENT.PrintName = "Paper"
ENT.Category        = "AHouse"
ENT.Author          = "Akulla"
ENT.Offset = Vector(-3, -3 * 1.777, -0.2)