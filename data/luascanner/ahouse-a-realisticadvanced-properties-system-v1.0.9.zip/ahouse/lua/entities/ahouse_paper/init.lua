AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

util.AddNetworkString("ahouse_printer")
function ENT:Initialize()
	self:SetModel("models/props_office/paper_single.mdl")
	self:PhysicsInitBox( self:GetModelBounds() )
	self:SetUseType(SIMPLE_USE)
	self.count = 0
	self:DropToFloor()
end

function ENT:Use(ply)
	if ply != self.target then
		ahouse.Notify(ply, "contrat_notyours", 1)
		return
	end

	net.Start("ahouse_printer")
		net.WriteEntity(self)
		net.WriteBool(self.rent)
		// weird unknown people system
		net.WriteUInt(self.houseid, 10)
		net.WriteUInt(self.commissionPrice, 24)
		net.WriteString(self.seller:Nick()) // Str bcuz some server will have system blocking the rp name

		if self.rent and ahouse.Config.PermanentHousing then
			net.WriteUInt(self.rent_days, 16)
		end
	net.Send(ply)
end