include("shared.lua")

local ang = Angle(0, 0, 180)
function ENT:Draw(f)
    self:DrawModel(f)

    // I'm sorry but I'm not a 3d modeler, rather a dev so it's a ghetto way
    if !self.rectModel or !IsValid(self.rectModel) then
        self.rectModel = ClientsideModel(self:GetModel())
        self.rectModel:SetPos(self:GetPos())
        self.rectModel:SetAngles(self:LocalToWorldAngles(ang))
        self.rectModel:SetParent(self)
    elseif !IsValid(self.rectModel:GetParent()) then
        self.rectModel:SetPos(self:GetPos())
        self.rectModel:SetAngles(self:LocalToWorldAngles(ang))
        self.rectModel:SetParent(self)
    end
end

function ENT:OnRemove()
    if IsValid(self.rectModel) then
        self.rectModel:Remove()
    end
end

local text = ahouse.lang.l.contract

net.Receive("ahouse_printer", function()
    local paper = net.ReadEntity()
    local rent = net.ReadBool()
    local houseid = net.ReadUInt(10)
    local commissionPrice = net.ReadUInt(24)
    local seller = net.ReadString()
    local rent_days

    if rent then
        rent_days = net.ReadUInt(16)
    end

    local max = ScrH() / 4 * 3
    // Drawing
    local local_ply = LocalPlayer()
    local buyer = local_ply:Nick()
    local house = ahouse.HouseData.List[houseid]
    local m = max * 0.05

    local mark = markup.Parse(string.format(text, buyer, seller, house.name,
        ahouse.HouseData.PropertyPrice(local_ply, houseid, rent, true, rent_days, commissionPrice)), max * 0.707 - m * 2 )
    local markH = mark:GetHeight()
    local rt, rtmat
    local refuse = true

    local p = vgui.Create("EditablePanel")
    p:SetSize(max * 0.707, max)
    p:Center()
    p:SetMouseInputEnabled(true)
    p:MakePopup()

    local b = vgui.Create("DButton", p)
    b:Dock(BOTTOM)
    b:SetContentAlignment(5)
    b:SetText(ahouse.lang.l.contract_finishbad)
    b:SetFont("ahouse_16")
    b:SetPaintBackground(false)

    function b:DoClick()
        net.Start("ahouse_printer")
            net.WriteEntity(paper)
            net.WriteBool(refuse)
        net.SendToServer()
        p:Remove()
    end

    function p:OnRemove()
        render.PushRenderTarget( rt )
        render.Clear(255, 255, 255, 255)
        render.PopRenderTarget()
    end

    function p:Paint(w, h)
        surface.SetDrawColor(210, 210, 210)
        surface.DrawRect(0, 0, w, h)

        local txtY = m

        txtY = txtY + select(2, draw.SimpleText(ahouse.lang.l.contract_title, "ahouse_16", w / 2, txtY, color_black, 1, 0)) + m / 2

        draw.SimpleText(ahouse.lang.l.contract_purchase, "ahouse_16", m, txtY, color_black, 0, 0)
        txtY = txtY + select(2, draw.SimpleText(ahouse.lang.l.contract_date .. os.date("%x"), "ahouse_16", w - m, txtY, color_black, 2, 0)) + m / 2
        mark:Draw(m, txtY, TEXT_ALIGN_TOP, TEXT_ALIGN_TOP)

        txtY = txtY + markH + m / 2

        txtY = txtY + select(2, draw.SimpleText(ahouse.lang.l.contract_draw, "ahouse_12", m, txtY, color_black, 0, 0))

        surface.SetDrawColor(color_black)
        surface.DrawOutlinedRect(m, txtY + m / 4, w - m * 2, h * 0.2, 2)

        if !rt then
            local n = "ahousecontract_" .. w - m * 2 .. h * 0.2 .. "n"
            rt = GetRenderTarget(n, w - m * 2, h * 0.2)
            rtmat = CreateMaterial( n, "UnlitGeneric", {
                ['$basetexture'] = rt:GetName(),
                ["$translucent"] = "1" -- This is necessary to render the RT with alpha channel
            } )

            self.OnRemove()
        end

        surface.SetDrawColor(color_white)
        surface.SetMaterial(rtmat)
        surface.DrawTexturedRect(m, txtY + m/4, w - m*2, h*0.2)

        local x, y = self:LocalCursorPos()
        x = x - m + 2
        y = y - (txtY + m/4) + 2

        if x < 0 or y < 0 or x > (w - m*2) - 2 or y >= h*0.2 - 2 or !input.IsMouseDown( MOUSE_LEFT ) then return end
        refuse = false

        b:SetText(ahouse.lang.l.contract_finish)

        render.PushRenderTarget( rt )
            cam.Start2D()
                render.PushFilterMag(TEXFILTER.ANISOTROPIC)
                render.PushFilterMin(TEXFILTER.ANISOTROPIC)

                draw.SimpleText("d", "ahouse_Icon_12", x, y, color_black, 1, 1)
                render.PopFilterMag()
                render.PopFilterMin()
            cam.End2D()
        render.PopRenderTarget()
    end
end)