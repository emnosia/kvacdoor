include("shared.lua")

function ENT:Draw(f)
    self:DrawModel(f)
end

function ENT:DrawTranslucent( flags )
    self:Draw(flags)
end