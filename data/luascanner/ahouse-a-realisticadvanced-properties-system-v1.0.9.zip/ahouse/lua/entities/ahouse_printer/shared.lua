ENT.Base = "base_entity"
ENT.Type = "anim"
ENT.PrintName = "Printer"
ENT.Category        = "AHouse"
ENT.Author          = "Akulla"
ENT.Spawnable       = true
ENT.AdminSpawnable  = true
ENT.AdminOnly = true