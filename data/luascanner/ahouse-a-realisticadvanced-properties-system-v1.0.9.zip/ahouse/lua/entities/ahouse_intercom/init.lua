AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/sterling/akulla_doorcamera.mdl")
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetMoveType(0)
end

util.AddNetworkString("ahouse_intercom")
local entMeta = FindMetaTable("Entity")
function ENT:Use(ply)
	if !self.houseid then return end

	self.lastdoorbell = self.lastdoorbell or -5
	if self.lastdoorbell + ahouse.Config.IntercomWaitTime < CurTime() then
		self.lastdoorbell = CurTime()
		local l = ahouse.HouseData.List[self.houseid]
		if !l or l.disabledbell then return end

		local doorid = ply.ahouse_ringbell
		local firstDoor = ahouse.HouseData.FirstSafeDoor(houseid)

		if IsValid(firstDoor) and IsValid(firstDoor:getDoorOwner()) then
			doorid = firstDoor:getDoorOwner().ahouse_ringbell
		end

		local plys = ahouse.HouseData.GetEntsInHouse(self.houseid, function(e) return e:IsPlayer() end)
		self:EmitSound( "akulla/ahouse/doorbell" .. ahouse.Config.RingbellSounds[doorid], 50)

		net.Start("ahouse_intercom")
			net.WriteBool(true) // Blue light
			net.WriteEntity(self)
		net.SendPAS(self:GetPos())

		net.Start("ahouse_intercom")
			net.WriteBool(false) // Sound
			net.WriteUInt(ply.ahouse_ringbell, 5)
		net.Send(plys)
	end
end