AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/sterling/akulla_mailbox.mdl")
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetMoveType(0)

	// Struct:
	// ply = 
	// 		item_list
	//		is_uptodate
	self.ahouse_inv = {
		items = {},
		plys = {}
	}
end

util.AddNetworkString("ahouse_mailbox")

function ENT:AddItem(ply, t, item)
	local l = self.ahouse_inv
	l.plys = {}

	local className = item.entity or item.ent or item.ammoType

	if l.items[className] then
		l.items[className].c = l.items[className].c + 1
	else
		// Mettre numero dans nom item
		l.items[className] = {
			t = t,
			c = 1,
			itemtbl = item
		}
	end
end

function ENT:Use(ply)
	if !self.houseid or !ahouse.HouseData.List[self.houseid] then return end

	local door = ahouse.HouseData.FirstSafeDoor(self.houseid)
	local l = self.ahouse_inv or {}
	l.items = l.items or {}
	l.plys = l.plys or {}
	if !IsValid(door) or !door:isKeysOwnedBy(ply) or table.IsEmpty(l.items) then return end

	net.Start("ahouse_mailbox")
		net.WriteEntity(self)
		net.WriteUInt(0, 3)
		net.WriteBool(!l.plys[ply])
		if !l.plys[ply] then
			net.WriteUInt(table.Count(l.items), 5)
			for k, v in pairs(l.items) do
				net.WriteString(k)
				net.WriteUInt(v.t, 3)
				net.WriteUInt(v.c, 5)
			end
		end
	net.Send(ply)

	l.plys[ply] = true
end

// Darkrp, not mine
local function defaultSpawn(ply, tr, tblE)
	local ent = ents.Create(tblE.ent)

	if not ent:IsValid() then error("Entity '" .. tblE.ent .. "' does not exist or is not valid.") end
	if ent.Setowning_ent then ent:Setowning_ent(ply) end

	ent:SetPos(tr.HitPos)
	-- These must be set before :Spawn()
	ent.SID = ply.SID
	ent.allowed = tblE.allowed
	ent.DarkRPItem = tblE
	ent:Spawn()
	ent:Activate()

	if !DarkRP.placeEntity then
		print("It seems like your server doesn't have the placeEntity function, THIS IS NOT A ISSUE FROM AHOUSE !!!")
		print("One of your addons break darkrp")
		return
	end

	DarkRP.placeEntity(ent, tr, ply)

	local phys = ent:GetPhysicsObject()
	if phys:IsValid() then phys:Wake() end

	return ent
end

ahouse.SafeNet("mailbox", function(ply)
    local ent = net.ReadEntity()
	if !IsValid(ent) or !ahouse.HouseData.PlayerOwned[ply] or
		!ahouse.HouseData.PlayerOwned[ply][ent.houseid] then return end

	local str = net.ReadString()
	local item = ent.ahouse_inv.items[str]
	if !item or item.c < 1 then return end

	item.c = item.c - 1
	
	net.Start("ahouse_mailbox")
		net.WriteEntity(ent)
		net.WriteUInt(1, 3)
		net.WriteString(str)
	net.Send(ply)

	local itemTbl = item.itemtbl
	local trace = {}
	trace.start = ent:LocalToWorld(ent:OBBCenter())
	trace.endpos = trace.start + ent:GetAngles():Forward() * 85
	trace.filter = ent
	local tr = util.TraceLine(trace)

	if tr.Hit then
		for i=-50, 50, 90 do
			local a = ent:GetAngles()
			a:RotateAroundAxis(a:Up(), 45)
			trace.endpos = a:Forward() * 85

			local tr2 = util.TraceLine(trace)
			if !tr2.Hit then
				tr = tr2
				break
			end
		end
	end

	if item.t == 1 then
		local ent = (itemTbl.spawn or defaultSpawn)(ply, tr, itemTbl)
		ent.onlyremover = not itemTbl.allowTools
		-- Repeat these properties to alleviate work in tblEnt.spawn:
		ent.SID = ply.SID
		ent.allowed = itemTbl.allowed
		ent.DarkRPItem = itemTbl

		ply:addCustomEntity(itemTbl)
	elseif item.t == 0 then
		local ammo = ents.Create("spawned_ammo")
		ammo:SetModel(itemTbl.model)
		ammo:SetPos(tr.HitPos)
		ammo.nodupe = true
		ammo.amountGiven, ammo.ammoType = itemTbl.amountGiven, itemTbl.ammoType
		ammo:Spawn()

		if !DarkRP.placeEntity then
			print("It seems like your server doesn't have the placeEntity function, THIS IS NOT A ISSUE FROM AHOUSE !!!")
			print("One of your addons break darkrp")
			return
		end
	
		DarkRP.placeEntity(ammo, tr, ply)
	elseif item.t == 2 then
		// The way to create this is soo garbage
		local found, foundKey = DarkRP.getShipmentByName(itemTbl.name)

		local crate = ents.Create(found.shipmentClass or "spawned_shipment")
		crate.SID = ply.SID
		crate:Setowning_ent(ply)
		crate:SetContents(foundKey, found.amount)

		crate:SetPos(Vector(tr.HitPos.x, tr.HitPos.y, tr.HitPos.z))
		crate.nodupe = true
		crate.ammoadd = itemTbl.spareammo
		crate.clip1 = itemTbl.clip1
		crate.clip2 = itemTbl.clip2
		crate:Spawn()
		crate:SetPlayer(ply)

		if !DarkRP.placeEntity then
			print("It seems like your server doesn't have the placeEntity function, THIS IS NOT A ISSUE FROM AHOUSE !!!")
			print("One of your addons break darkrp")
			return
		end
		
		DarkRP.placeEntity(crate, tr, ply)

		local phys = crate:GetPhysicsObject()
		phys:Wake()
		if itemTbl.weight then
			phys:SetMass(itemTbl.weight)
		end

		if CustomShipments[foundKey].onBought then
			CustomShipments[foundKey].onBought(ply, CustomShipments[foundKey], crate)
		end
	elseif item.t == 3 then
		local shipment = DarkRP.getShipmentByName(itemTbl.name)

		if not shipment or not shipment.separate then
			DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("unavailable", DarkRP.getPhrase("weapon_")))
			return ""
		end

		local wep_tbl = weapons.Get(shipment.entity)
		if wep_tbl and wep_tbl.Primary then
			defaultClip = wep_tbl.Primary.DefaultClip
			clipSize = wep_tbl.Primary.ClipSize
		end

		local weapon = ents.Create("spawned_weapon")
		weapon:SetModel(shipment.model)
		weapon:SetWeaponClass(shipment.entity)
		weapon:SetPos(tr.HitPos)
		weapon.ammoadd = shipment.spareammo or defaultClip
		weapon.clip1 = shipment.clip1 or clipSize
		weapon.clip2 = shipment.clip2
		weapon.nodupe = true
		weapon:Spawn()

		if !DarkRP.placeEntity then
			print("It seems like your server doesn't have the placeEntity function, THIS IS NOT A ISSUE FROM AHOUSE !!!")
			print("One of your addons break darkrp")
			return
		end
	
		DarkRP.placeEntity(weapon, tr, ply)
	
		if shipment.onBought then
			shipment.onBought(ply, shipment, weapon)
		end
	end

	if item.c == 0 then
		ent.ahouse_inv.items[str] = nil
	end
end, 0.25)