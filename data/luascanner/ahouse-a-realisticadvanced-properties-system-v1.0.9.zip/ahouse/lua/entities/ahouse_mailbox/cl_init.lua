include("shared.lua")

function ENT:Draw(f)
    self:DrawModel(f)
end

function ENT:DrawTranslucent( flags )
	self:Draw(flags)
end

local containers = {}
net.Receive("ahouse_mailbox", function(_, ply)
    local ent = net.ReadEntity()
    local id = net.ReadUInt(3)

    if id == 0 then
        local amt

        if net.ReadBool() then
            ent.ahouse_inv = {}
            amt = net.ReadUInt(5)
            for i = 1, amt do
                ent.ahouse_inv[net.ReadString()] = {
                    t = net.ReadUInt(3),
                    c = net.ReadUInt(5)
                }
            end
        else
            amt = table.Count(ent.ahouse_inv)
        end

        // Create UI
        containers = {}
        local m = ahouse.GetMargin(0.5)
        local ui = vgui.Create("EditablePanel")
        ui:MakePopup()
        ui:SetSize(ScrW()/2, ScrH()/2)
        ui:Center()
        ui:DockPadding(m, m, m, m)
        ui.c = CurTime()

        ahouse.UI.QuitOnClick(ui)

        function ui:Paint(w, h)
            if !self.bgahouse then
                self.bgahouse = ahouse.UI.Background(self, w, h, 25)
            end
            self.bgahouse()
        end

        local rowElemSize = 6
        local rowButtonSize = (ui:GetWide() - math.ceil(m*2) - m*(rowElemSize-1)) / rowElemSize

        local scroll = vgui.Create("DScrollPanel", ui)
        scroll:Dock(FILL)
        scroll:GetVBar():SetWide(4)
    
        local iconLayout = vgui.Create("DIconLayout", scroll)
        iconLayout:Dock(FILL)
        iconLayout:SetSpaceX(m)
        iconLayout:SetSpaceY(m)

        local rowAmt = math.ceil(amt/rowElemSize)

        if rowAmt * rowButtonSize + m * (rowAmt - 1) < ui:GetTall() then
            ui:SetTall(rowAmt * rowButtonSize + m * (rowAmt - 1) + m*2)
            scroll:GetVBar():SetWide(0)
            ui:Center()
        else
            rowButtonSize = rowButtonSize + 1
        end

        for i=1, rowAmt*rowElemSize do
            p = vgui.Create("DPanel", iconLayout)
            p:SetSize(rowButtonSize, rowButtonSize)

            function p:Paint(w, h)
                if self.perc != 0 and self.child then
                    draw.RoundedBox(ahouse.GetCorner(), 0, 0, w, h,
                        ahouse.UI.ColorTo(ahouse.Config.Colors.SubBackground, ahouse.Config.Colors.BlackGreen, self.perc))
                else
                    draw.RoundedBox(ahouse.GetCorner(), 0, 0, w, h,
                    ahouse.Config.Colors.SubBackground)
                end
            end
            ahouse.UI.AddHoverTimer(p, 3, true)

            containers[i] = p
        end

        local count = 1

        for k, v in pairs(ent.ahouse_inv) do
            local pnl = vgui.Create("DButton", containers[count])
            pnl:Dock(FILL)
            pnl:SetText("")
            pnl:DockMargin(5, 5, 5, 5)
            pnl:SetMouseInputEnabled(true)
            pnl.item = k
            pnl:SetPaintBackground(false)

            function pnl:DoClick()
                net.Start("ahouse_mailbox")
                    net.WriteEntity(ent)
                    net.WriteString(k)
                net.SendToServer()
            end

            pnl.title = vgui.Create("DLabel", pnl)
            pnl.title:Dock(BOTTOM)
            pnl.title:SetFont("ahouse_12")
            pnl.title:SetContentAlignment(5)
            pnl.title:SetTall(select(2, pnl.title:GetContentSize()))
            pnl.title:SetMouseInputEnabled(false)

            pnl.model = vgui.Create("ModelImage", pnl)
            pnl.model:DockMargin(pnl.title:GetTall()/2, 0, pnl.title:GetTall()/2, 0)
            pnl.model:Dock(FILL)
            pnl.model:SetMouseInputEnabled(false)

            local drpTbl, lookKey

            // ammo
            if v.t == 0 then
                drpTbl = DarkRP.getCategories().ammo
                lookKey = "ammoType"
            elseif v.t == 1 then
                drpTbl = DarkRP.getCategories().entities
                lookKey = "ent"
            elseif v.t == 2 then
                drpTbl = DarkRP.getCategories().shipments
                lookKey = "entity"
            elseif v.t == 3 then
                drpTbl = DarkRP.getCategories().weapons
                lookKey = "entity"
            end

            // DarkRP way to manage items is bad
            for a, b in ipairs(drpTbl or {}) do
                for i, j in ipairs(b.members) do
                    if j[lookKey] == k then
                        model = j.shipmodel or j.model
                        pnl.title:SetText(j.name)
                        pnl.model:SetModel(model)
                        break
                    end
                end
            end

            containers[count].child = pnl

            count = count + 1
        end
    elseif id == 1 then
        local item = net.ReadString()
        ent.ahouse_inv[item].c = ent.ahouse_inv[item].c - 1

        if ent.ahouse_inv[item].c == 0 then
            local move = false
            for k, v in ipairs(containers) do
                if !v.child then continue end

                if v.child.item == item then
                    v:Clear()
                    move = true
                elseif move then
                    local child = v.child

                    if IsValid(child) then
                        child:SetParent(containers[k-1])
                        child:Dock(FILL)

                        child.title:Dock(BOTTOM)
                        child.model:Dock(FILL)

                        child:InvalidateLayout(true)
                        containers[k-1].child = child
                        v.child = nil
                    end
                end
            end

            ent.ahouse_inv[item] = nil
            return
        end
    end
end)