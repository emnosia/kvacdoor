ahouse.lang = {}

local l = {
    cantBuy = "No puedes adquirir esta propiedad",
    alreadyowned = "¡Esta propiedad ya tiene dueño!",
    toomuchProperties = "Cuentas con demasiadas propiedades",
    startPhrase = "Todos merecen un hogar",
    startPhrase2 = "¡Obtén el tuyo hoy!",

    home_settings = "Opciones",
    home_settings_desc = "Cambia tus ajustes",

    home_buy = "Comprar, Vender, Rentar",
    home_buy_desc = "Su Real Estado libre",

    home_manage = "Administra tu propiedad",
    home_manage_desc = "¿Grupos de timbre?",

    printer_away = "La impresora está demasiado lejos",
    printer_already = "La impresora ya está imprimiendo un contrato",
    printer_toomuch = "Debes esperar a que algún contrato desaparezca (90seg)",

    rent_price = "%s cada %s",

    contrat_notyours = "Este contrato no te involucra",
    NPCName = "Hombre de ventas del Real Estado",
    gotonpc = "Por favor, habla con un hombre de ventas para adquirir esta residencia",

    closed_doors = "Has cerrado las puertas de tu residencia",
    open_doors = "Has abierto las puertas de tu residencia",

    property_0 = "Casa",
    property_1 = "Departamento",
    property_2 = "Edificio",

    ringbell = "Timbre",
    ringbell_on = "Timbre encendido",
    ringbell_off = "Timbre apagado",
    alldoors = "Puertas",
    close = "Cerrar",
    open = "Abrir",

    contract_finish = "Finalizar el contrato",
    contract_finishbad = "Rechazar el contrato",
    contract_title = "CONTRATO DE VENTAS DEL REAL ESTADO",
    contract_purchase = "OFERTA",
    contract_date = "FECHA:",
    contract_draw = "A continuación, la firma del comprador (¡Firma para aceptar el contrato!)",

    format_withdays = "%s por %s",

    alarm_with = "Con alarma",
    alarm_without = "Sin alarma",

    ui_back = "Inicio",
    ui_manageproperty = "Administra tus propiedades",
    ui_extra = "Días restantes de renta",
    ui_rentdays = "Días a rentar",
    ui_gps = "Activar GPS (5 minutos)",
    printcontract = "Imprimir contrato",
    contract_options = "Opciones del contrato",
    contract_commission = "Tu comisión (valor distinto al de la propiedad adquirida)",
    re_rent = "Volver a rentar",
    search = "Buscar",
    coowners = "Co-Propietarios",
    propconfig = "Configuración de props",
    propconfig_new = "Nueva configuración",
    name = "Nombre",
    create = "Crear",
    timeday = "Días (=%s) (Entre 1 y %s)",
    invalid_value = "Valor inválido",
    price_inferior = "El precio debe ser menor a %s",

    buy = "Comprar",
    rent = "Rentar",
    direct_buy = "Compra directa",
    renting = "Renta",
    sell = "Vender",
    property_of = "Propiedad de %s",

    blogs_alarm = "{1} activó la alarma de la propiedad %s",
    blogs_printer = "{1} imprimió un contrato",
    blogs_buy = "{1} adquirió la propiedad %s",
    blogs_sell = "{1} vendió la propiedad %s",
    blogs_coowners_add = "{1} añadió a {2} a la propiedad %s",
    blogs_coowners_remove = "{1} removió {2} de la propiedad %s",

    notif_noplayers = "No hay jugadores para añadir como co-propietarios",

    propspawn_1 = "No puedes generar props fuera de tu propiedad",
    propspawn_2 = "No puedes generar props en propiedades ajenas",

    // This is markup, DON'T TRANSLATE font and colour
    contract = [[
<font=ahouse_12><colour=0,0,0>
Nombre de el/los comprador(es): <font=ahouse_12>%s</font>
Nombre de el/los vendedor(es): <font=ahouse_12>%s</font>

Los compradores, sea uno o más de uno, accede a comprar y, los vendedores, sea uno o más de uno, acceden a vender el/la "%s"

La propiedad a comprar y a vender cuenta con sistema de calefacción y de aire acondicionado, timbres, chimenea, buzón, pantalla de fuego, calentadores, tuberías en correcto estado, luces en correcto estado, ventiladores, alfombra, electrodomésticos propios, cerca, patio, árboles, arbustos, persianas, herrajes para ventanas.

<font=ahouse_16>1. PRECIO DE LA COMPRA</font>
El precio total de la compra será de %s

Si el banco del comprador no admitiese el cheque, el o los compradores aceptan emitir un cheque válido dentro de los próximos dos días hábiles y pagar una comisión. En caso de incumplimiento, el vendedor se verá en posición de levantar cargos frente a él o los compradores.

<font=ahouse_16>2. FINANCIACIÓN:</font>
El comprador pagará en efectivo o obtendrá un préstamo para la Propiedad sin contingencia financiera.

<font=ahouse_16>3. ACUERDO TOTAL DEL CONTRATO</font>
El contrato constituye el acuerdo total entre el comprador y el vendedor respecto de la propiedad, y supera a cualquier discusión, negociación y acuerdo entre el comprador y el vendedor, ya sea oral o escrito. Ni el comprado, ni el vendedor, ni algún agente o socio de ventas debe estar atado bajo ningún entendimiento, acuerdo, promesa o representación respecto a la Propiedad, explícito o implícito, no especificado aquí. Se recomienda a todas las partes que busquen el asesoramiento de un asesor legal sobre cualquiera de los términos del presente que no se entiendan, antes de firmar el Contrato. Al firmar este Contrato, las partes reconocen que entienden que este acuerdo crea obligaciones legales, así como derechos legales que se pueden hacer cumplir en un tribunal de justicia. ESTE DOCUMENTO PRETENDE SER UN CONTRATO LEGALMENTE VINCULANTE. (Una vez firmado, este documento es un contrato legalmente vinculante).
</colour></font>
    ]]
}

ahouse.lang.l = l