ahouse.lang = {}

local l = {
    cantBuy = "Vous ne pouvez pas acheter cette propriété",
    alreadyowned = "Une personne possède déjà cette propriété",
    toomuchProperties = "Vous avez trop de résidences",
    startPhrase = "Tout le monde mérite une maison,",
    startPhrase2 = "Sautez le pas aujourd'hui !",

    home_settings = "Options",
    home_settings_desc = "Changez vos paramètres",

    home_buy = "Acheter, Vendre, Louer",
    home_buy_desc = "Votre chez-vous en moins de 5 minutes",

    home_manage = "Gérez votre propriété",
    home_manage_desc = "Marre des sonnettes party ?",

    printer_away = "L'imprimante est trop loin",
    printer_already = "L'imprimante imprime déjà un contrat",
    printer_toomuch = "Vous devez attendre qu'un contrat disparaisse (90sec)",

    rent_price = "%s tout les %s",

    contrat_notyours = "Ce contrat ne vous concerne pas",
    NPCName = "Vendeur Immobilier",
    gotonpc = "Veuillez parler avec un vendeur immobilier pour acheter cette résidence",

    closed_doors = "Vous avez fermé les portes de votre résidence",
    open_doors = "Vous avez ouvert les portes de votre résidence",

    property_0 = "Maison",
    property_1 = "Appartement",
    property_2 = "Batiment",

    ringbell = "Sonnette",
    ringbell_on = "Sonnette activée",
    ringbell_off = "Sonnette désactivée",
    alldoors = "Portes",
    close = "Fermer",
    open = "Ouvrir",

    contract_finish = "Finaliser le contrat",
    contract_finishbad = "Refuser le contrat",
    contract_title = "CONTRAT DE VENTE IMMOBILIÈRE",
    contract_purchase = "OFFRE D'ACHAT",
    contract_date = "DATE:",
    contract_draw = "Témoin de la signature de l'acheteur (Signez pour confirmer l'accord !)",

    format_withdays = "%s pour %s",

    alarm_with = "Avec alarme",
    alarm_without = "Sans alarme",

    ui_back = "Accueil",
    ui_manageproperty = "Gérez vos propriétés",
    ui_extra = "Combien de jours à louer en plus",
    ui_rentdays = "Location de combien de jours",
    ui_gps = "Activer GPS ( 5 minutes )",
    printcontract = "Imprimer contrat",
    contract_options = "Options du contrat",
    contract_commission = "Votre commission ( Moins que le prix de la propriété )",
    re_rent = "Re-louer",
    search = "Chercher",
    coowners = "Co-propriétaires",
    propconfig = "Configuration de props",
    propconfig_new = "Nouvelle configuration",
    name = "Nom",
    create = "Créer",
    timeday = "Jour (=%s) ( Entre 1 et %s )",
    invalid_value = "Valeur invalide",
    price_inferior = "Le prix doit être inférieur à %s",

    buy = "Acheter",
    rent = "Louer",
    direct_buy = "Achat direct",
    renting = "Location",
    sell = "Vendre",
    property_of = "Propriété de %s",

    blogs_alarm = "{1} a utilisé l'alarme de la propriété %s",
    blogs_printer = "{1} a imprimé un contrat",
    blogs_buy = "{1} a acheté la propriété %s",
    blogs_sell = "{1} a vendu la propriété %s",
    blogs_coowners_add = "{1} a ajouté {2} a la propriété %s",
    blogs_coowners_remove = "{1} a retiré {2} de la propriété %s",

    notif_noplayers = "Aucun joueur à ajouter en co-propriétaire",

    propspawn_1 = "Vous ne pouvez pas faire spawn de props en dehors de vos propriétés",
    propspawn_2 = "Vous ne pouvez pas faire spawn de props dans les propriétés des autres",

    contract = [[
<font=ahouse_12><colour=0,0,0>
Nom de l'acheteur(s): <font=ahouse_12>%s</font>
Nom du vendeur(s): <font=ahouse_12>%s</font>
        
L'acheteur(s), un ou plusieurs, conviennent par la présente d'acheter et, le vendeur(s), un ou plusieurs, conviennent par la présente de vendre la propriété "%s"
        
La propriété convenue pour être vendue comprend le système de chauffage et de refroidissement, les sonnettes, les manteaux de cheminée, les boîtes aux lettres, les pare-feu, les chauffe-eau, les appareils de plomberie, les appareils d'éclairage, les ventilateurs de plafond, les moquettes, les appareils électroménagers encastrés, les clôtures, les dépendances, les arbres, les arbustes, les revêtements de fenêtres et la quincaillerie de fenêtres, le cas échéant, sur les lieux à l'exécution du présent contrat.
        
<font=ahouse_16>1. PRIX D'ACHAT</font>
Le prix d'achat total du bien est de %s
        
Si le chèque d'arrhes n'est pas honoré par la banque de l'Acheteur, ce dernier s'engage à valider le chèque dans les deux jours ouvrables et à payer au courtier inscripteur des frais de dossier d'un montant maximum autorisé par la loi. À défaut, le présent contrat sera annulé et le courtier inscripteur et le vendeur pourront exercer contre l'acheteur les recours prévus par la loi.
        
<font=ahouse_16>2. FINANCEMENT:</font>
L'acheteur paiera comptant ou obtiendra un prêt pour la propriété sans condition de financement.
        
<font=ahouse_16>3. CONTRAT ACCORD COMPLET</font>
Le présent contrat constitue l'intégralité de l'accord entre l'Acheteur et le Vendeur concernant la Propriété, et remplace toutes les discussions, négociations et accords antérieurs entre l'Acheteur et le Vendeur, qu'ils soient oraux ou écrits. Ni l'Acheteur, ni le Vendeur, ni aucun courtier ou associé de vente ne seront liés par aucun arrangement, accord, promesse ou représentation concernant la Propriété, exprimé ou implicite, non spécifié dans le présent contrat. Le temps est un facteur essentiel. Il est conseillé à toutes les parties de demander l'avis d'un conseiller juridique sur tout terme des présentes qui pourrait ne pas être compris, avant de signer le Contrat. En signant ce contrat, les parties reconnaissent qu'elles comprennent que cet accord crée des obligations légales ainsi que des droits légaux qui peuvent être appliqués devant un tribunal. CE DOCUMENT EST DESTINÉ À ÊTRE UN CONTRAT JURIDIQUEMENT CONTRAIGNANT ( Une fois signé, ce document est un contrat juridiquement contraignant).
</colour></font>
]]
}

ahouse.lang.l = l