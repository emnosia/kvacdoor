ahouse.Config = ahouse.Config or {}

/*
    The languages you can use
    Relative to the file names in ahouse/code/lang/
*/

ahouse.Config.Language = "english"

/*
    Hide owned properties
    This prevent people from using the UI view to get infos on people houses
*/
ahouse.Config.HideOwnedProperties = false

/*
    Hide owners infos on doors
    Prevent metagaming
*/
ahouse.Config.HideOwnerOnDoors = false

/*
    The amount a person will get back when he sells his house (if the permanent option is not activated)
*/
ahouse.Config.SellPerc = 10 // 10%

// Lower/Bigger property price for X ranks. This will does :
//      Price for the player = (Price * YOUR_AMOUNT)
ahouse.Config.DiscountRanks = {
    ["VIP"] = 0.9,
    ["superadmin"] = 0.8
}

/*
    Jobs who are considered as real estate sellers
    Can use the chat command anytime, print contract etc...
*/
ahouse.Config.Jobs = {
    ["Medic"] = true,
}

/*
    If you want to enable permanent housing
*/
ahouse.Config.PermanentHousing = {
    Enabled = false, // Self-explain
    BuyTime = 7 * 24 * 60 * 60, // If he buy, how much time we give him in seconds ? Actually, this is 7 Days
}

/*
    Do you want alarm ?
    This may not work on some maps
    This will activate on all lockpicked doors that are entrance doors
*/
ahouse.Config.Alarm = {
    Enable = true,
    Cooldown = 300, // This allows you to wait before reactivating a door alarm
    Volume = 95 // What is the noise level ? Refer to https://wiki.facepunch.com/gmod/Enums/SNDLVL
}

/*
    Ringbells sounds, if you want to remove one or add one
    Relative to sound/akulla/ahouse/doorbell%PREFIX%
*/
ahouse.Config.RingbellSounds = {
    "_1.mp3", "_2.wav", "_3.mp3", "_4.wav", "_5.mp3"
}














// DON'T TOUCH BELOW! DON'T EXCEPT SUPPORT IF YOU WANT TO MODIFY THEM.
// DON'T TOUCH BELOW! DON'T EXCEPT SUPPORT IF YOU WANT TO MODIFY THEM.
// DON'T TOUCH BELOW! DON'T EXCEPT SUPPORT IF YOU WANT TO MODIFY THEM.

// This is made to edit the UI, I put it here for experienced users
// so they won't need to manage 3 separate config files.
// DON'T EXCEPT SUPPORT IF YOU WANT TO MODIFY THEM.
// The UI is very fragile with the patterns,
// if you edit the wrong values, you can make the ui look weird

ahouse.Config.RoundCorner = 8
ahouse.Config.DisplayHoldTime = 10
ahouse.Config.RentTime = 1800
ahouse.Config.PatternCount = 60

ahouse.Config.Colors = {
    Background = Color(32, 39, 47),
    SubBackground = Color(42, 50, 55),

    Material_Background = Color(26, 34, 43),

    BlackGreen = Color(46, 107, 53),
    BlackGreenPattern = Color(46, 107, 53, 17),
    LightGreen = Color(112, 194, 122),
    LightGreen2 = Color(129, 236, 142),

    White = Color(230, 240, 241),
    White60 = Color(230, 240, 241, 60)
}