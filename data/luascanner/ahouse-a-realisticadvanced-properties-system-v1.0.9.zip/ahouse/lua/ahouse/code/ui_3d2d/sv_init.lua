hook.Add("ahouse_inithouse", "ui_3d2d", function(id)
    local l = ahouse.HouseData.List[id]
    if !l then return end
    
    // Shouldn't happens
    if IsValid((l.ents or {}).display) then
        l.ents.display:Remove()
    end

    if l.display_pos then
        local e = ents.Create("ahouse_3d2dui")
        e:SetAngles(Angle(90, l.display_ang, 0))
        e:SetPos(l.display_pos + e:GetAngles():Up() * 0.2)
        e:Activate()
        e:Spawn()

        l.ents = l.ents or {}
        l.ents.display = e
        e.houseid = id
    end
end)