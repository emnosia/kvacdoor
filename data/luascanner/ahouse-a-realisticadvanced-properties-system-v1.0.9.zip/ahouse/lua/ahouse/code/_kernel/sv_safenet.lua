local l = {}
local c = CurTime

function ahouse.NetCD(name, ply, cd)
    local t = c()
    if l[ply] and l[ply][name] and l[ply][name] + cd > t then
        return false
    end

    l[ply] = l[ply] or {}
    l[ply][name] = t

    return true
end

hook.Add("PlayerDisconnected", "ahouse_clearnets", function(ply)
    l[ply] = nil
end)

function ahouse.SafeNet(netname, code, cooldown)
    util.AddNetworkString("ahouse_" .. netname)
    net.Receive("ahouse_" .. netname, function(_, ply)
        if !ahouse.NetCD(netname, ply, cooldown) then return end
        code(ply)
    end)
end