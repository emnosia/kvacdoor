hook.Add("ahouse_inithouse", "mailbox", function(id)
    local l = ahouse.HouseData.List[id]
    if !l then return end
    
    // Shouldn't happens
    if IsValid((l.ents or {}).mailbox) then
        l.ents.mailbox:Remove()
    end

    if l.letterbox_pos then
        local e = ents.Create("ahouse_mailbox")
        e:SetAngles(Angle(0, l.letterbox_ang, 0))
        e:SetPos(l.letterbox_pos)

        e:Activate()
        e:Spawn()
        e:SetModel(!l.letterbox_ground and
            "models/sterling/akulla_wallmailbox.mdl" or
            "models/sterling/akulla_mailbox.mdl")

        l.ents = l.ents or {}
        l.ents.mailbox = e

        e.houseid = id
    end
end)

// yoink
local function grabAndDelete(ply, tblEnt, ent, t)
    local houses = ahouse.HouseData.PlayerOwned[ply]
    if !houses then return end

    local closestMailbox
    local plyPos = ply:GetPos()

    for k, v in pairs(houses) do
        local houseData = ahouse.HouseData.List[k]

        if houseData.ents and houseData.ents.mailbox then
            local e = houseData.ents.mailbox
    
            if !IsValid(closestMailbox) then
                closestMailbox = e
            elseif closestMailbox:GetPos():DistToSqr(plyPos) < e:GetPos():DistToSqr(plyPos) then
                closestMailbox = e
            end
        end
    end

    if IsValid(closestMailbox) then
        if !ahouse.Config.Mailbox_Whitelist or !ahouse.Config.Mailbox_Whitelist[ent:GetClass()] then
            closestMailbox:AddItem(ply, t, tblEnt)
            ent:Remove()
        end
    end
end

hook.Add("playerBoughtAmmo", "ahouse_grabent", function(ply, tblEnt, ent, cost)
    if !ahouse.Config.DeliveryBox.Ammo then return end
    grabAndDelete(ply, tblEnt, ent, 0)
end)

hook.Add("playerBoughtCustomEntity", "ahouse_grabent", function(ply, tblEnt, ent, cost)
    if !ahouse.Config.DeliveryBox.Entity then return end
    grabAndDelete(ply, tblEnt, ent, 1)
end)

hook.Add("playerBoughtShipment", "ahouse_grabent", function(ply, tblEnt, ent, cost)
    if !ahouse.Config.DeliveryBox.Shipment then return end
    grabAndDelete(ply, tblEnt, ent, 2)
end)

hook.Add("playerBoughtPistol", "ahouse_grabent", function(ply, tblEnt, ent, cost)
    if !ahouse.Config.DeliveryBox.Pistol then return end
    grabAndDelete(ply, tblEnt, ent, 3)
end)