
hook.Add("onLockpickCompleted", "ahouse_dooralarm", function(ply, _, ent)
    if !ahouse.Config.Alarm.Enable or !ahouse.HouseData.IsDoor(ent)
        or !ent.ahouse_groupID or (ent.alarmCooldown or 0) > CurTime() then return end

    // Check if this is a exterior door
    local good = false
    local vec = ahouse.doorsHoles.GetHolePos(ent)

    for i=-1, 1, 2 do
        local tr = {
            start = ent:LocalToWorld(ent:OBBCenter()),
            endpos = ent:LocalToWorld(vec*100*i),
            mask = MASK_NPCWORLDSTATIC
        }

        local res = util.TraceLine( tr )

        if !res.Hit then
            good = true
            break
        end
            
        if !ahouse.HouseData.VecInHouse(ent.ahouse_groupID, res.HitPos) then
            good = true
            break
        end
    end

    if !good then return end
    local fd = ahouse.HouseData.FirstSafeDoor(ent.ahouse_groupID)
    if !fd:getDoorOwner() then return end

    ent.alarmCooldown = CurTime() + ahouse.Config.Alarm.Cooldown

    hook.Run("ahouse_alarm", ply, ent, ent.ahouse_groupID)

    fd:EmitSound( "akulla/ahouse/alarm.wav", 1)
    EmitSound( "akulla/ahouse/alarm.wav", fd:GetPos(), fd:EntIndex(), nil, nil, ahouse.Config.Alarm.Volume)
end)