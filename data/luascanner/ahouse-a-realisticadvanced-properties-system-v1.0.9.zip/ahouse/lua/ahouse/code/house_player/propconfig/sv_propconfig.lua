util.AddNetworkString("ahouse_sendpropconfig")

hook.Add("ahouse_afterbuy", "load_playerconfig", function(ply, id)
    ply.ahouse_configs = ply.ahouse_configs or {}

    ahouse.SQL.query("SELECT * FROM ahouse_playerhouseprops WHERE house = " .. id .. " AND owner = '" .. ply:SteamID64() .. "'", function(q)
        ply.ahouse_configs[id] = ply.ahouse_configs[id] or {}
        if !q then return end

        net.Start("ahouse_sendpropconfig")
            net.WriteBool(true)
            net.WriteUInt(id, 10)
            net.WriteUInt(#q, 4)
            for k, v in ipairs(q) do
                ply.ahouse_configs[id][tonumber(v.configid)] = {
                    house = id,
                    name = v.name,
                    configid = tonumber(v.configid),
                }

                net.WriteString(v.name)
                net.WriteUInt(tonumber(v.configid), 21)
            end
        net.Send(ply)
    end)
end)

ahouse.Props = ahouse.Props or {}

function ahouse.Props.Delete(ply, houseid, configid)
    ply.ahouse_configs = ply.ahouse_configs or {}
    ply.ahouse_configs[houseid] = ply.ahouse_configs[houseid] or {}

    if !ply.ahouse_configs[houseid][configid] then return end

    ply.ahouse_configs[houseid][configid] = nil

    ahouse.SQL.query("DELETE FROM ahouse_playerhouseprops WHERE configid = " .. configid)
    ahouse.SQL.query("DELETE FROM ahouse_playerprops WHERE configid = " .. configid)

    net.Start("ahouse_sendpropconfig")
        net.WriteBool(false)
        net.WriteUInt(houseid, 10)
        net.WriteUInt(configid, 21)
    net.Send(ply)
end

function ahouse.Props.Create(name, ply, uid)
    ply.ahouse_configs = ply.ahouse_configs or {}
    ply.ahouse_configs[uid] = ply.ahouse_configs[uid] or {}

    if table.Count(ply.ahouse_configs[uid]) >= 3 then return end
    local t = {}

    for k, v in ipairs(ents.GetAll()) do
        if v:GetClass() == "prop_physics" and v:CPPIGetOwner() == ply and ahouse.HouseData.VecInHouse(uid, v:GetPos()) then
            table.insert(t, {
                pos = v:GetPos(),
                ang = v:GetAngles(),
                model = v:GetModel()
            })
        end
    end

    local q = "INSERT INTO ahouse_playerhouseprops(owner, name, house) VALUES('" .. ply:SteamID64() .. "', " .. ahouse.SQL.escape(name) .. ", " .. uid .. ")"

    ahouse.SQL.query(q, function(data, queryObject)
        local id
        if ahouse.Config.MySQL.enable then
            id = queryObject:lastInsert()
        else
            ahouse.SQL.query("select last_insert_rowid() as id;", function(d)
                id = tonumber(d[1].id)
            end)
        end

        net.Start("ahouse_sendpropconfig")
            net.WriteBool(true)
            net.WriteUInt(uid, 10)
            net.WriteUInt(1, 4)
            net.WriteString(name)
            net.WriteUInt(id, 21)
        net.Send(ply)

        ply.ahouse_configs[uid][id] = {
            house = uid,
            name = name,
            configid = id,
        }

        for k, v in ipairs(t) do
            local q = [[INSERT INTO ahouse_playerprops(x,y,z,a_r,a_y,a_p,model,configid) VALUES(
                ]] .. v.pos.x .. [[, ]] .. v.pos.y .. [[, ]] .. v.pos.z .. [[, 
                ]] .. v.ang.r .. [[, ]] .. v.ang.y .. [[, ]] .. v.ang.p .. [[, 
                ']] .. v.model .. [[', ]] .. id .. ")"

            ahouse.SQL.query(q)
        end
    end)
end

function ahouse.Props.Setup(ply, houseid, configid)
    for k, v in ipairs(ents.GetAll()) do
        if v:GetClass() == "prop_physics" and v:CPPIGetOwner() == ply and ahouse.HouseData.VecInHouse(houseid, v:GetPos()) then
            v:Remove()
        end
    end

    if !ply.ahouse_configs[houseid] or !ply.ahouse_configs[houseid][configid] then return end

    ahouse.SQL.query('SELECT * FROM ahouse_playerprops where configid = ' .. configid, function(q)
        if !IsValid(ply) then return end

        for k, v in ipairs(q or {}) do
            if !hook.Run("PlayerSpawnProp", ply, v.model) then continue end
            local n = tonumber

            local e = ents.Create("prop_physics")
            e:SetModel(v.model)
            e:SetPos(Vector(n(v.x), n(v.y), n(v.z)))
            e:SetAngles(Angle(n(v.a_r), n(v.a_y), n(v.a_p)))
            e:SetMoveType(0)
            e:Spawn()

            hook.Run("PlayerSpawnedProp", ply, v.model, e)
            e:SetMoveType(0)

            if IsValid(e) then
                undo.Create( "Prop" )
                    undo.SetPlayer( ply )
                    undo.AddEntity( e )
                undo.Finish( "Prop (" .. tostring( v.model ) .. ")" )
            end
        end
    end)
end

// Faire reception net, créer props
// Trigger hook