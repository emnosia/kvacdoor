ahouse.HouseData.PlayerOwned = ahouse.HouseData.PlayerOwned or {}

function ahouse.HouseData.Buy(ply, id, is_rent, rent_time, skip_buy, extraPrice)
    local house = ahouse.HouseData.List[id]

    if !house then
        ahouse.Notify(ply, "cantBuy", 1)
        return
    end
    
    local firstDoor = ahouse.HouseData.FirstSafeDoor(id)
    
    if !IsValid(firstDoor) then
        ahouse.Notify(ply, "cantBuy", 1)
        return
    end
    
    if firstDoor:getDoorOwner() then
        ahouse.Notify(ply, "alreadyowned", 1)
        return
    end
    
    if table.Count(ahouse.HouseData.PlayerOwned[ply] or {}) >= ahouse.Config.MaxProperties then
        ahouse.Notify(ply, ahouse.lang.l.toomuchProperties, 1)
        return
    end
    
    local cantBuy = hook.Run("ahouse_canbuy", ply, id, is_rent, price, firstDoor)
    
    if cantBuy then
        ahouse.Notify(ply, cantBuy, 1)
        return
    end
    
    if !skip_buy then
        local price = ahouse.HouseData.PropertyPrice(ply, id, is_rent, nil, rent_time) + (extraPrice or 0)
        
        if !ply:canAfford(price) then
            DarkRP.notify(ply, 1, 3, DarkRP.getPhrase("cant_afford", house.name))
            return
        end
        
        ply:addMoney(-price)
    end
    
    ahouse.HouseData.SafeLoop(id, function(door)
        local doorData = door:getDoorData()
        doorData.owner = ply:UserID()
        DarkRP.updateDoorData(door, "owner")
        ply.Ownedz[door:EntIndex()] = door
    end)
    
    ply.OwnedNumz = ply.OwnedNumz or 0
    ply.OwnedNumz = ply.OwnedNumz + 1
    
    if is_rent and table.IsEmpty(ahouse.HouseData.PlayerOwned[ply] or {}) and !ahouse.Config.PermanentHousing.Enabled then
        // Get this cash boys
        timer.Create("ahouse_" .. ply:SteamID64(), 600, 0, function()
            for k, v in pairs(ahouse.HouseData.PlayerOwned[ply]) do
                if !v.owner or v.no_price then continue end
                
                local p = ahouse.HouseData.PropertyPrice(ply, id, true)
                
                if !ply:canAfford(p) then
                    DarkRP.notify(ply, 1, 3, DarkRP.getPhrase("cant_afford", house.name))
                    ahouse.HouseData.Sell(ply, k)
                else
                    ply:addMoney(-p)
                end
            end
        end)
    end
    
    ahouse.HouseData.PlayerOwned[ply] = ahouse.HouseData.PlayerOwned[ply] or {}
    ahouse.HouseData.PlayerOwned[ply][id] = {
        is_rent = is_rent,
        owner = true,
    }
    
    net.Start("ahouse_housedata")
        net.WriteUInt(2, 8)
        net.WriteUInt(id, 10)
        net.WriteEntity(ply)
    net.Broadcast()

    hook.Run("ahouse_afterbuy", ply, id, is_rent, rent_time, skip_buy)
    return true
end

// This function should be called if someone sell the door, even with keys
function ahouse.HouseData.Sell(ply, id)
    local plyInfos = ahouse.HouseData.PlayerOwned[ply]

    if !plyInfos or !plyInfos[id] then return end

    local house = ahouse.HouseData.List[id]
    local plyHouse = plyInfos[id]

    // So, he is not the owner ?
    if !plyHouse.owner then
        ahouse.HouseData.SafeLoop(id, function(door)
            door:removeKeysDoorOwner(ply)
            // Remove co-owners also
        end)

        ahouse.HouseData.PlayerOwned[ply][id] = nil
        return
    end

    if !plyHouse.is_rent and ahouse.Config.SellPerc and ahouse.Config.SellPerc > 0 and ahouse.Config.SellPerc < 1 then
        ply:addMoney(ahouse.HouseData.PropertyPrice(ply, id) * (ahouse.Config.SellPerc / 100))
    end

    ahouse.HouseData.SafeLoop(id, function(door)
        local doorData = door:getDoorData()
        door:removeAllKeysExtraOwners()
        door:setKeysTitle(nil)
        doorData.owner = nil
        ply.Ownedz[door:EntIndex()] = nil
        DarkRP.updateDoorData(door, "owner")
    end)

    // Clear data from old co-owners
    for plyFromTable, housetable in pairs(ahouse.HouseData.PlayerOwned) do
        if housetable[id] then
            ahouse.HouseData.PlayerOwned[plyFromTable][id] = nil
        end
    end

    ply.OwnedNumz = ply.OwnedNumz - 1
    ahouse.HouseData.PlayerOwned[ply][id] = nil

    if table.IsEmpty(ahouse.HouseData.PlayerOwned[ply]) then
        timer.Remove("ahouse_" .. ply:SteamID64())
    end

    if house.ents and IsValid(house.ents.mailbox) then
        house.ents.mailbox.ahouse_inv = {}
    end

    net.Start("ahouse_housedata")
        net.WriteUInt(3, 8)
        net.WriteUInt(id, 10)
    net.Broadcast()

    hook.Run("ahouse_sell", ply, id)

    // Notfication
end

function ahouse.HouseData.CoOwner(id, owner, ply, is_remove)
    local plyInfos = ahouse.HouseData.PlayerOwned[owner]

    if !plyInfos or !plyInfos[id] or !plyInfos[id].owner then return end

    ahouse.HouseData.PlayerOwned[ply] = ahouse.HouseData.PlayerOwned[ply] or {}
    ahouse.HouseData.PlayerOwned[ply][id] = {
        is_rent = is_rent,
        owner = false
    }

    // AHouse change the owner himself, or darkrp already did it ?
    hook.Run("ahouse_coowners", id, owner, ply, is_remove)
    if !partial then
        ahouse.HouseData.SafeLoop(id, function(door)
            if !is_remove then
                if ahouse.Config.NoForceOwner then
                    ahouse.detours.addKeysAllowedToOwn(door, ply)
                else
                    ahouse.detours.addKeysDoorOwner(door, ply)
                end
            else
                ahouse.detours.removeKeysDoorOwner(door, ply)
                door:removeKeysAllowedToOwn(ply)
            end
        end)
    end
end

function ahouse.HouseData.ToggleDoors(id, want_close)
    ahouse.HouseData.SafeLoop(id, function(door)
        door:Fire(want_close and "Close" or "Open")

        if want_close then
            door:Fire("Close")
            door:keysLock()
        else
            door:Fire("Open")
            door:keysUnLock()
        end
    end)
end

hook.Add("playerSellDoor", "ahouse_removeowner", function(ply, ent)
    if ent.ahouse_groupID and ahouse.HouseData.PlayerOwned[ply] then
        for k, v in pairs(ahouse.HouseData.PlayerOwned[ply]) do
            if ent.ahouse_groupID == k then
                local str = ahouse.HouseData.Sell(ply, k)

                if str then
                    return false, str
                end
            end
        end

        return false
    end
end)

hook.Add("playerBuyDoor", "ahouse_addowner", function(ply, ent)
    if ent.ahouse_groupID then
        return false, ahouse.HouseData.Buy(ply, ent.ahouse_groupID)
    end
end)

ahouse.detours = ahouse.detours or {}
local eMeta = FindMetaTable("Entity")

// I'm mad even thinking I need to detour this, why there no hook for this
hook.Add("PostGamemodeLoaded", "ahouse_detours", function()
    if !ahouse.detours.addKeysAllowedToOwn then
        ahouse.detours.addKeysAllowedToOwn = eMeta.addKeysAllowedToOwn
    
        function eMeta:addKeysAllowedToOwn(ply)
            // I get the owner instantly since darkrp already check if the owner is the right one
            ahouse.detours.addKeysAllowedToOwn(self, ply)
            if self.ahouse_groupID then
                // mettre owner sur toutes les autres portes
                ahouse.HouseData.CoOwner(self.ahouse_groupID, self:getDoorOwner(), ply, false, true)
            end
        end
    end
    
    if !ahouse.detours.addKeysDoorOwner then
        ahouse.detours.addKeysDoorOwner = eMeta.addKeysDoorOwner
    
        function eMeta:addKeysDoorOwner(ply)
            // I get the owner instantly since darkrp already check if the owner is the right one
            if self.ahouse_groupID then
                ahouse.HouseData.CoOwner(self.ahouse_groupID, self:getDoorOwner(), ply, false, true)
            end

            ahouse.detours.addKeysDoorOwner(self, ply)
        end
    end
    
    if !ahouse.detours.removeKeysDoorOwner then
        ahouse.detours.removeKeysDoorOwner = eMeta.removeKeysDoorOwner
    
        // No need to use playerDisconnect, darkrp is cool and will call this meta for us
        function eMeta:removeKeysDoorOwner(ply)
            // I get the owner instantly since darkrp already check if the owner is the right one
            ahouse.detours.removeKeysDoorOwner(self, ply)
    
            if self.ahouse_groupID then
                ahouse.HouseData.CoOwner(self.ahouse_groupID, self:getDoorOwner(), ply, true, true)
            end
        end
    end
end)

hook.Add("playerBuyDoor", "ahouse_disabledirectbuy", function(ply, ent)
    if ent.ahouse_groupID and ahouse.Config.BlockDirectBuy then
        return false
    end
end)

/*
    Seller related
*/
local seller = 0

function ahouse.IsSeller(ply)
    return ahouse.Config.Jobs[team.GetName(ply:Team())]
end

function ahouse.ThereSeller()
    return seller > 0
end

for k, v in ipairs(player.GetAll()) do
    if ahouse.IsSeller(v) then
        seller = seller + 1
    end
end

hook.Add("OnPlayerChangedTeam", "ahouse_getjobs", function(ply, before, after)
    local old = seller

    if ahouse.Config.Jobs[team.GetName(before)] then
        seller = seller - 1
    end

    if ahouse.Config.Jobs[team.GetName(after)] then
        seller = seller + 1
    end

    if (seller == 0) != (old == 0) and ahouse.Config.HideNPCOnSeller then
        local d = seller != 0

        for k, v in ipairs((ahouse.entities or {}).ahouse_npc or {}) do
            if !IsValid(v) then continue end
            v:SetNoDraw(d)
            v:DrawShadow(d)
            v:SetCollisionGroup(d and 20 or 9)
        end
    end
end)