ahouse.UserConfigs = ahouse.UserConfigs or {}
net.Receive("ahouse_sendpropconfig", function()
    local b = net.ReadBool()
    local house = net.ReadUInt(10)
    ahouse.UserConfigs[house] = ahouse.UserConfigs[house] or {}

    if b then
        for i = 1, net.ReadUInt(4) do
            local str = net.ReadString()
            local configid = net.ReadUInt(21)

            ahouse.UserConfigs[house][configid] = {
                house = house,
                name = str,
                configid = configid,
            }
        end
    else
        ahouse.UserConfigs[house][net.ReadUInt(21)] = nil
    end

    hook.Run("ahouse_ReceiveConfig", house)
end)