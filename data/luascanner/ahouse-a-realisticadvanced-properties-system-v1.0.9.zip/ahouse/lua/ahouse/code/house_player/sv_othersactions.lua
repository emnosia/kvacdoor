// Check if he spawn his things in his house
hook.Add("PlayerSpawnProp", "ahouse_propcheck", function(ply, model)
    if ahouse.Config.LimitPropSpawnToHouse == 2 and
        !ahouse.Config.BypassPropLimiter[ply:GetUserGroup()] and
        !ahouse.HouseData.VecInPlayerHouses(ply, ply:GetEyeTrace().HitPos) then

        ahouse.Notify(ply, "propspawn_1", 1)

        return false
    elseif ahouse.Config.LimitPropSpawnToHouse == 1 then
        local p = ply:GetEyeTrace().HitPos

        for k, v in pairs(ahouse.HouseData.List) do
            if ahouse.HouseData.VecInHouse(k, p) then
                local firstDoor = ahouse.HouseData.FirstSafeDoor(k)
                if !IsValid(firstDoor) then continue end

                if !firstDoor:isKeysOwnedBy(ply) then
                    ahouse.Notify(ply, "propspawn_1", 1)
                    return false
                end
            end
        end
    end
end)

function ahouse.HouseData.VecInPlayerHouses(ply, pos)
    local plyInfos = ahouse.HouseData.PlayerOwned[ply]
    if !plyInfos then return false end

    for houseID, _ in pairs(plyInfos) do
        if ahouse.HouseData.VecInHouse(houseID, pos) then
            return true
        end
    end

    return false
end

util.AddNetworkString("ahouse_openui")
function ahouse.HouseData.VerifyUINet(ply)
    if ply.ahouse_openIsNpc then
        local e = ply:GetEyeTrace().Entity
        return e:GetClass() == "ahouse_npc" and !e:GetNoDraw()
    end

    return ahouse.Config.AllowCommandUI or ahouse.IsSeller(ply)
end

function ahouse.HouseData.VerifyNet(ply, permission, houseid)
    // Needs a panel around him
    local house = ahouse.HouseData.List[houseid]

    if permission == 1 then
        if !house or !house.ents or
            !IsValid(house.ents.display) then return false end

        return ply:GetPos():DistToSqr(house.ents.display:GetPos()) < 512*512
    end

    return false
end

function ahouse.HouseData.OpenUI(ply, is_npc)
    ply.ahouse_openIsNpc = is_npc

    if is_npc then
        local e = ply:GetEyeTrace().Entity
        if e:GetClass() != "ahouse_npc" or e:GetNoDraw() then return end
    end

    net.Start("ahouse_openui")
    net.Send(ply)
end

hook.Add("PlayerSay", "ahouse_command", function(ply, txt)
    local c = ahouse.Config.Command
    local isValidCmd = (string.StartWith(txt, "!" .. c) or string.StartWith(txt, "/" .. c))

    if isValidCmd and (ahouse.Config.AllowCommandUI or ahouse.IsSeller(ply)) then
        ahouse.HouseData.OpenUI(ply, false)
    end
end)

util.AddNetworkString("ahouse_askdisplay")
util.AddNetworkString("ahouse_shop")

ahouse.SafeNet("askdisplay", function(ply)
    local id = net.ReadUInt(10)
    local pos = {}

    if !ahouse.HouseData.List[id] then return end

    for k, v in ipairs(ahouse.HouseData.List[id].viewList) do
        table.insert(pos, (v.endpos - v.pos)/2 + v.pos)
    end

    ply.ahouseDisplay = pos
end, 0.1)

ahouse.SafeNet("shop", function(ply)
    local id = net.ReadUInt(3)
    local houseid = net.ReadUInt(10)

    if !ahouse.HouseData.VerifyUINet(ply) then return end
    
    if id == 0 or id == 1 then
        if ahouse.Config.PermanentHousing and id == 1 then
            local rent_days = net.ReadUInt(16)

            if rent_days > ahouse.Config.PermanentHousing.BuyTime / ahouse.Config.RentTime then return end

            ahouse.HouseData.Buy(ply, houseid, true, rent_days)
        else
            ahouse.HouseData.Buy(ply, houseid, id == 1)
        end
    elseif id == 2 then
        ahouse.HouseData.Sell(ply, houseid)
    elseif id == 3 then
        local ent = net.ReadEntity()
        local commissionPrice = net.ReadUInt(24)
        local is_rent = net.ReadBool()
        local days

        if ahouse.Config.PermanentHousing.Enabled and is_rent then
            days = net.ReadUInt(16)
        end

        if !IsValid(ent) then return end
        ahouse.create_contract(houseid, ply, ent, is_rent, days, commissionPrice)
    elseif id == 4 then
        if !ahouse.Config.PermanentHousing.Enabled then return end
        if !ahouse.HouseData.PlayerOwned[ply] or !ahouse.HouseData.PlayerOwned[ply][houseid] then return end
        // Re-Rent
        local c = ahouse.Config.PermanentHousing
        local t = ahouse.permanentHousing.data[houseid]

        local days = net.ReadUInt(16)
        local maxDays = math.ceil(c.BuyTime / ahouse.Config.RentTime)
        local actualDays = math.ceil(t.relativeTime / ahouse.Config.RentTime)

        local maxValue = maxDays - days - actualDays

        if maxValue < 0 or days == 0 then return end

        local price = ahouse.HouseData.PropertyPrice(ply, houseid, true, nil, days)

        if !ply:canAfford(price) then
            DarkRP.notify(ply, 1, 3, DarkRP.getPhrase("cant_afford", house.name))
            return
        end

        ply:addMoney(-price)

        // Save it
        ahouse.permanentHousing.data[houseid].time = ahouse.permanentHousing.data[houseid].time + (days * ahouse.Config.RentTime)
        ahouse.permanentHousing.data[houseid].relativeTime = ahouse.permanentHousing.data[houseid].relativeTime + (days * ahouse.Config.RentTime)

        net.Start("ahouse_housedata")
            net.WriteUInt(7, 8)
            net.WriteUInt(1, 8)

            net.WriteUInt(houseid, 10)
            net.WriteUInt(ahouse.permanentHousing.data[houseid].relativeTime, 20)
        net.Send(ply)
        ahouse.SQL.query('UPDATE ahouse_permanentproperties SET time = time + ' .. (days * ahouse.Config.RentTime) .. " WHERE house = " .. houseid .. " AND owner = '" .. ply:SteamID64() .. "'")
    end
end, 0.25)

hook.Add("SetupPlayerVisibility", "ahouse_adddisplay", function(ply)
    if ply.ahouseDisplay then
        for k, v in ipairs(ply.ahouseDisplay) do
            AddOriginToPVS(v)
        end
    end
end)

local blockedEnts = {
    ["ahouse_intercom"] = true,
    ["ahouse_hole"] = true,
    ["ahouse_mailbox"] = true,
    ["ahouse_3d2dui"] = true,
}
hook.Add("PhysgunPickup", "ahouse_protectents", function(ply, ent)
    if blockedEnts[ent:GetClass()] then return false end
end)

//
ahouse.SafeNet("house_config", function(ply)
    local uid = net.ReadUInt(10)
    local house = ahouse.HouseData.List[uid]

    if !house then return end

    local action = net.ReadUInt(4)
    if !ahouse.HouseData.PlayerOwned[ply] or !ahouse.HouseData.PlayerOwned[ply][uid] then return end

    if action == 0 then
        if !ahouse.HouseData.VerifyUINet(ply) then return end
        local n = net.ReadString()

        if string.len(n) < 4 or string.len(n) > 20 then return end
        ahouse.Props.Create(n, ply, uid)
        // ply.ahouse_configs[uid][name]
    elseif action == 1 then
        if !ahouse.HouseData.VerifyUINet(ply) then return end
        ahouse.Props.Setup(ply, uid, net.ReadUInt(24))
    elseif action == 2 then
        if !ahouse.HouseData.VerifyUINet(ply) then return end
        ahouse.Props.Delete(ply, uid, net.ReadUInt(24))
    elseif action == 3 then
        if !ahouse.HouseData.VerifyUINet(ply) then return end
        if !IsValid(house.ents.doorbell) then return end

        house.disabledbell = !house.disabledbell
        house.ents.doorbell:SetNoDraw(house.disabledbell)

        net.Start("ahouse_housedata")
            net.WriteUInt(6, 8)
            net.WriteUInt(uid, 10)
            net.WriteBool(house.disabledbell)
        net.Broadcast()
    end
end, 0.5)