local PANEL = {}

local function checkOwner(ply, index)
    local d = DarkRP.doorData[index]
    local uid = ply:UserID()

    return (d.extraOwners or {})[uid] or (d.allowedToOwn or {})[uid] or d.owner == uid
end

function PANEL:Build(houseid, avoidMargin)
    local firstDoor = ahouse.HouseData.FirstSafeDoor(houseid)

    if IsValid(firstDoor) then
        firstDoor = firstDoor:EntIndex()
    else
        firstDoor = ahouse.HouseData.List[houseid].firstDoorIndex
    end

    local margin = ahouse.GetMargin(1)
    local margin2 = ahouse.GetMargin(0.5)
    local buttonTall = ahouse.getfontheight("ahouse_16") + margin2

    if !avoidMargin then
        self:DockPadding(margin, margin, margin, margin)
    end

    local s = vgui.Create("DScrollPanel", self)
    s:Dock(FILL)

    local d = vgui.Create("DIconLayout", s)
    d:Dock(FILL)
    d:SetSpaceX(margin2)
    d:SetSpaceY(margin2/2)

    local buttonWSize = math.floor((self:GetWide() - margin*2 - math.ceil(margin2))/2)

    if avoidMargin then
        buttonWSize = math.floor((self:GetWide() - math.ceil(margin2))/2)
    end

    local local_ply = LocalPlayer()
    for k, v in ipairs(player.GetAll()) do
        if v == local_ply then continue end

        local b = d:Add("DButton")
        b:SetText(v:Nick())
        b:SetTextColor(ahouse.Config.Colors.White)
        b:SetFont("ahouse_16")
        b:SetSize(buttonWSize, buttonTall)

        function b:Paint(w, h)
            draw.RoundedBox(ahouse.GetCorner(), 0, 0, w, h, !(checkOwner(v, firstDoor)) and
                ahouse.Config.Colors.SubBackground or ahouse.Config.Colors.BlackGreen)
        end

        function b:DoClick()
            if !IsValid(v) then return end

            net.Start("ahouse_coowners")
                net.WriteUInt(houseid, 10)
                net.WriteEntity(v)
            net.SendToServer()
        end

        ahouse.UI.AddHoverTimer(b, 3)

        first = true

        if checkOwner(v, firstDoor) then
            b.perc = 1
        end
    end

    ahouse.UI.QuitOnClick(self)
end

function PANEL:Init()
    local oldLayout = self.PerformLayout

    function PANEL:PerformLayout()
        oldLayout(self)
        self.bgahouse = nil
    end
end

function PANEL:Paint(w, h)
    if !self.bgahouse then
        self.bgahouse = ahouse.UI.Background(self, w, h)
    end
    self.bgahouse()
end

derma.DefineControl( "ahouse_coowners", "", PANEL, "DPanel" )