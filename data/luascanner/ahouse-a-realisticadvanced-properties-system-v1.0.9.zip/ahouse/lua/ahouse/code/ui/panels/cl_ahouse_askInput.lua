// f l u x s h e n a n i g a n s

local PANEL = {}

function PANEL:Init()
    self:MakePopup()
    self:SetSize(ScrW() * 0.256, ScrH() * 0.110)
    self:Center()
    self:SetMouseInputEnabled(true)
    self:SetKeyboardInputEnabled(true)

    local m = self:GetWide()*0.05
    self:DockPadding(m, m, m, m)

    self.inputList = {}

    local n = vgui.Create("DLabel", self)
    n:SetText("Missing text")
    n:Dock(TOP)
    n:SetFont("ahouse_16")
    n:SetTextColor(ahouse.Config.Colors.White60)
    self.n = n

    local h = ahouse.getfontheight("ahouse_20")
    local cont = vgui.Create("EditablePanel", self)
    cont:Dock(BOTTOM)
    cont:DockMargin(0, 0, 0, 0)
    cont:SetTall(h * 1.5)
    self.cont = cont

    local but = vgui.Create("DButton", cont)
    but:Dock(RIGHT)
    but:SetText( ":/" )
    but:SetFont( "ahouse_20" )
    but:DockPadding(5, 5, 5, 5)
    but:DockMargin(h/2, 0, 0, 0)
    but:SetWidth(but:GetTextSize() + h)
    but:SetTextColor(ahouse.Config.Colors.White)
    self.but = but

    local main = self
    function but:DoClick()
        if main.func then
            local entries = {}

            for k, v in ipairs(main.inputList) do
                if v.GetText then
                    entries[k] = {v,v:GetText()}
                elseif v.GetSelected then
                    local a, b = v:GetSelected()
                    entries[k] = {v, a, b}
                end
            end

            main.func(self, main, unpack(entries))
        end
    end

    local margin = ahouse.GetCorner()
    function but:Paint(w, h)
        draw.RoundedBox(margin, 0, 0, w, h, ahouse.Config.Colors.BlackGreen)
    end

    ahouse.UI.QuitOnClick(self)
end

function PANEL:Paint(w, h)
    if !self.bgahouse then
        self.bgahouse = ahouse.UI.Background(self, w, h, 15)
    end
    self.bgahouse()
end

function PANEL:SetTitle(txt)
    self.n:SetText(txt)
end

function PANEL:SetTextButton(txt)
    self.but:SetText(txt)
    self.but:SetWidth(self.but:GetTextSize() + ahouse.getfontheight("ahouse_20"))
end

function PANEL:CreateEntryComboBox(onSelect)
    local h = ahouse.getfontheight("ahouse_20")
    local firstPanel = table.IsEmpty(self.inputList)
    local c = vgui.Create("EditablePanel", firstPanel and self.cont or self)
    c:Dock(firstPanel and FILL or BOTTOM)
    c:DockMargin(0, 0, 0, firstPanel and 0 or h/2)
    c:SetTall(h * 1.5)

    local te = vgui.Create("DComboBox", c)
    te:Dock(FILL)
    te:SetFont("ahouse_20")
    te:SetPaintBackground(false)
    te:DockMargin(ahouse.getfontheight("ahouse_20")/2, 0, 0, 0)
    te:SetTextInset(0, 0)
    te:SetContentAlignment(4)
    te:SetTextColor(ahouse.Config.Colors.White)

    if onSelect then
        te.OnSelect = onSelect
    end

    function te:Paint() end

    local margin = ahouse.GetCorner()
    function c:Paint(w, h)
        if ( te:HasFocus() ) then
            draw.RoundedBox(margin, 0, 0, w, h, ahouse.Config.Colors.BlackGreen)
        else
            draw.RoundedBox(margin, 0, 0, w, h, ahouse.Config.Colors.SubBackground)
        end
    end

    if !table.IsEmpty(self.inputList) then
        self:SetTall(self:GetTall() + ahouse.getfontheight("ahouse_20") * 1.5 + h/2)
        self:Center()
    end

    table.insert(self.inputList, te)
    return te
end


function PANEL:CreateEntry(txt, onlyNumeric, minChar, maxChar)
    local h = ahouse.getfontheight("ahouse_20")
    local firstPanel = table.IsEmpty(self.inputList)
    local c = vgui.Create("EditablePanel", firstPanel and self.cont or self)
    c:Dock(firstPanel and FILL or BOTTOM)
    c:DockMargin(0, 0, 0, firstPanel and 0 or h/2)
    c:SetTall(h * 1.5)

    local te = vgui.Create("DTextEntry", c)
    te:Dock(FILL)
    te:SetFont( "ahouse_20" )
    te:SetPlaceholderText( txt )
    te:DockMargin(h/2, 0, 0, 0)
    te:SetDrawLanguageIDAtLeft( false )
    te:SetDrawLanguageID(false)
    te:SetNumeric(onlyNumeric)
    te:SetPlaceholderColor(ahouse.Config.Colors.White60)

    local margin = ahouse.GetCorner()
    function c:Paint(w, h)
        if ( te:HasFocus() ) then
            draw.RoundedBox(margin, 0, 0, w, h, ahouse.Config.Colors.BlackGreen)
        else
            draw.RoundedBox(margin, 0, 0, w, h, ahouse.Config.Colors.SubBackground)
        end
    end

    function te:Paint(w, h)
        if ( self.GetPlaceholderText && self.GetPlaceholderColor && self:GetPlaceholderText() && self:GetPlaceholderText():Trim() != "" && self:GetPlaceholderColor() && ( !self:GetText() || self:GetText() == "" ) ) then
    
            local oldText = self:GetText()
    
            local str = self:GetPlaceholderText()
            if ( str:StartWith( "#" ) ) then str = str:sub( 2 ) end
            str = language.GetPhrase( str )
    
            self:SetText( str )
            self:DrawTextEntryText( self:GetPlaceholderColor(), self:GetHighlightColor(), self:GetCursorColor() )
            self:SetText( oldText )
    
            return
        end
    
        self:DrawTextEntryText( self:HasFocus() and ahouse.Config.Colors.White or ahouse.Config.Colors.White60, self:GetHighlightColor(), self:GetCursorColor() )
    end

    if !table.IsEmpty(self.inputList) then
        self:SetTall(self:GetTall() + ahouse.getfontheight("ahouse_20") * 1.5 + h/2)
        self:Center()
    end

    if onlyNumeric then
        te:SetNumeric(true)
    end

    if minChar or maxChar then
        if minChar and maxChar then
            te:SetPlaceholderText(txt .. " (" .. minChar .. "-" .. maxChar .. ")")
        elseif minChar then
            te:SetPlaceholderText(txt .. " (" .. minChar .. " letters min)")
        else
            te:SetPlaceholderText(txt .. " (" .. maxChar .. " letters max)")
        end

        function te:AllowInput(char)
            if maxChar <= #te:GetText() then
                return false
            end
        end
    end

    table.insert(self.inputList, te)
    return te
end

function PANEL:SetCallback(func)
    self.func = func
end

derma.DefineControl( "ahouse_AskInput", "", PANEL, "EditablePanel" )