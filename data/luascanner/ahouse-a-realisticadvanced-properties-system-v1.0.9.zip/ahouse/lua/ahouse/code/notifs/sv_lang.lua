util.AddNetworkString("ahouse_notify")

function ahouse.Notify(plys, txt, type, length, ...)
    net.Start("ahouse_notify")
        // Flux shenanigans
        if ahouse.lang.StrToID[txt] then
            net.WriteBool(true)
            net.WriteUInt(ahouse.lang.StrToID[txt], 12)
            local args = {...}

            net.WriteUInt(#args, 3)

            for _, v in ipairs(args) do
                net.WriteString(v)
            end
        else
            net.WriteBool(false)
            net.WriteString(txt)
        end

        net.WriteInt(type or 0, 5)
        net.WriteInt(length or 4, 5)
    net.Send(plys)
end