file.CreateDir("ahouse")
util.AddNetworkString("ahouse_housedata")
util.AddNetworkString("ahouse_plyconfig")

/*
    Load player
*/
local function load_plyconfig(ply)
    // Send his player config
    ahouse.SQL.query("SELECT * FROM ahouse_playerinfos WHERE owner = '" .. ply:SteamID64() .. "'", function(q)
        if !IsValid(ply) then return end
        if !q then
            ahouse.SQL.query("INSERT INTO ahouse_playerinfos(owner) VALUES('" .. ply:SteamID64() .. "')", function()
                if !IsValid(ply) then return end
                load_plyconfig(ply)
            end)
        else
            ply.ahouse_ringbell = tonumber(q[1].ringbell_id)

            net.Start("ahouse_plyconfig")
            net.WriteUInt(ply.ahouse_ringbell, 5)
            net.Send(ply)
        end
    end)
end

// Register
ahouse.SafeNet("plyconfig", function(ply)
    local uid = net.ReadUInt(5)

    if !ahouse.Config.RingbellSounds[uid] then return end

    ply.ahouse_ringbell = uid

    net.Start("ahouse_plyconfig")
        net.WriteUInt(uid, 5)
    net.Send(ply)

    ahouse.SQL.query([[UPDATE ahouse_playerinfos SET ringbell_id = ]] .. uid .. [[ WHERE owner = ']] .. ply:SteamID64() .. "'")
end, 0.33)

local load_queue = {}

local function sendConfig(ply)
    // Not now
    if !ahouse.HouseData.List then
        load_queue[ply] = true
        return
    end

    net.Start("ahouse_housedata")
    net.WriteUInt(0, 8)

    net.WriteUInt(table.Count(ahouse.HouseData.List), 10)
    for k, v in pairs(ahouse.HouseData.List) do
        ahouse.HouseData.WriteHouseStruct(v)
    end
    net.Send(ply)

    if istable(ply) then
        for k, v in ipairs(ply) do
            load_plyconfig(v)
        end
    else
        load_plyconfig(ply)
    end
end

hook.Add("PlayerInitialSpawn", "ahouse_load", function(ply)
    load_queue[ply] = true
end)

hook.Add("SetupMove", "ahouse_load", function(ply, _, cmd)
	if load_queue[ply] and !cmd:IsForced() then
		load_queue[ply] = nil
        sendConfig(ply)
	end
end)

/*
    First load the house list, put it in cache
*/
// Doors
function ahouse.HouseData.Load()
    //if ahouse.HouseData.List then return end
    local l = {}

    // Async meme, we do the 3 queries in any order, we don't mind if a query is finished before another one
    local actions = 2

    local function onFinished()
        if actions == 1 then
            ahouse.HouseData.List = l

            // Get map doors
            ahouse.WaitPostInit(function()
                for k, v in pairs(l) do
                    hook.Run("ahouse_inithouse", k)
                end
    
                hook.Run("ahouse_houseloaded")
    
                // Someone already connected ? This is weird
                local plyList = {}
                for k, v in pairs(load_queue) do
                    table.insert(plyList, k)
                end
    
                sendConfig(plyList)
                load_queue = {}
            end)
        else
            actions = actions - 1
        end
    end

    ahouse.SQL.query('SELECT * FROM ahouse_houses WHERE map = "' .. game.GetMap() .. '"', function(q)
        for k, v in ipairs(q or {}) do
            l[tonumber(v.houseid)] = l[tonumber(v.houseid)] or {}
            local d = {
                houseid = tonumber(v.houseid),
                name = v.name,
                price = tonumber(v.price),
                rent_price = tonumber(v.rent_price),
                type = tonumber(v.type),
                display_pos = Vector(tonumber(v.display_pos_x), tonumber(v.display_pos_y), tonumber(v.display_pos_z)),
                display_ang = tonumber(v.display_ang),
                vecs = {
                    Vector(tonumber(v.min_x), tonumber(v.min_y), tonumber(v.min_z)),
                    Vector(tonumber(v.max_x), tonumber(v.max_y), tonumber(v.max_z)),
                }
            }

            if v.rpos_x then
                d.rPos = Vector(tonumber(v.rpos_x), tonumber(v.rpos_y), tonumber(v.rpos_z))
                d.rAng = tonumber(v.rang)
            end

            if v.display_pos_x then
                d.display_pos = Vector(tonumber(v.display_pos_x), tonumber(v.display_pos_y), tonumber(v.display_pos_z))
                d.display_ang = tonumber(v.display_ang)
            end

            if v.letterbox_pos_x then
                d.letterbox_pos = Vector(tonumber(v.letterbox_pos_x), tonumber(v.letterbox_pos_y),tonumber( v.letterbox_pos_z))
                d.letterbox_ang = tonumber(v.letterbox_ang)
                d.letterbox_ground = tonumber(v.letterbox_ground) == 1
            end

            d.have_alarm = tonumber(v.have_alarm) == 1

            table.Merge(l[tonumber(v.houseid)], d)
        end

        onFinished()
    end)

    ahouse.SQL.query('SELECT vp_x, vp_y, vp_z, vp_a_r, vp_a_y, vp_a_p, vp_f_x, vp_f_y, vp_f_z, vp_fa_r, vp_fa_y, vp_fa_p, rendertime, renderorder, house FROM ahouse_viewpoints, ahouse_houses WHERE house = houseid and map = "' .. game.GetMap() .. '"', function(q)
        for k, v in ipairs(q or {}) do
            local n = tonumber(v.house)
            l[n] = l[n] or {}
            l[n].viewList = l[n].viewList or {}

            l[n].viewList[tonumber(v.renderorder)] = {
                renderorder = tonumber(v.renderorder),
                pos = Vector(tonumber(v.vp_x), tonumber(v.vp_y), tonumber(v.vp_z)),
                endpos = Vector(tonumber(v.vp_f_x), tonumber(v.vp_f_y), tonumber(v.vp_f_z)),
                ang = Angle(tonumber(v.vp_a_p), tonumber(v.vp_a_y), tonumber(v.vp_a_r)),
                endang = Angle(tonumber(v.vp_fa_p), tonumber(v.vp_fa_y), tonumber(v.vp_fa_r)),
                rendertime = tonumber(v.rendertime)
            }
        end

        onFinished()
    end)
end

function ahouse.HouseData.Add(name, price, rent_price, rPos, rAng, display_pos, display_ang, viewList, min, max, letterbox_pos, letterbox_ang, type, have_alarm)
    if !viewList then
        print("[AHouse] Aborted new house, You need atleast one view point")
        return false
    end

    // Flip burgers
    // We use that because inverted min/max can break OOB detection for the modify tool
    local newMin = Vector(
        math.min(min.x, max.x),
        math.min(min.y, max.y),
        math.min(min.z, max.z)
    )

    local newMax = Vector(
        math.max(max.x, min.x),
        math.max(max.y, min.y),
        math.max(max.z, min.z)
    )

    min = newMin
    max = newMax

    local f = false
    for k, v in ipairs(ents.FindInBox(newMin, newMax)) do
        if ahouse.HouseData.IsDoor(v) then
            f = true
            break
        end
    end

    if !f then
        print("[AHouse] The new house doesn't have doors, aborted new house")
        return
    end

    // Low cost query builder
    local queryParams = {"name", "map", "price","rent_price","type", "min_x","min_y","min_z","max_x","max_y","max_z", "have_alarm"}
    local queryValues = {
        ahouse.SQL.escape(name), ahouse.SQL.escape(game.GetMap()), price, rent_price, type,
        min.x, min.y, min.z, max.x, max.y, max.z, have_alarm and 1 or 0}

    for k, v in pairs({
        ["display_"] = {display_pos, display_ang},
        ["letterbox_"] = {letterbox_pos, letterbox_ang and letterbox_ang.y or nil},
        ["r"] = {rPos, rAng}
    }) do
        if v[1] then
            table.insert(queryParams, k .. "pos_x")
            table.insert(queryParams, k .. "pos_y")
            table.insert(queryParams, k .. "pos_z")
            table.insert(queryParams, k .. "ang")

            table.insert(queryValues, v[1].x)
            table.insert(queryValues, v[1].y)
            table.insert(queryValues, v[1].z)
            table.insert(queryValues, v[2])
        end
    end

    local letterboxground
    if letterbox_ang then
        letterboxground = (letterbox_ang.x > 245 and letterbox_ang.x < 295) and 1 or 0
        table.insert(queryParams, "letterbox_ground")
        table.insert(queryValues, letterboxground)
    end

    local q = [[INSERT INTO ahouse_houses(%s) VALUES(%s)]]

    q = string.format(q,
        table.concat(queryParams, ", "),
        table.concat(queryValues, ", "))

    ahouse.SQL.query(q, function(data, queryObject)
        local id
        if ahouse.Config.MySQL.enable then
            id = queryObject:lastInsert()
        else
            ahouse.SQL.query("select last_insert_rowid() as id;", function(d)
                id = tonumber(d[1].id)
            end)
        end

        ahouse.HouseData.List[id] = {
            houseid = id,
            name = name,
            price = price,
            rent_price = rent_price,
            rPos = rPos,
            rAng = rAng,
            type = type,
            display_pos = display_pos,
            display_ang = display_ang and math.Round(display_ang) or nil,
            letterbox_pos = letterbox_pos,
            letterbox_ang = letterbox_ang and letterbox_ang.y or nil,
            letterbox_ground = !letterboxground and nil or tobool(letterboxground),
            viewList = viewList,
            vecs = {
                min,
                max
            }
        }

        for k, v in ipairs(viewList) do
            local s = [[INSERT INTO ahouse_viewpoints(
                vp_x, vp_y, vp_z, vp_a_p, 
                vp_a_y, vp_a_r, vp_f_x, vp_f_y, 
                vp_f_z, vp_fa_p, vp_fa_y, vp_fa_r, 
                rendertime, renderorder, house)
            VALUES(
                %d, %d, %d, %d, 
                %d, %d, %d, %d, 
                %d, %d, %d, %d, 
                %d, %d, %d)]]

            ahouse.SQL.query(string.format(s,
                v.pos.x, v.pos.y, v.pos.z, v.ang.p,
                v.ang.y, v.ang.r, v.endpos.x, v.endpos.y,
                v.endpos.z, v.endang.p, v.endang.y, v.endang.r,
                v.rendertime, v.renderorder, id
            ))
        end

        hook.Run("ahouse_inithouse", id)

        // Refresh config
        net.Start("ahouse_housedata")
            net.WriteUInt(1, 8) // Add a single house
            ahouse.HouseData.WriteHouseStruct(ahouse.HouseData.List[id])
        net.Broadcast()
    end)
end

function ahouse.HouseData.Remove(id)
    if !ahouse.HouseData.List[id] then return end

    for ply, data in pairs(ahouse.HouseData.PlayerOwned) do
        if ahouse.HouseData.PlayerOwned[ply] then
            local d = ahouse.HouseData.PlayerOwned[ply][id]
            if !d or !d.owner then continue end

            ahouse.HouseData.Sell(ply, id)
            break
        end
    end

    for k, v in pairs(ahouse.doorIDs[id]) do
        v.ahouse_groupID = nil
    end

    local l = ahouse.HouseData.List[id]
    for k, v in pairs(l.ents or {}) do
        v:Remove()
    end

    net.Start("ahouse_housedata")
        net.WriteUInt(5, 8)
        net.WriteUInt(id, 10)
    net.Broadcast()

    ahouse.HouseData.List[id] = nil
    ahouse.doorIDs[id] = nil

    ahouse.SQL.query("DELETE FROM ahouse_houses WHERE houseid = " .. id)
end

// Register
ahouse.SafeNet("coowners", function(ply)
    local uid = net.ReadUInt(10)

    if !ahouse.HouseData.PlayerOwned[ply] or !ahouse.HouseData.PlayerOwned[ply][uid] then return end
    if !ahouse.HouseData.VerifyNet(ply, 1, uid) and !ahouse.HouseData.VerifyUINet(ply) then return end

    local e = net.ReadEntity()

    if !IsValid(e) or !e:IsPlayer() then return end

    local fd = ahouse.HouseData.FirstSafeDoor(uid)
    if !IsValid(fd) then return end

    ahouse.HouseData.CoOwner(uid, ply, e, fd:isKeysOwnedBy(e))
end, 0.25)

ahouse.SafeNet("house_manage", function(ply)
    local display = net.ReadEntity()
    local uid = net.ReadUInt(10)
    local house = ahouse.HouseData.List[uid]

    if !house or !IsValid(display) or
        display:GetClass() != "ahouse_3d2dui" or display.houseid != uid or display:GetPos():DistToSqr(ply:GetPos()) > 400*400 then return end

    local action = net.ReadUInt(4)

    if action == 0 then
        if !IsValid(house.ents.doorbell) then return end
        if !ahouse.HouseData.PlayerOwned[ply] or !ahouse.HouseData.PlayerOwned[ply][uid] then return end
        if !ahouse.HouseData.VerifyNet(ply, 1, uid) then return end

        house.disabledbell = !house.disabledbell
        house.ents.doorbell:SetNoDraw(house.disabledbell)

        net.Start("ahouse_housedata")
            net.WriteUInt(6, 8)
            net.WriteUInt(uid, 10)
            net.WriteBool(house.disabledbell)
        net.Broadcast()
    elseif action == 2 then
        if !ahouse.HouseData.PlayerOwned[ply] or !ahouse.HouseData.PlayerOwned[ply][uid]
            or !ahouse.HouseData.VerifyNet(ply, 1, uid) then return end
        ahouse.HouseData.Sell(ply, uid)
    elseif action == 3 then
        if !ahouse.HouseData.VerifyNet(ply, 1, uid) or ahouse.Config.BlockDirectBuy then return end
        ahouse.HouseData.Buy(ply, uid)
    elseif action == 4 then
        local e = house.ents

        if e and e.doorbell and IsValid(e.doorbell) and e.doorbell:GetPos():DistToSqr(ply:GetPos()) < 256 * 256 then
            e.doorbell:Use(ply)
        end
    elseif action == 5 or action == 6 then
        if !ahouse.HouseData.PlayerOwned[ply] or !ahouse.HouseData.PlayerOwned[ply][uid]
        or !ahouse.HouseData.VerifyNet(ply, 1, uid) then return end

        ahouse.HouseData.ToggleDoors(uid, action == 6)
        ahouse.Notify(ply, action == 6 and "closed_doors" or "open_doors", 1)
    end
end, 0.5)

net.Receive("ahouse_housedata", function(_, ply)
    if !ply:IsSuperAdmin() then return end

    // Check if there no door
    local id = net.ReadUInt(4)
    if id == 0 then
        local name = net.ReadString()

        if string.len(name) < 4 or string.len(name) > 24 then
            return
        end

        local rent = net.ReadUInt(24)
        local price = net.ReadUInt(24)
        local houseMin = net.ReadVector()
        local houseMax = net.ReadVector()
        local type = net.ReadUInt(2)
        local rep = net.ReadUInt(3)
        if !ahouse.lang.l["property_" .. type] then return end
        local views = {}

        for i = 1, rep do
            local t = {
                pos = net.ReadVector(),
                endpos = net.ReadVector(),
                ang = net.ReadAngle(),
                endang = net.ReadAngle(),
                renderorder = i,
            }

            local d = t.pos:Distance(t.endpos)

            if d > 200 then
                t.rendertime = d / 100
            else
                t.rendertime = ahouse.Config.DisplayHoldTime
            end

            views[i] = t
        end

        local d = {}
        for i = 1, 3 do
            local t = {}
            local b = net.ReadBool()

            if b then
                t[1] = net.ReadVector()
                t[2] = net.ReadAngle()
            end

            d[i] = t
        end

        ahouse.HouseData.Add(name, price, rent, d[1][1], d[1][2] and d[1][2].y or nil, d[3][1], d[3][2] and d[3][2].y or nil, views, houseMin, houseMax,
            d[2][1], d[2][2], type, net.ReadBool())

        // TODO: Maybe add rank ?
    elseif id == 1 then
        local house = net.ReadUInt(10)

        local data = ahouse.HouseData.List[house]
        if !data then return end

        data.name = net.ReadString()

        if string.len(data.name) < 4 or string.len(data.name) > 24 then
            return
        end

        data.rent_price = net.ReadUInt(24)
        data.price = net.ReadUInt(24)
        data.type = net.ReadUInt(2)
        data.have_alarm = net.ReadBool()

        if !ahouse.lang.l["property_" .. data.type] then return end
        
        local q = [[UPDATE ahouse_houses SET name = %s, rent_price = %s, price = %s, type = %s, have_alarm = %s WHERE houseid = %s]]
        q = string.format(q, ahouse.SQL.escape(data.name), data.rent_price, data.price, data.type, tonumber(have_alarm), house)
        ahouse.SQL.query(q)

        net.Start("ahouse_housedata")
            net.WriteUInt(4, 8)
            net.WriteUInt(house, 10)
            net.WriteString(data.name)
            net.WriteUInt(data.rent_price, 24)
            net.WriteUInt(data.price, 24)
            net.WriteUInt(data.type, 2)
            net.WriteBool(data.have_alarm)
        net.Broadcast()
    elseif id == 2 then
        local house = net.ReadUInt(10)
        ahouse.HouseData.Remove(house)
    end
end)

if ahouse.Config.RotatePrice.Enabled then
    SetGlobalFloat( "ahouse_float", math.Rand(ahouse.Config.RotatePrice.Min,
        ahouse.Config.RotatePrice.Max) )

    timer.Create("ahouse_rotateprice", ahouse.Config.RotatePrice.Time, 0, function()
        SetGlobalFloat( "ahouse_float", math.Rand(ahouse.Config.RotatePrice.Min,
            ahouse.Config.RotatePrice.Max) )
    end)
else
    SetGlobalFloat( "ahouse_float", 1 )
end

//
function ahouse.HouseData.WriteHouseStruct(data)
    if !IsValid(ahouse.HouseData.FirstSafeDoor(data.houseid)) then
        net.WriteBool(false)
        return
    end

    net.WriteBool(true)

    net.WriteUInt(data.houseid, 10)
    net.WriteString(data.name)
    net.WriteUInt(data.price, 32)
    net.WriteUInt(data.rent_price, 32)
    net.WriteUInt(data.type, 2)
    
    net.WriteUInt(table.Count(data.viewList or {}), 3)
    for a, b in ipairs(data.viewList or {}) do
        net.WriteUInt(b.renderorder, 8)
        net.WriteVector(b.pos)
        net.WriteAngle(b.ang)
        net.WriteVector(b.endpos)
        net.WriteAngle(b.endang)
        net.WriteUInt(b.rendertime, 8)
    end

    net.WriteUInt(table.Count(data.ents or {}), 3)
    for k, v in pairs(data.ents or {}) do
        net.WriteUInt(v:EntIndex(), 13)
    end

    // Send one door index, to get owners clientside
    local e = ahouse.HouseData.FirstSafeDoor(data.houseid)
    net.WriteUInt(e:EntIndex(), 13)

    net.WriteBool(data.disabledbell)
    net.WriteVector(data.vecs[1])
    net.WriteVector(data.vecs[2])

    net.WriteBool(data.have_alarm)
end

concommand.Add("ahouse_removeinvalidhouses", function(ply)
    if !IsValid(ply) then
        for k, v in pairs(ahouse.HouseData.List) do
            if !IsValid(ahouse.HouseData.FirstSafeDoor(k)) then
                ahouse.HouseData.Remove(k)
            end
        end
    end
end )