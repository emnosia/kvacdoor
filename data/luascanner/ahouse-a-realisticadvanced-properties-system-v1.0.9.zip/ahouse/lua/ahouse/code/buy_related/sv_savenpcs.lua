local ent = {
    ["ahouse_printer"] = true,
    ["ahouse_npc"] = true,
}

local function ReloadNPC()
    local datas = file.Read("ahouse/npcdata.json")

    if datas then
        local datatbl = util.JSONToTable(datas)

        if datatbl then
            for k, v in ipairs(ents.GetAll()) do
                if ent[v:GetClass()] then
                    v:Remove()
                end
            end

            // create new
            local entList = {}

            for k, v in ipairs(datatbl) do
                local ent = ents.Create(v.class)

                if IsValid(ent) then
                    ent:SetPos(v.pos)
                    ent:SetAngles(v.ang)
                    ent:Spawn()
                    ent:Activate()

                    entList[v.class] = entList[v.class] or {}
                    table.insert(entList[v.class], ent)
                end
            end
            print("[AHouse] Spawn NPCs")

            ahouse.entities = entList
        else
            print("[AHouse] Missing NPC pos ( Setup issue ? )")
        end
    end
end

local function remove(ply)
    if IsValid(ply) and !ply:IsSuperAdmin() then return end

    for k, v in pairs(ahouse.entities) do
        for _, ent in ipairs(v) do
            if IsValid(ent) then
                ent:Remove()
            end
        end
    end

    ahouse.entities = {}
end

concommand.Add("ahouse_RemoveNPCs", remove)

concommand.Add("ahouse_SaveNPCs", function(ply)
    if IsValid(ply) and !ply:IsSuperAdmin() then return end

    local save = {}

    for k, v in ipairs(ents.GetAll()) do
        if ent[v:GetClass()] then
            table.insert(save, {class = v:GetClass(), pos = v:GetPos(), ang = v:GetAngles()})
        end
    end

    if !file.Exists("ahouse/", "DATA") then
        file.CreateDir("ahouse")
    end

    file.Write("ahouse/npcdata.json", util.TableToJSON(save))
    ReloadNPC()
end)

hook.Add("InitPostEntity", "AHouse_SecureNPCSpawn", function()
    ReloadNPC()
end)