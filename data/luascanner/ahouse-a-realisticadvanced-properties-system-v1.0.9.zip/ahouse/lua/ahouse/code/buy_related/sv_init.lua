function ahouse.create_contract(houseid, creator, target, rent, rent_days, commissionPrice)
    local firstDoor = ahouse.HouseData.FirstSafeDoor(houseid)

    if !IsValid(target) then return end

    if !IsValid(firstDoor) then
        ahouse.Notify(creator, "cantBuy", 1)
        return
    end

    if firstDoor:getDoorOwner() then
        ahouse.Notify(creator, "alreadyowned", 1)
        return
    end

    local ent, dist
    local pos = creator:GetPos()

    for _, ent2 in ipairs((ahouse.entities or {}).ahouse_printer or {}) do
        if !IsValid(ent) then
            ent = ent2
            dist = ent2:GetPos():DistToSqr(pos)
        else
            local d = ent2:GetPos():DistToSqr(pos)

            if d < dist then
                ent = ent2
                dist = d
            end
        end
    end

    if !dist or dist > ahouse.Config.MaxDistToPrinter*ahouse.Config.MaxDistToPrinter then
        ahouse.Notify(creator, "printer_away", 1)
        return
    end

    // Everything is fine now
    ent:PrintContract(creator, target, houseid, rent, rent_days, commissionPrice)
end