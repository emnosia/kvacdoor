local MODULE = GAS.Logging:MODULE()

MODULE.Category = "AHouse"
MODULE.Name = "Alarm"
MODULE.Colour = ahouse.Config.Colors.BlackGreen

MODULE:Setup(function()
	MODULE:Hook("ahouse_alarm", "Blogs", function(ply, _, id)
        MODULE:Log(ahouse.FormatLanguage("blogs_alarm", ahouse.HouseData.List[id].name),
            GAS.Logging:FormatPlayer(ply))
	end)
end)

GAS.Logging:AddModule(MODULE) // This function adds the module object to the registry.