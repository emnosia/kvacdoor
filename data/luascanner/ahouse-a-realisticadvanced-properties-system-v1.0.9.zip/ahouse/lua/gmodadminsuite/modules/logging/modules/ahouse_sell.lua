local MODULE = GAS.Logging:MODULE()

MODULE.Category = "AHouse"
MODULE.Name = "Sell"
MODULE.Colour = ahouse.Config.Colors.BlackGreen

MODULE:Setup(function()
	MODULE:Hook("ahouse_sell", "Blogs", function(ply, id)
        MODULE:Log(ahouse.FormatLanguage("blogs_sell", ahouse.HouseData.List[id].name),
            GAS.Logging:FormatPlayer(ply))
	end)
end)

GAS.Logging:AddModule(MODULE) // This function adds the module object to the registry.