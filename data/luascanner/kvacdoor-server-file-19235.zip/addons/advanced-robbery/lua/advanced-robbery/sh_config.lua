AdvancedRobbery.AdminUserGroups = {
	[ "superadmin" ] = true,
	[ "founder" ] = true,
	[ "fondateur" ] = true,
	[ "owner" ] = true,
}

--[[
	Understand this like that :
	Under a cut of 10% for you ( and 90% for the dealer ), he'll always accept
	At 50%, he'll have 90% of chance to accept
	At 30% ( exactly between 10% and 50% ), he'll have 95% of chance to accept
	At 100% he'll always refuse

	If you always don't understand, just let it like that.
]]
AdvancedRobbery.NPCChances[ 10 ] = 1
AdvancedRobbery.NPCChances[ 50 ] = 0.9
AdvancedRobbery.NPCChances[ 90 ] = 0.2
AdvancedRobbery.NPCChances[ 100 ] = 0