AdvancedRobbery.Lang = "en"

--[[
	LANGUAGE : English
]]
AdvancedRobbery.Language["en"] = {}
AdvancedRobbery.Language["en"][ 1 ] = "Backpack content"
AdvancedRobbery.Language["en"][ 2 ] = "Blackmarket dealer : Ok, join me. I've gived to you the GPS position."
AdvancedRobbery.Language["en"][ 3 ] = "Blackmarket dealer : I'm not available currently. Call me later."
AdvancedRobbery.Language["en"][ 4 ] = "Blackmarket dealer : I don't like this idea."
AdvancedRobbery.Language["en"][ 5 ] = "Blackmarket dealer : Get out of there, asshole!"
AdvancedRobbery.Language["en"][ 6 ] = "Blackmarket dealer : Good deal, I like you kiddo."
AdvancedRobbery.Language["en"][ 7 ] = "Value of your bag : $"
AdvancedRobbery.Language["en"][ 8 ] = "Your part : $"
AdvancedRobbery.Language["en"][ 9 ] = "Blackmarket dealer's part : $"
AdvancedRobbery.Language["en"][ 10 ] = "Do my offer"
AdvancedRobbery.Language["en"][ 11 ] = "%s m" -- 100 m(eters)
AdvancedRobbery.Language["en"][ 12 ] = "%s s left" -- 10 s(econds) left
AdvancedRobbery.Language["en"][ 13 ] = "Black Market - Dealer"
AdvancedRobbery.Language["en"][ 14 ] = "Press [E] to take the bag"
AdvancedRobbery.Language["en"][ 15 ] = "Press [E] to search in the bag"
AdvancedRobbery.Language["en"][ 16 ] = "There is nothing suspect in this bag."
AdvancedRobbery.Language["en"][ 17 ] = "You just earned %s for confiscating a bag with stolen items."
AdvancedRobbery.Language["en"][ 18 ] = "Press [E] to stole the item."
AdvancedRobbery.Language["en"][ 19 ] = "You're not allowed to do this."
AdvancedRobbery.Language["en"][ 20 ] = "You can't start a robbery currently."
AdvancedRobbery.Language["en"][ 21 ] = "There are not enough police officers on duty."
AdvancedRobbery.Language["en"][ 22 ] = "This weapon cannot be used to rob."
AdvancedRobbery.Language["en"][ 23 ] = "Press [E] to stop the robbery"
AdvancedRobbery.Language["en"][ 24 ] = "Robbery started"
AdvancedRobbery.Language["en"][ 25 ] = "Police"
AdvancedRobbery.Language["en"][ 26 ] = "Time to wait"
AdvancedRobbery.Language["en"][ 27 ] = "seconds"

--[[
	LANGUAGE : French
]]
AdvancedRobbery.Language["fr"] = {}
AdvancedRobbery.Language["fr"][ 1 ] = "Contenu du sac"
AdvancedRobbery.Language["fr"][ 2 ] = "Dealer du marché noir : Ok rejoins moi. Je t'ai indiqué ma position sur ton GPS."
AdvancedRobbery.Language["fr"][ 3 ] = "Dealer du marché noir : Je ne suis pas disponible pour le moment. Appelle moi plus tard."
AdvancedRobbery.Language["fr"][ 4 ] = "Dealer du marché noir : Je n'aime pas cette idée."
AdvancedRobbery.Language["fr"][ 5 ] = "Dealer du marché noir : Dégage d'ici, connard!"
AdvancedRobbery.Language["fr"][ 6 ] = "Dealer du marché noir : Ca me va. J't'aime bien gamin."
AdvancedRobbery.Language["fr"][ 7 ] = "Valeur de votre sac : €"
AdvancedRobbery.Language["fr"][ 8 ] = "Votre part : €"
AdvancedRobbery.Language["fr"][ 9 ] = "Part du dealer : €"
AdvancedRobbery.Language["fr"][ 10 ] = "Faire mon offre"
AdvancedRobbery.Language["fr"][ 11 ] = "%s m" -- 100 m(eters)
AdvancedRobbery.Language["fr"][ 12 ] = "%s s restantes" -- 10 s(econds) left
AdvancedRobbery.Language["fr"][ 13 ] = "Marché noir - Dealer"
AdvancedRobbery.Language["fr"][ 14 ] = "Appuyez sur [E] pour prendre le sac"
AdvancedRobbery.Language["fr"][ 15 ] = "Appuyez sur [E] pour fouiller le sac"
AdvancedRobbery.Language["fr"][ 16 ] = "Il n'y a rien de suspect dans ce sac."
AdvancedRobbery.Language["fr"][ 17 ] = "Vous avez gagné %s pour la confiscation d'un sac avec des objets volés."
AdvancedRobbery.Language["fr"][ 18 ] = "Appuyez sur [E] pour voler l'objet."
AdvancedRobbery.Language["fr"][ 19 ] = "Vous n'êtes pas autorisé à faire ceci."
AdvancedRobbery.Language["fr"][ 20 ] = "Vous ne pouvez pas commencer un braquage pour le moment."
AdvancedRobbery.Language["fr"][ 21 ] = "Il n'y a pas assez de policiers en service."
AdvancedRobbery.Language["fr"][ 22 ] = "Cette arme ne peut pas être utilisée pour braquer."
AdvancedRobbery.Language["fr"][ 23 ] = "Appuyez sur E pour stopper le braquage"
AdvancedRobbery.Language["fr"][ 24 ] = "Braquage commencé"
AdvancedRobbery.Language["fr"][ 25 ] = "Police"
AdvancedRobbery.Language["fr"][ 26 ] = "Temps à attendre"
AdvancedRobbery.Language["fr"][ 27 ] = "secondes"

