
AdvancedRobbery.Config.EntitiesSpawns = AdvancedRobbery.Config.EntitiesSpawns or {}

AdvancedRobbery.Config.NPC_Model = 'models/Eli.mdl'
AdvancedRobbery.Config.isCPPolice = true
AdvancedRobbery.Config.OtherPoliceTeams = {}
AdvancedRobbery.Config.IsRobberyLimitedToRobbers = true
AdvancedRobbery.Config.RobberTeams = {
	'Gangster'
}
AdvancedRobbery.Config.PercentageEarnedByPolice = 10

AdvancedRobbery.Config.TimeNPCWait = 120 -- when the black market NPC appears, how much time (in seconds) he should wait.
AdvancedRobbery.Config.TimeBetween2CallNPC = 360 -- after a call, how much time the player should wait to call the black market NPC another time.

-- TODO
--AdvancedRobbery.Config.BagSlowdownType = 1 -- how to slow down a player with a bag.

AdvancedRobbery.Config.DrawHUD = {
	["robber_icon_npc"] = true,
}

AdvancedRobbery.Config.TimeToResetEverything = 360
AdvancedRobbery.Config.TimeBetween2Robbery = 1800
AdvancedRobbery.Config.TimeBrokenAlarmAdvert = 60
AdvancedRobbery.Config.NumberPoliceMin = 5

AdvancedRobbery.Config.TimeWanted = 360

AdvancedRobbery.ScriptFunc = AdvancedRobbery.ScriptFunc or {}
AdvancedRobbery.ScriptFunc[ "config" ] = {
	SetConfig = function( tConfig )
		AdvancedRobbery.Config = table.Copy( tConfig )
	end,
	GetConfig = function( tConfig )
		return AdvancedRobbery.Config
	end
}


if SERVER then
	util.AddNetworkString( "AdvancedRobbery.SendConfig" )

	function AdvancedRobbery:SaveConfiguration( iScriptID, tConfig )
		local config = tConfig or AdvancedRobbery.Config or {}
		local sConfig = util.TableToJSON( config )

		file.CreateDir( "advancedrobbery" )
		file.Write( "advancedrobbery/" .. ( iScriptID or "config" ) .. ".txt", sConfig )
		
		AdvancedRobbery:BroadcastConfig()
	end

	function AdvancedRobbery:UpdateConfig( iScriptID )
		if file.Exists( "advancedrobbery/" .. ( iScriptID or "config" ) .. ".txt", "DATA" ) then
			local sConfig = file.Read( "advancedrobbery/" .. ( iScriptID or "config" ) .. ".txt" )
			local config = util.JSONToTable( sConfig )
			
			AdvancedRobbery.ScriptFunc[ iScriptID and iScriptID ~= "config" and tonumber( iScriptID ) or "config" ].SetConfig( table.Copy( config ) or {} )
		else
			AdvancedRobbery:SaveConfiguration( iScriptID )
		end

		AdvancedRobbery:BroadcastConfig( iScriptID )
	end

	function AdvancedRobbery:BroadcastConfig( iScriptID )
		local config = AdvancedRobbery.ScriptFunc[ iScriptID and iScriptID ~= "config" and tonumber( iScriptID ) or "config"].GetConfig() or AdvancedRobbery.Config		
		local json_data = util.TableToJSON( config )
		local compressed_data = util.Compress( json_data )
		local bytes_number = string.len( compressed_data )
		
		net.Start( "AdvancedRobbery.SendConfig" )
			net.WriteInt( bytes_number, 32 )
			net.WriteData( compressed_data, bytes_number )
			net.WriteInt( iScriptID ~= "config" and iScriptID and tonumber( iScriptID ) or -1, 6 )
		net.Broadcast()
	end

	function AdvancedRobbery:SendConfig( pPlayer, iScriptID )
		local config = AdvancedRobbery.ScriptFunc[ iScriptID and iScriptID ~= "config" and tonumber( iScriptID ) or "config"].GetConfig() or AdvancedRobbery.Config		
		local json_data = util.TableToJSON( config )
		local compressed_data = util.Compress( json_data )
		local bytes_number = string.len( compressed_data )
		
		net.Start( "AdvancedRobbery.SendConfig" )
			net.WriteInt( bytes_number, 32 )
			net.WriteData( compressed_data, bytes_number )
			net.WriteInt( iScriptID ~= "config" and iScriptID and tonumber( iScriptID ) or -1, 6 )
		net.Send( pPlayer )
	end

	function AdvancedRobbery:PlaceEntities( specificType )
		if AdvancedRobbery.Config.EntitiesSpawns and AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ]  then
			AdvancedRobbery.EntitiesSpawned = {}
			AdvancedRobbery.EntitiesSpawnedType = {}
			
			for sClass, tList in pairs( AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] ) do
				for k, tInfos in pairs( tList ) do
					if specificType and specificType ~= tInfos.type then continue end

					local eEntity = ents.Create( sClass )
					if not IsValid( eEntity ) then continue end
					eEntity:SetPos( tInfos.pos )
					eEntity:SetAngles( tInfos.ang )
					eEntity.RobType = tInfos.type
					eEntity:Spawn()
					
					local phys = eEntity:GetPhysicsObject()
					if phys:IsValid() then
						phys:EnableMotion( false )
					end
					
					if eEntity.RobType then
						AdvancedRobbery.EntitiesSpawnedType[ eEntity.RobType ] = AdvancedRobbery.EntitiesSpawnedType[ eEntity.RobType ] or {}
						table.insert( AdvancedRobbery.EntitiesSpawnedType[ eEntity.RobType ], eEntity )
					end
					AdvancedRobbery.EntitiesSpawned[ sClass ] = AdvancedRobbery.EntitiesSpawned[ sClass ] or {}
					table.insert( AdvancedRobbery.EntitiesSpawned[ sClass ], eEntity )
				end
			end
		end
	end

	function AdvancedRobbery:RemoveSpecificEntities( specificType )
		AdvancedRobbery.EntitiesSpawnedType = AdvancedRobbery.EntitiesSpawnedType or {}
		for k, v in pairs( AdvancedRobbery.EntitiesSpawnedType[ specificType ] or {} ) do
			if IsValid( v ) then
				v:Remove()
			end
		end
	end

	hook.Add( "Initialize", "Initialize.AdvancedRobbery", function()
		local files, directories = file.Find( "advancedrobbery/*", "DATA" )
		for k, v in pairs( files ) do 
			v = string.Replace( v, ".txt", "" )
			AdvancedRobbery:UpdateConfig( v )
		end
	end )

	hook.Add( "PlayerInitialSpawn", "PlayerInitialSpawn.AdvancedRobbery", function( pPlayer )
		timer.Simple( 1, function()
			local files, directories = file.Find( "advancedrobbery/*", "DATA" )
			for k, v in pairs( files ) do 
				v = string.Replace( v, ".txt", "" )
				AdvancedRobbery:SendConfig( pPlayer, v )
			end
		end )
	end )

	hook.Add( "InitPostEntity", "InitPostEntity.AdvancedRobbery", function()
		AdvancedRobbery:PlaceEntities()
	end )

	hook.Add( "PostCleanupMap", "PostCleanupMap.AdvancedRobbery", function()
		AdvancedRobbery:PlaceEntities()
	end )

elseif CLIENT then

	net.Receive( "AdvancedRobbery.SendConfig", function()
		local bytes_number = net.ReadInt( 32 )
		local compressed_data = net.ReadData( bytes_number )
		local json_data = util.Decompress( compressed_data )
		local real_data = util.JSONToTable( json_data )

		local iScriptID = net.ReadInt( 6 )

		if iScriptID and iScriptID ~= -1 then
			AdvancedRobbery.ScriptFunc[ iScriptID ].SetConfig( real_data )
			return
		end

		AdvancedRobbery.Config = real_data
	end )

end

-- These functions will be the same for AJR and ASR, so they are global
function AdvancedRobbery_IsPolice( ply )
	return ( ply:isCP() and AdvancedRobbery.Config.isCPPolice ) or table.HasValue( AdvancedRobbery.Config.OtherPoliceTeams, team.GetName( ply:Team() ) )
end

function AdvancedRobbery_IsRobber( ply )
	return not AdvancedRobbery_IsPolice( ply ) and ( not AdvancedRobbery.Config.IsRobberyLimitedToRobbers or table.HasValue( AdvancedRobbery.Config.RobberTeams, team.GetName( ply:Team() ) ) )
end

function AdvancedRobbery_GetBagMaxWeight( ply )
	local wBag = ply:GetWeapon( 'advancedrobbery_robbery_bag' )
	if not IsValid( wBag ) then return -1 end
	return wBag:GetBagWeight() or -1 
end

function AdvancedRobbery_CountPolice()
	local count = 0
	for k, ply in pairs( player.GetAll() ) do
		if AdvancedRobbery_IsPolice( ply ) then
			count = count + 1
		end
	end
	
	return count
end

function AdvancedRobbery_GetBagWeight( ply )
	ply.ListJewelry = ply.ListJewelry or {}
	ply.ListJewelry[ 'jewelry' ] = ply.ListJewelry[ 'jewelry' ] or {}
	ply.ListJewelry[ 'showcase' ] = ply.ListJewelry[ 'showcase' ] or {}

	local iWeight = 0

	for sEntClass, tList in pairs( ply.ListJewelry[ 'showcase' ] ) do
		for sModel, tInfos in pairs( tList ) do
			iWeight = iWeight + tInfos.weight * tInfos.number
		end
	end

	for k, list in pairs( ply.ListJewelry[ 'jewelry' ] ) do
		iWeight = iWeight + Jewelry_Robbery.Config.ListJewelry[k].weight * list.number		
	end

	return iWeight
end

function AdvancedRobbery_GetBagValue( ply )

	ply.ListJewelry = ply.ListJewelry or {}
	ply.ListJewelry[ 'jewelry' ] = ply.ListJewelry[ 'jewelry' ] or {}
	ply.ListJewelry[ 'showcase' ] = ply.ListJewelry[ 'showcase' ] or {}

	local iValue = 0

	for k, list in pairs( ply.ListJewelry[ 'jewelry' ] ) do
		iValue = iValue + Jewelry_Robbery.Config.ListJewelry[k].price_blackmarket * list.number		
	end

	for sEntClass, tList in pairs( ply.ListJewelry[ 'showcase' ] ) do
		for sModel, tInfos in pairs( tList ) do
			iValue = iValue + tInfos.price_blackmarket * tInfos.number
		end
	end

	return iValue
end

if CLIENT then

	local function PrecacheArc( cx, cy, radius, thickness, startang, endang, roughness )
		local triarc = {}
		roughness = math.max(roughness or 1, 1)
		local step = roughness

		startang, endang = startang or 0, endang or 0

		if startang > endang then
			step = math.abs(step) * -1
		end

		local inner = {}
		local r = radius - thickness
		for deg = startang, endang, step do
			local rad = math.rad(deg)
			local ox, oy = cx + ( math.cos( rad ) * r ), cy + ( -math.sin( rad ) * r )
			table.insert(inner, {
				x = ox,
				y = oy,
				u = ( ox - cx ) / radius + .5,
				v = ( oy - cy ) / radius + .5,
			})
		end

		local outer = {}
		for deg = startang, endang, step do
			local rad = math.rad( deg )
			local ox, oy = cx + ( math.cos( rad ) * radius ), cy + ( -math.sin( rad ) * radius )
			table.insert(outer, {
				x = ox,
				y = oy,
				u = ( ox - cx ) / radius + .5,
				v = ( oy - cy ) / radius + .5,
			})
		end

		for tri = 1, #inner * 2 do
			local p1, p2, p3
			p1 = outer[ math.floor( tri / 2 ) + 1 ]
			p3 = inner[ math.floor( ( tri + 1 ) / 2 ) + 1 ]
			if tri % 2 == 0 then
				p2 = outer[math.floor( ( tri + 1 ) / 2 ) ]
			else
				p2 = inner[math.floor( ( tri + 1 ) / 2 ) ]
			end

			table.insert( triarc, { p1, p2, p3 } )
		end

		return triarc
	end

	local function DrawArc( arc )
		for k,v in ipairs( arc ) do
			surface.DrawPoly( v )
		end
	end

	local function drawArc( cx, cy, radius, thickness, startang, endang, roughness, color )
		draw.NoTexture()
		surface.SetDrawColor( color )
		DrawArc( PrecacheArc( cx, cy, radius, thickness, startang, endang, roughness ) )
	end


	AdvancedRobbery.Interaction = {}
	local Interaction = {}
	Interaction.__index = Interaction

	function Interaction:New( entity, data )
		local interact = {}
		setmetatable( interact, Interaction )
		interact:Initialize( entity, data )
		return interact
	end

	function Interaction:Initialize( entity, data )

		-- Add all default values which will be used in the rest of the code
		self.Entity = entity
		self.EntityIndex = entity:EntIndex()
		self.AddHalo = data.AddHalo or false
		self.HaloColor = data.HaloColor or Color( 255, 255, 255, 255 )
		self.FontSize = data.FontSize or ScreenScale( 9 )
		self.Font = data.Font or 'AdvancedRobbery.Font20'
		self.IgnoreWorld = data.IgnoreWorld or false
		self.Position = data.Position
		self.ActionIsRunning = false
		self.ActionStartAt = CurTime()
		self.MaxInteractDistanceRacine = data.MaxInteractDistance or 150
		self.MaxInteractDistance = self.MaxInteractDistanceRacine * self.MaxInteractDistanceRacine
		if ( istable( data.Hint ) ) then
			self:SetHint( data.Hint.Text, data.Hint.Color )
		end
		self:InitializeHooks()
	end

	function Interaction:CanInteract()
		return IsValid( self.Entity ) and self.Action and self.Action.ActionCheck and self.Action.ActionCheck( self.Entity )
	end

	function Interaction:CheckDistance()
		-- Do not check if self.Entity is valid as it has already been done in CanInteract
		return self.Entity:GetPos():DistToSqr( LocalPlayer():GetPos() ) <= self.MaxInteractDistance
	end

	function Interaction:CheckLookAt()
		-- Do not check if self.Entity is valid as it has already been done in CanInteract
		local tFilter = { LocalPlayer() }
		if ( self.TraceFilters and istable( self.TraceFilters ) ) then table.Add( tFilter, self.TraceFilters ) end
		local pPlayerEyeTrace = util.TraceLine( {
			start = LocalPlayer():EyePos(),
			endpos = LocalPlayer():EyePos() + LocalPlayer():EyeAngles():Forward() * self.MaxInteractDistanceRacine,
			filter = tFilter,
			ignoreworld = self.IgnoreWorld or true
		} )

		return pPlayerEyeTrace.Hit and pPlayerEyeTrace.Entity == self.Entity
	end

	function Interaction:ShouldDraw()
		return self:CanInteract() and self:CheckDistance() and self:CheckLookAt()
	end

	function Interaction:InitializeHooks()
		-- List all hooks used in this table so I can remove them later.
		self.Hooks = {}
		if self.AddHalo then
			self.Hooks[ "PreDrawHaloHook" ] = true
			hook.Add( "PreDrawHaloHook", tostring( self ), function() self:PreDrawHaloHook() end )
		end

		self.Hooks[ "HUDPaint" ] = true
		hook.Add( "HUDPaint", tostring( self ), function() self:HUDPaint() end )
	end

	function Interaction:PreDrawHalosHook()
		if not self:ShouldDraw() then return end
		halo.Add( { self.Entity }, self.HaloColor, 5, 5, 1, true, self.IgnoreWorld )
	end

	function Interaction:HUDPaint()
		if ( not IsValid( self.Entity ) ) then self:Delete() end
		if ( not self:ShouldDraw() ) then return end

		if input.IsKeyDown( self.Action.Key ) then
			if not self.ActionIsRunning then
				self.ActionStartAt = CurTime()
			end
			if self.ActionStartAt + self.Action.Duration <= CurTime() then
				self:OnActionFinished( LocalPlayer() )
			end
			self.ActionIsRunning = true
		else
			self.ActionIsRunning = false
		end
		self:DrawHint()
		self:DrawAction()
	end

	function Interaction:DrawHint()
		if self.ActionIsRunning then return end

		local vOrigin = isfunction( self.Position ) and self.Position() or self.Entity:GetPos():ToScreen()
		vOrigin.y = vOrigin.y + ScreenScale( 20 )
		local fFont = self.Font
		local sHintText = string.upper( self.Hint.Text )
		local cHintColor = self.Hint.Color or Color( 255, 255, 255, 255 )
		draw.SimpleText( sHintText, fFont, vOrigin.x, vOrigin.y - ScreenScale( 15 ), cHintColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end

	function Interaction:DrawAction()
		if ( not self.ActionIsRunning ) then return end

		local vOrigin = isfunction( self.Position ) and self.Position() or self.Entity:GetPos():ToScreen()
		local value = -270 + ( 360 / self.Action.Duration * ( self.ActionStartAt + self.Action.Duration - CurTime() ) )
		drawArc( vOrigin.x, vOrigin.y, ScreenScale( 15 ), 8, 0, 360, 1, Color( 0, 0, 0, 100 ) )
		drawArc( vOrigin.x, vOrigin.y, ScreenScale( 15 ), 8, -270, value, 1, Color( 255, 255, 255, 200 ) )
	end

	function Interaction:OnActionFinished( ply )
		self.ActionIsRunning = false
		self.ActionIsFinish = false
		local sData = util.TableToJSON( {
			EntityIndex = self.EntityIndex,
			ActionType = self.Action.ActionType
		} )
		local sCompressedData = util.Compress( sData, string.len( sData ) )
		net.Start( 'advancedrobbery.on.action.finish.handle.by.interaction' )
			net.WriteData( sCompressedData, string.len( sCompressedData ) )
		net.SendToServer()
		if self.Entity.PostAction and isfunction( self.Entity.PostAction ) then
			self.Entity:PostAction(  self.Action.ActionType, LocalPlayer() )
		end
	end

	function Interaction:OnValueChanged( var, old, new ) end -- For override

	function Interaction:AddFilters( filters )
		if ( not istable( filters ) ) then return end
		self.TraceFilters = filters
	end

	function Interaction:SetIgnoreWorld( ignore )
		self.IgnoreWorld = ignore
	end

	function Interaction:SetHint( text, color )
		self.Hint = self.Hint or {}
		if isstring( text ) then self.Hint.Text = text end
		if IsColor( color ) then self.Hint.Color = color end
		return self
	end

	function Interaction:SetAction( key, duration, actionType, actionCheck )
		self.Action = {}
		self.Action.Key = key
		self.Action.Duration = duration
		self.Action.ActionType = actionType
		self.Action.ActionCheck = actionCheck
	end

	function Interaction:Delete()
		for hookName, bBool in pairs( self.Hooks or {} ) do
			hook.Remove( hookName, tostring( self ) )
		end
		-- self = nil
	end

	Interaction.Remove = Interaction.Delete

	setmetatable( AdvancedRobbery.Interaction, { __call = Interaction.New } )
end

if SERVER then
	util.AddNetworkString( 'advancedrobbery.on.action.finish.handle.by.interaction' )

	net.Receive( 'advancedrobbery.on.action.finish.handle.by.interaction', function( len, ply )
		local data = util.JSONToTable( util.Decompress( net.ReadData( len / 8 ) ) )
		local eEntity = Entity( data.EntityIndex )
		if ( not IsValid( eEntity ) or not IsValid( ply ) or not eEntity.PostAction ) then return end
		eEntity:PostAction( data.ActionType, ply )
	end)
end

AdvancedRobbery.Networking = {}

if ( SERVER ) then util.AddNetworkString( 'AdvancedRobberyNetworking' ) end

local function serialize( tbl )
	local args = {}

	for k, v in pairs( tbl ) do
		local typeID, key, value = TypeID( v ), k, v
		if ( typeID == TYPE_ENTITY ) then
			value = v:EntIndex()
		elseif ( IsColor( v ) ) then
			typeID = TYPE_COLOR
			value = tostring( v )
		elseif ( typeID == TYPE_MATRIX ) then
			value = v:ToTable()
		elseif ( typeID == TYPE_TABLE ) then
			value = serialize( v )
		end

		table.insert( args, { typeID = typeID, key = key, value = value } )
	end

	return args
end


local function start( name, ... )
	local args = { ... }
	local map = {}

	table.insert( args, 1, name )
	map = serialize( args )

	local serializedData = util.TableToJSON( map )
	local binaryData = util.Compress( serializedData, string.len( serializedData ) )

	net.Start( 'AdvancedRobberyNetworking' )
	net.WriteData( binaryData, string.len( binaryData ) )
end

if ( SERVER ) then
	function AdvancedRobbery.Networking:Send( name, target, ... )
		start( name, unpack( { ... } ) )
		net.Send( target )
	end

	function AdvancedRobbery.Networking:Broadcast( name, ... )
		start( name, unpack( { ... } ) )
		net.Broadcast()
	end

	function AdvancedRobbery.Networking:SendPAS( name, vPosition, ... )
		start( name, unpack( { ... } ) )
		net.SendPAS( vPosition )
	end

	function AdvancedRobbery.Networking:SendPVS( name, vPosition, ... )
		start( name, unpack( { ... } ) )
		net.SendPVS( vPosition )
	end
end

if ( CLIENT ) then
	function AdvancedRobbery.Networking:SendToServer( name, ... )
		local args = { ... }
		table.insert( args, 1, LocalPlayer() )
		start( name, unpack( args ) )
		net.SendToServer()
	end
end

local function deserialize( tbl )
	local args = {}

	for k, v in ipairs( tbl ) do
		local typeID, key, value = v.typeID, v.key, v.value
		if ( typeID == TYPE_COLOR ) then
			value = string.ToColor( value )
		elseif ( typeID == TYPE_MATRIX ) then
			value = Matrix( value )
		elseif ( typeID == TYPE_ENTITY ) then
			value = Entity( value )
		elseif ( typeID == TYPE_TABLE ) then
			value = deserialize( value )
		end

		args[ key ] = value
	end

	return args
end

local RECEIVE = {}

function AdvancedRobbery.Networking:Receive( name, callback )
	RECEIVE[ name ] = callback
end

net.Receive( 'AdvancedRobberyNetworking', function( len )
	local map = util.JSONToTable( util.Decompress( net.ReadData( len / 8 ) ) )

	local args = {}
	args = deserialize( map )

	local name = args[ 1 ]

	if ( not RECEIVE[ name ] ) then return end

	table.remove( args, 1 )

	RECEIVE[ name ]( unpack( args )  )
end )

function AdvancedRobbery.Notify( type, message, ply )
	if SERVER then
		DarkRP.notify( ply, type, 10, message )
	elseif CLIENT then
		notification.AddLegacy( message, type, 10 )
	end
end

if CLIENT then

surface.CreateFont( "AdvancedRobbery.Font30", {
	font = "Rajdhani",
	extended = true,
	size = 30,
	weight = 400,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

surface.CreateFont( "AdvancedRobbery.Font30b", {
	font = "Rajdhani",
	extended = true,
	size = 30,
	weight = 750,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

surface.CreateFont( "AdvancedRobbery.Font20", {
	font = "Rajdhani",
	extended = true,
	size = 20,
	weight = 400,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

surface.CreateFont( "AdvancedRobbery.Font17", {
	font = "Rajdhani",
	extended = true,
	size = 17,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

surface.CreateFont( "AdvancedRobbery.Font17b", {
	font = "Rajdhani",
	extended = true,
	size = 17,
	weight = 750,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

surface.CreateFont( "AdvancedRobbery.Font40", {
	font = "Rajdhani",
	extended = true,
	size = 40,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

surface.CreateFont( "AdvancedRobbery.Font22", {
	font = "Rajdhani",
	extended = true,
	size = 22,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

surface.CreateFont( "AdvancedRobbery.Font22b", {
	font = "Rajdhani",
	extended = true,
	size = 22,
	weight = 750,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

surface.CreateFont( "AdvancedRobbery.Font25", {
	font = "Rajdhani",
	extended = true,
	size = 25,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

end