AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

include('shared.lua')

function ENT:Initialize()
	
	self:SetModel( AdvancedRobbery.Config.NPC_Model )
	self:StartActivity(ACT_IDLE)
	
	self.nextClick = 0
end

function ENT:AcceptInput( event, a, pCaller )

	if( event == 'Use' && pCaller:IsPlayer() && self.nextClick < CurTime() )  then
	
		self.nextClick = CurTime() + 2
		AdvancedRobbery.Networking:Send( 'AdvancedRobbery:OpenBlackMarketMenu', pCaller, self )
		
	end
	
end

function ENT:OnInjured( dmg )
	local damage = dmg:GetDamage( 0 )
	dmg:SetDamage( 0 )
	self:SetHealth( damage + 1 )
end


function ENT:RunBehaviour()
	while (true) do
		
		local anim = self.ShouldAnim or false
		
		if anim then
		
			self:PlaySequenceAndWait('Heal', 1)
			self.ShouldAnim = false
			
			timer.Simple(0.5, function()
				if IsValid( self ) then
					self:StartActivity(ACT_IDLE)
				end
			end)
			
		end
		
		coroutine.yield()
	end
end

AdvancedRobbery.NPCInfos = {
	free = true,
	pos = Vector( 0, 0, 0 ),
	lastCall = -AdvancedRobbery.Config.TimeBetween2CallNPC,
	caller = NULL,
}

local chancesTable = AdvancedRobbery.NPCChances

function AdvancedRobbery.Config.DefaultPercentageCheckFunction(ply, iBagValue, percentage)
	for k,v in SortedPairs(chancesTable) do
		if percentage <= k then
			local rand = math.Rand(0, 1)
			return rand <= v
		end
	end
	return false
end

local percentageCheckFunction = AdvancedRobbery.Config.PercentageCheckFunction or AdvancedRobbery.Config.DefaultPercentageCheckFunction

AdvancedRobbery.Networking:Receive( 'AdvancedRobbery:SellToBlackmarket', function( pCaller, eDealer, iPercentage )
	if not IsValid( pCaller ) or not IsValid( eDealer ) or eDealer:GetPos():DistToSqr( pCaller:GetPos() ) > 16000 or not AdvancedRobbery_IsRobber( pCaller ) or not eDealer:GetClass() == 'advancedrobbery_robbery_blackmarket_npc' or not pCaller:HasWeapon( 'advancedrobbery_robbery_bag') or not isnumber( iPercentage ) or iPercentage < 0 or iPercentage > 100 then
		return
	end

	local iBagValue = AdvancedRobbery_GetBagValue( pCaller )

	if percentageCheckFunction( pCaller, iBagValue, iPercentage) then
		AdvancedRobbery.Notify( 0, AdvancedRobbery.Language[AdvancedRobbery.Lang][ 6 ], pCaller )

		pCaller:StripWeapon( 'advancedrobbery_robbery_bag' )
		pCaller.ListJewelry = {}
		AdvancedRobbery.Networking:Send( 'AdvancedRobbery:SendJewelryListToPlayer', pCaller, pCaller.ListJewelry )

		pCaller:addMoney( iBagValue * iPercentage / 100 )

		eDealer:EmitSound('advanced_robbery/money.wav') -- TODO : put this in ASR
	else
		eDealer.NumRefuse = (eDealer.NumRefuse or 0) + 1 
			
		if eDealer.NumRefuse >= 3 then
			AdvancedRobbery.Notify( 1, AdvancedRobbery.Language[AdvancedRobbery.Lang][ 5 ], pCaller )
			eDealer:Remove()

			AdvancedRobbery.NPCInfos.free = true

			AdvancedRobbery.Networking:Send( 'AdvancedRobbery:NetworkNPCPosition', pCaller, AdvancedRobbery.NPCInfos )
		else
			AdvancedRobbery.Notify( 1, AdvancedRobbery.Language[AdvancedRobbery.Lang][ 4 ], pCaller )
		end
	end
end )

function AdvancedRobbery.CreateNPC( pCaller )
	
	if not AdvancedRobbery or not AdvancedRobbery.Config or not AdvancedRobbery.Config.NPCPositions or not istable( AdvancedRobbery.Config.NPCPositions ) or not AdvancedRobbery.Config.NPCPositions[ game.GetMap() ] then return end

	local infos = table.Random( AdvancedRobbery.Config.NPCPositions[ game.GetMap() ]) or {}
	
	local ent = ents.Create( infos.class or 'advancedrobbery_robbery_blackmarket_npc' )
	if not IsValid( ent ) then return end
	ent:SetPos( infos.pos )
	ent:SetAngles( infos.ang )
	ent:Spawn()
	
	AdvancedRobbery.NPCInfos = {
		free = false,
		pos = infos.pos,
		lastCall = CurTime(),
		caller = pCaller,
	}
	
	AdvancedRobbery.Networking:Send( 'AdvancedRobbery:NetworkNPCPosition', pCaller, AdvancedRobbery.NPCInfos )
	
	timer.Simple( AdvancedRobbery.Config.TimeNPCWait, function()
		
		if IsValid( ent ) then ent:Remove() end
		
		AdvancedRobbery.NPCInfos.free = true
		
		AdvancedRobbery.Networking:Send( 'AdvancedRobbery:NetworkNPCPosition', pCaller, AdvancedRobbery.NPCInfos )
		
	end)
	
end
