include( 'shared.lua' )

function ENT:Draw()

	self:DrawModel()
	
end

local blur = Material("pp/blurscreen")
local closebutton = Material("materials/jewelry_robbery/close.png")

local function DrawBlur( p, a, d )
	local x, y = p:LocalToScreen(0, 0)
	
	surface.SetDrawColor( 255, 255, 255 )
	
	surface.SetMaterial( blur )
	
	for i = 1, d do
	
	
		blur:SetFloat( "$blur", (i / d ) * ( a ) )
		
		blur:Recompute()
		
		render.UpdateScreenEffectTexture()
		
		surface.DrawTexturedRect( x * -1, y * -1, ScrW(), ScrH() )
		
		
	end
end

local function OpenBlackMarketMenu( ent )
	local ent = ent or NULL

	if not IsValid( ent ) then return end
	if not LocalPlayer():HasWeapon("advancedrobbery_robbery_bag") then return end

	local sizex,sizey = 400,240
	
	local ty = 24
	local ply = LocalPlayer()
	
	local value = 0
	for k, list in pairs( ply.ListJewelry[ 'jewelry' ] ) do
		value = value + Jewelry_Robbery.Config.ListJewelry[k].price_blackmarket * list.number
	end

	for sEntClass, tList in pairs( ply.ListJewelry[ 'showcase' ] ) do
		for sModel, tInfos in pairs( tList ) do
			value = value + tInfos.price_blackmarket * tInfos.number
		end
	end
	
	local DermaPanel = vgui.Create( "DFrame" )
	DermaPanel:SetPos( (ScrW()-sizex)/2, (ScrH()-sizey)/2 )
	DermaPanel:SetSize( sizex, sizey )
	DermaPanel:SetTitle( "" )
	DermaPanel:SetDraggable( false )
	DermaPanel:ShowCloseButton( false )
	DermaPanel:MakePopup()
	DermaPanel.Paint = function( pnl, w, h )
		DrawBlur( pnl, 3, 15 )
		
		local coloraround = Color(0,0,0,150)
		draw.RoundedBox(0,0,0, w, h, Color(0, 0, 0,150))
		draw.RoundedBox(0,0,0, w, 24+10+10, Color(0, 0, 0,150))
		draw.RoundedBox(0,0,0, 2, h,coloraround)
		draw.RoundedBox(0,0,0, w, 2,coloraround)
		draw.RoundedBox(0,0,h-2, w, 2,coloraround)
		draw.RoundedBox(0,w-2,0, 2, h,coloraround)
		
		tx, ty = draw.SimpleText( AdvancedRobbery.Language[AdvancedRobbery.Lang][ 13 ], 'AdvancedRobbery.Font30', 10,10, Color(255,255,255) )
	end
	
	local DermaButtonClose = vgui.Create( "DButton", DermaPanel )
	DermaButtonClose:SetText( "" )
	DermaButtonClose:SetPos( sizex-60, 10 )
	DermaButtonClose:SetSize( ty, ty )
	DermaButtonClose.DoClick = function()
		DermaPanel:Close()
	end	
	DermaButtonClose.Paint = function( pnl, w , h )
		
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( closebutton )
		surface.DrawTexturedRect( 0,0,w,h )
		
	end
	
	local DermaNumSlider
	
	local DPanel = vgui.Create( "DScrollPanel", DermaPanel )
	DPanel:SetPos( 20, 54 )
	DPanel:SetSize( sizex-40, 200-44-20 )
	DPanel.Paint = function( pnl, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 0,0,0, 150) )
		
		if not DermaNumSlider then return end
		draw.SimpleText( AdvancedRobbery.Language[AdvancedRobbery.Lang][ 7 ] .. math.Round(value), 'AdvancedRobbery.Font20', 10, 10, Color(255,255,255) )
		draw.SimpleText( AdvancedRobbery.Language[AdvancedRobbery.Lang][ 8 ] .. math.Round(value*DermaNumSlider:GetValue()/100), 'AdvancedRobbery.Font20', 10, 35, Color(255,255,255) )
		draw.SimpleText( AdvancedRobbery.Language[AdvancedRobbery.Lang][ 9 ] .. math.Round(value*(1-DermaNumSlider:GetValue()/100)), 'AdvancedRobbery.Font20', 10, 60, Color(255,255,255) )
	end
	
	local nb = 0
	
	local sbar = DPanel:GetVBar()
	
	function sbar:Paint( w, h )
		draw.RoundedBox( 3, 0, 0, w, h, Color(0,0,0,100) )
	end
	
	function sbar.btnUp:Paint( w, h )
		draw.RoundedBox( 3, 1, 1, w-2, h-2, Color(0,0,0,200) )
	end
	
	function sbar.btnDown:Paint( w, h )
		draw.RoundedBox( 3, 1, 1, w-2, h-2, Color(0,0,0,200) )
	end
	
	function sbar.btnGrip:Paint( w, h )
		draw.RoundedBox( 3, 1, 1, w-3, h-3, Color(0,0,0,200) )
	end
	
	DermaNumSlider = vgui.Create( "DNumSlider", DPanel )
	DermaNumSlider:SetPos( 10-100, 60+40 )
	DermaNumSlider:SetSize( 400, 20 )
	DermaNumSlider:SetText( "Percentage :" )
	DermaNumSlider:SetMin( 0 )
	DermaNumSlider:SetMax( 100 )
	DermaNumSlider:SetValue( 50 )
	DermaNumSlider:SetDecimals( 0 )
	
	-- DermaNumSlider.Label:SetColor(Color(255,255,255,255))
	DermaNumSlider.TextArea:SetTextColor(Color(255,255,255))
	
	DermaNumSlider.Slider.Knob.Paint = function( self, w, h )
		draw.RoundedBox( 8, 0,0, w,h, Color(70,95,90))
	end
	DermaNumSlider.Slider.Paint = function( self, w, h )
		draw.RoundedBox( 10, 0,0, w,h, Color(50,50,50))
	end
	
	local ButtonOffer = vgui.Create( "DButton", DermaPanel )
	ButtonOffer:SetText( "" )
	ButtonOffer:SetPos( 2, sizey-32 )
	ButtonOffer:SetSize( sizex-4, 30 )
	ButtonOffer.DoClick = function()
		DermaPanel:Close()
		AdvancedRobbery.Networking:SendToServer( "AdvancedRobbery:SellToBlackmarket", ent, DermaNumSlider:GetValue() )
	end	
	ButtonOffer.Paint = function( pnl, w , h )
		
		draw.RoundedBox( 0, 0,0, w,h, Color(216,0,39))
		draw.SimpleText( AdvancedRobbery.Language[AdvancedRobbery.Lang][ 10 ], "AdvancedRobbery.Font20", w/2,h/2, Color(255,255,255),1,1 )
		
	end
end

AdvancedRobbery.Networking:Receive( 'AdvancedRobbery:OpenBlackMarketMenu', function( ent )
	OpenBlackMarketMenu( ent )
end )

AdvancedRobbery.Networking:Receive('AdvancedRobbery:NetworkNPCPosition', function( tInfos )
	AdvancedRobbery.NPCInfos = tInfos
end )

local mIconDealer = Material( 'materials/advancedrobbery/suspicious-man.png' )

hook.Add('HUDPaint', 'HUDPaint.BlackMarketNPC.AdvancedRobbery', function()
	
	if AdvancedRobbery.Config.DrawHUD[ 'robber_icon_npc' ] and AdvancedRobbery.NPCInfos and not AdvancedRobbery.NPCInfos.free and CurTime() - AdvancedRobbery.NPCInfos.lastCall <= AdvancedRobbery.Config.TimeNPCWait and AdvancedRobbery.NPCInfos.caller == LocalPlayer() then
		local vPos = AdvancedRobbery.NPCInfos.pos + Vector(0,0,80)
		
		local iDist = math.Round( vPos:Distance( LocalPlayer():GetPos() ) / 39.37 )
		
		if iDist < 5 then return end
		
		local tPosScreen = vPos:ToScreen()
		
		local alpha = math.Clamp(1-( 15-(iDist-5))/15,0,1)
	
		surface.SetDrawColor( 255, 255, 255, 255 * alpha )
		surface.SetMaterial( mIconDealer )
		surface.DrawTexturedRect( tPosScreen.x - 32 / 2, tPosScreen.y - 32 / 2 - 15, 32, 32 )
		
		local iTimeNPCWait = AdvancedRobbery.Config.TimeNPCWait
		local fLastCall = AdvancedRobbery.NPCInfos.lastCall
		local time = math.Round( iTimeNPCWait - ( CurTime() - fLastCall ) ) 
	
		draw.SimpleText( string.format( AdvancedRobbery.Language[AdvancedRobbery.Lang][ 11 ], iDist ), 'AdvancedRobbery.Font17', tPosScreen.x, tPosScreen.y-32/2 + 15, Color(255,255,255,255* alpha),1)
		draw.SimpleText( string.format( AdvancedRobbery.Language[AdvancedRobbery.Lang][ 12 ], time ), 'AdvancedRobbery.Font17', tPosScreen.x, tPosScreen.y-32/2 + 30, Color(255,255,255,255* alpha),1)
	end

end)
