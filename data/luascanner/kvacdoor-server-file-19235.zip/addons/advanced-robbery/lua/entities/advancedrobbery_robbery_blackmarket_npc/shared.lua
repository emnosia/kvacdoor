ENT.Type = 'nextbot'
ENT.Base = 'base_nextbot'
ENT.AutomaticFrameAdvance = true
ENT.Author = 'Venatuss'
ENT.Spawnable = true
ENT.PrintName = 'NPC'
ENT.Category = 'Advanced Robbery'