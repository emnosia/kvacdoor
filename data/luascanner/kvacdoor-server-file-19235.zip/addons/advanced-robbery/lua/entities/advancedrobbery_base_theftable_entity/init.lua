AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')
include('shared.lua')

function ENT:Initialize()
	self:SetModel( self.Model or 'models/props_interiors/phone.mdl' )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetUseType( SIMPLE_USE )
	local physics = self:GetPhysicsObject()
	if physics:IsValid() then physics:EnableMotion( false ) end
end

function ENT:UpdateTransmitState()
	return TRANSMIT_ALWAYS
end

function ENT:PostAction( sAction, pCaller )
	if sAction == 'Grab' then
		if not AdvancedRobbery.ScriptFunc or not AdvancedRobbery.ScriptFunc[ self:GetScript() ] or not AdvancedRobbery.ScriptFunc[ self:GetScript() ].GrabFunction or not isfunction( AdvancedRobbery.ScriptFunc[ self:GetScript() ].GrabFunction ) then 
			return
		end
		
		AdvancedRobbery.ScriptFunc[ self:GetScript() ].GrabFunction( pCaller, self )
	end
end