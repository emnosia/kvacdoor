ENT.Type = 'anim'
ENT.Base = 'base_gmodentity'
ENT.PrintName = 'Entity: Theftable entity'
ENT.Category = 'Advanced Robbery'
ENT.Author = 'Venatuss and his squad'
ENT.Contact = 'ASR Team.'
ENT.Purpose = 'ASR Team.'
ENT.Instructions = 'ASR Team.'
ENT.Spawnable = false

function ENT:SetupDataTables()
	self:NetworkVar( 'Entity', 0, 'Showcase' )
	self:NetworkVar( 'String', 0, 'Glass' )
	self:NetworkVar( 'Float', 0, 'Script' ) -- 0 = jewelryrobbery, 1 = showcaserobbery
end