include( 'shared.lua' )

function ENT:Initialize()
	self.GrabInteraction = AdvancedRobbery.Interaction( self, { AddHalo = false, IgnoreWorld = true } )
	self.GrabInteraction:SetHint( AdvancedRobbery.Language[ AdvancedRobbery.Lang ][ 18 ] )
	self.GrabInteraction:SetAction( KEY_E, 5, 'Grab', function( ent )
		return ( AdvancedRobbery.ScriptFunc and AdvancedRobbery.ScriptFunc[ ent:GetScript() ] and AdvancedRobbery.ScriptFunc[ ent:GetScript() ].GrabCheck and isfunction( AdvancedRobbery.ScriptFunc[ ent:GetScript() ].GrabCheck ) and AdvancedRobbery.ScriptFunc[ ent:GetScript() ].GrabCheck( ent ) ) or false
	end)

	-- for stencils
	if self:GetScript() == 1 then ASR.TheftableEntitiesList = ASR.TheftableEntitiesList or {} table.insert( ASR.TheftableEntitiesList, self ) end
end

function ENT:AddShowcaseToFilters()
	if ( not isfunction( self.GetShowcase ) or not IsValid( self:GetShowcase() ) or self.IsAddToFilters or not self.GrabInteraction ) then return end
	self.IsAddToFilters = true
	self.GrabInteraction:AddFilters( { self:GetShowcase() } )
end

function ENT:Think()
	self:AddShowcaseToFilters()
end

function ENT:Draw()
	self:DrawModel()
end
