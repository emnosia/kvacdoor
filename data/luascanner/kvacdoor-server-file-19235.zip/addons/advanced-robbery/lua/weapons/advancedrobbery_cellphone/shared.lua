SWEP.ViewModelFlip 			= false
SWEP.Author					= 'Venatuss'
SWEP.Instructions			= 'Click to use'

SWEP.ViewModel				= Model( 'models/sterling/ajr_phone_c.mdl' )
SWEP.WorldModel 			= Model( 'models/sterling/ajr_phone_w.mdl' )

SWEP.UseHands				= true

SWEP.Spawnable				= true
SWEP.AdminSpawnable			= false

SWEP.Primary.Damage         = 0
SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= 'none'
SWEP.Primary.Delay 			= 4

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= 'none'

SWEP.Category 				= 'Advanced Robbery'
SWEP.PrintName				= 'Cellphone'
SWEP.Slot					= 1
SWEP.SlotPos				= 1
SWEP.DrawAmmo				= false
SWEP.DrawCrosshair			= true

function SWEP:SecondaryAttack()
end

function SWEP:ShouldDropOnDie()
	return false
end

function SWEP:Reload()
end

function SWEP:CallResponse()
	if CLIENT then return end

	AdvancedRobbery.NPCInfos = AdvancedRobbery.NPCInfos or {
		free = true,
		pos = Vector( 0, 0, 0 ),
		lastCall = -AdvancedRobbery.Config.TimeBetween2CallNPC,
		caller = NULL,
	}
	
	if AdvancedRobbery.NPCInfos.free and CurTime() - AdvancedRobbery.NPCInfos.lastCall > AdvancedRobbery.Config.TimeBetween2CallNPC then
		AdvancedRobbery.CreateNPC( self.Owner )
		AdvancedRobbery.Notify( 0, AdvancedRobbery.Language[AdvancedRobbery.Lang][ 2 ], self.Owner )
	else
		AdvancedRobbery.Notify( 1, AdvancedRobbery.Language[AdvancedRobbery.Lang][ 3 ], self.Owner )
	end
end

function SWEP:PrimaryAttack()
	self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )

	self:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
	
	if CLIENT then return end
	
	self:SetCallTime( CurTime() + 2 )
	
end

function SWEP:SetupDataTables()
	self:NetworkVar( 'Float', 0, 'CallTime' )
end

function SWEP:Think()
	if self:GetCallTime() > 0 and self:GetCallTime() < CurTime() then
		self:SendWeaponAnim( ACT_VM_SECONDARYATTACK )
		if SERVER then
			self:SetCallTime( 0 )
			self:CallResponse()
		end
	end
end

function SWEP:Initialize()
	self:SetHoldType( 'melee' )
	if SERVER then
		self:SetCallTime( 0 )
	end
end

function SWEP:Deploy()
	self:SendWeaponAnim( ACT_VM_DRAW )
	self:SetNextPrimaryFire( CurTime() + 1 )
	if SERVER then
		self:SetCallTime(0)
	end
    return true
end

function SWEP:OnRemove()
end

function SWEP:Holster()
    return true
end