-- a part of this is inspired from the code of Rubat, https://steamcommunity.com/sharedfiles/filedetails/?id=195065185
-- Thanks to him.

TOOL.Category = "Advanced Robbery"
TOOL.Name = "Advanced Robbery Tool"

if CLIENT then
	TOOL.Information = {
		{ name = "left" },
		{ name = "right" },
		{ name = "reload" },
		{ name = "reload_use", icon2 = "gui/e.png" },
		{ name = "use" }
	}
	language.Add( "tool.advrobbery.name", "Advanced Robbery" )
	language.Add( "tool.advrobbery.desc", "Configuration tool" )

	language.Add( "tool.advrobbery.left", "Left click to place entity" )
	language.Add( "tool.advrobbery.right", "Right click to remove entity" )
	language.Add( "tool.advrobbery.use", "Rotate" )
	language.Add( "tool.advrobbery.reload", "Next tool" )
	language.Add( "tool.advrobbery.reload_use", "Previous tool" )
end

AdvancedRobbery.ListOfTools = AdvancedRobbery.ListOfTools or {}

local ListOfTools = { 
	{
		name = "NPC positions",
		model = AdvancedRobbery.Config.NPC_Model,
		ang = Angle( 90, 0, 0 ),
		onSelectTool = function( tool, tTool )
			AdvancedRobbery.Config.NPCPositions = AdvancedRobbery.Config.NPCPositions or {}
			if SERVER then return end

			if not AdvancedRobbery.Config.NPCPositions or not AdvancedRobbery.Config.NPCPositions[ game.GetMap() ] then return end
			
			for k, spawninfos in pairs( AdvancedRobbery.Config.NPCPositions[ game.GetMap() ] ) do
				local ToolPreview = ents.CreateClientProp()
				if not IsValid( ToolPreview ) then return end
				ToolPreview:SetRenderMode( RENDERMODE_TRANSALPHA )
				ToolPreview:SetColor( Color( 0, 255, 0, 255 ) )
				ToolPreview:SetModel( AdvancedRobbery.Config.NPC_Model )
				ToolPreview:SetPos( spawninfos.pos )
				ToolPreview:SetAngles( spawninfos.ang )
				ToolPreview:Spawn()
				tool.ToolPreview[ #tool.ToolPreview + 1 ] = ToolPreview
			end

		end,
		onDeselectTool = function( tool, tTool )
			if SERVER then return end

			for k, v in pairs( tool.ToolPreview ) do
				if IsValid( v ) then v:Remove() end
			end
		end,
		onLeftClick = function( tool, tTool )
			if CLIENT then 
				if not IsValid( tool.EntPreview ) then return end
				
				AdvancedRobbery.Config.NPCPositions[ game.GetMap() ] = AdvancedRobbery.Config.NPCPositions[ game.GetMap() ] or {}
				
				AdvancedRobbery.Config.NPCPositions[ game.GetMap() ][ #AdvancedRobbery.Config.NPCPositions[ game.GetMap() ] + 1 ] = {
					pos = tool.EntPreview:GetPos(),
					ang = tool.EntPreview:GetAngles()
				}

				net.Start( "AdvancedRobbery.Tool" )
					net.WriteInt( 0, 5 )
					net.WriteTable( AdvancedRobbery.Config.NPCPositions[ game.GetMap() ] )
				net.SendToServer()				

			end

			tTool:NextToolFunction( 0 )
		end,
		onRightClick = function( tool, tTool )
			AdvancedRobbery.Config.NPCPositions[ game.GetMap() ] = {}
			
			if SERVER then
				AdvancedRobbery:SaveConfiguration()
			end
			
			tTool:NextToolFunction( 0 )
		end
	},
	{
		name = "General config menu",
		onSelectTool = function( tool, tTool )
			if CLIENT and IsValid( tool.EntPreview ) then
				timer.Simple( 0.1, function()
					if not IsValid( tool.EntPreview ) then return end
					tool.EntPreview:Remove()
				end)
			end
		end,
		onLeftClick = function( tool, tTool )
			if CLIENT then 
				tTool:OpenConfigurationMenu()
			end
		end,
		onRightClick = function( tool, tTool )
		end
	}
}

for k, v in pairs( ListOfTools ) do
	table.insert( AdvancedRobbery.ListOfTools, v )
end
ListOfTools = AdvancedRobbery.ListOfTools

if SERVER then
	util.AddNetworkString( "AdvancedRobbery.Tool" )

	net.Receive( "AdvancedRobbery.Tool", function( len, ply ) 
		local type = net.ReadInt( 5 )

		if not AdvancedRobbery.AdminUserGroups[ ply:GetUserGroup() ] then return end

		if type == 0 then
			local mapinfos = net.ReadTable()
			AdvancedRobbery.Config.NPCPositions[ game.GetMap() ] = mapinfos
		elseif type == 1 then
			local class = net.ReadString()
			local id = net.ReadInt( 32 )
			local mapinfos = net.ReadTable()
			
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] = AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] or {}
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] = AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] or {}
			
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ][ id ] = mapinfos
			
			local eEntity = ents.Create( class )
			if not IsValid( eEntity ) then return end
			eEntity:SetPos( mapinfos.pos )
			eEntity:SetAngles( mapinfos.ang )
			eEntity:Spawn()
			
			local phys = eEntity:GetPhysicsObject()
			if phys:IsValid() then
				phys:EnableMotion( false )
			end
			
			AdvancedRobbery.EntitiesSpawned = AdvancedRobbery.EntitiesSpawned or {}
			AdvancedRobbery.EntitiesSpawned[ class ] = AdvancedRobbery.EntitiesSpawned[ class ] or {}
			table.insert( AdvancedRobbery.EntitiesSpawned[ class ], eEntity )
		elseif type == 2 then
			local class = net.ReadString()
			AdvancedRobbery.EntitiesSpawned = AdvancedRobbery.EntitiesSpawned or {}
			for k, v in pairs( AdvancedRobbery.EntitiesSpawned[ class ] or {} ) do
				if IsValid( v ) then
					v:Remove()
				end
			end
			AdvancedRobbery.EntitiesSpawned[ class ] = {}
		elseif type == 3 then
			local config = net.ReadTable()
			AdvancedRobbery.Config.NPC_Model = config.NPC_Model
			AdvancedRobbery.Config.isCPPolice = config.isCPPolice
			AdvancedRobbery.Config.OtherPoliceTeams = config.OtherPoliceTeams
			AdvancedRobbery.Config.IsRobberyLimitedToRobbers = config.IsRobberyLimitedToRobbers
			AdvancedRobbery.Config.RobberTeams = config.RobberTeams
			AdvancedRobbery.Config.PercentageEarnedByPolice = config.PercentageEarnedByPolice
			AdvancedRobbery.Config.TimeNPCWait = config.TimeNPCWait
			AdvancedRobbery.Config.TimeBetween2CallNPC = config.TimeBetween2CallNPC
			AdvancedRobbery.Config.DrawHUD = config.DrawHUD
			AdvancedRobbery.Config.TimeToResetEverything = config.TimeToResetEverything
			AdvancedRobbery.Config.TimeBetween2Robbery = config.TimeBetween2Robbery
			AdvancedRobbery.Config.TimeBrokenAlarmAdvert = config.TimeBrokenAlarmAdvert
			AdvancedRobbery.Config.NumberPoliceMin = config.NumberPoliceMin
			AdvancedRobbery.Config.TimeWanted = config.TimeWanted
		elseif type == 4 then
			AdvancedRobbery.ScriptFunc[ net.ReadInt( 6 ) ].NetToolReceived()
			return
		end

		AdvancedRobbery:SaveConfiguration()
	end )
end

function TOOL:LeftClick()
	if ( self.nextLeftClick or 0 ) >= CurTime() then return end
	self.nextLeftClick = CurTime() + 0.5 

	if not AdvancedRobbery.AdminUserGroups[ self:GetOwner():GetUserGroup() ] then return end
	self.Weapon.ToolPreview = self.Weapon.ToolPreview or {}

	local current_func = self:GetSelectedTool()
	if ListOfTools[ current_func ].onLeftClick and isfunction( ListOfTools[ current_func ].onLeftClick ) then
		ListOfTools[ current_func ].onLeftClick( self.Weapon, self )
	end
end

function TOOL:RightClick()
	if ( self.nextRightClick or 0 ) >= CurTime() then return end
	self.nextRightClick = CurTime() + 0.5

	if not AdvancedRobbery.AdminUserGroups[ self:GetOwner():GetUserGroup() ] then return end
	self.Weapon.ToolPreview = self.Weapon.ToolPreview or {}

	local current_func = self:GetSelectedTool()
	if ListOfTools[ current_func ].onRightClick and isfunction( ListOfTools[ current_func ].onRightClick ) then
		ListOfTools[ current_func ].onRightClick( self.Weapon, self )
	end
end

function TOOL:NextToolFunction( add )
	if IsValid( self:GetOwner() ) and not AdvancedRobbery.AdminUserGroups[ self:GetOwner():GetUserGroup() ] then return end
	self.Weapon.ToolPreview = self.Weapon.ToolPreview or {}

	local current_func = self:GetWeapon():GetNWInt( "AdvancedRobbery.Tool", 1 )
	if ListOfTools[ current_func ].onDeselectTool and isfunction( ListOfTools[ current_func ].onDeselectTool ) then
		ListOfTools[ current_func ].onDeselectTool( self.Weapon, self )
	end

	if ( current_func + add > #ListOfTools ) then current_func = 0 end
	if ( current_func + add < 1 ) then current_func = #ListOfTools + 1 end
	
	local new_func = current_func + add

	if ListOfTools[ new_func ].onSelectTool and isfunction( ListOfTools[ new_func ].onSelectTool ) then
		ListOfTools[ new_func ].onSelectTool( self.Weapon, self )
	end

	if SERVER then
		self:GetWeapon():SetNWInt( "AdvancedRobbery.Tool", new_func )
	elseif ListOfTools[ new_func ].model then
		if not IsValid( self.Weapon.EntPreview ) then return end
		self.Weapon.EntPreview:SetModel( ListOfTools[ new_func ].model )
		self.Weapon.EntPreview.AngAdd = nil
	elseif IsValid( self.Weapon.EntPreview ) then
		self.Weapon.EntPreview:Remove()
	end
end

function TOOL:GetSelectedTool()
	return self:GetWeapon():GetNWInt( "AdvancedRobbery.Tool", 1 )
end

function TOOL:Reload( tr )
	if ( self.nextReloadClick or 0 ) >= CurTime() then return end
	self.nextReloadClick = CurTime() + 0.1 

	if not AdvancedRobbery.AdminUserGroups[ self:GetOwner():GetUserGroup() ] then return end
	self.Weapon.ToolPreview = self.Weapon.ToolPreview or {}

	if ( self:GetOwner():KeyDown( IN_USE ) ) then 
		self:NextToolFunction( -1 ) 
	else
		self:NextToolFunction( 1 )
	end

	self:GetWeapon():EmitSound( "weapons/pistol/pistol_empty.wav", 100, math.random( 50, 150 ) ) -- YOOOOY
	return false
end

function TOOL:Holster()
	local current_func = self:GetSelectedTool()
	if ListOfTools[ current_func ].onDeselectTool and isfunction( ListOfTools[ current_func ].onDeselectTool ) then
		ListOfTools[ current_func ].onDeselectTool( self.Weapon, self )
	end
	
	self.firstuse = false

	if SERVER then return end
	if not IsValid( self.Weapon.EntPreview ) then return end

	for k, v in pairs( self.Weapon.ToolPreview ) do
		if IsValid( v ) then v:Remove() end
	end

	self.Weapon.EntPreview:Remove()
end

function TOOL:OnRemove()
	local current_func = self:GetSelectedTool()
	if ListOfTools[ current_func ].onDeselectTool and isfunction( ListOfTools[ current_func ].onDeselectTool ) then
		ListOfTools[ current_func ].onDeselectTool( self.Weapon, self )
	end

	if SERVER then return end
	if not IsValid( self.Weapon.EntPreview ) then return end

	for k, v in pairs( self.Weapon.ToolPreview ) do
		if IsValid( v ) then v:Remove() end
	end

	self.Weapon.EntPreview:Remove()
end

function TOOL:Think()
	if not self.firstuse then
		self:NextToolFunction( 0 )
		self.firstuse = true
	end
	
	if SERVER then return end
	
	local tool = self:GetWeapon():GetNWInt( "AdvancedRobbery.Tool", 1 )
	local infos = ListOfTools[ tool ]

	if not IsValid( self.Weapon.EntPreview ) and infos.model then
		self.Weapon.EntPreview = ents.CreateClientProp()
		if not IsValid( self.Weapon.EntPreview ) then return end
		self.Weapon.EntPreview:SetModel( infos.model )
		self.Weapon.EntPreview:SetRenderMode( RENDERMODE_TRANSALPHA )
		self.Weapon.EntPreview:Spawn()
	end
	
	if not IsValid( self.Weapon.EntPreview ) then return end

	self.Weapon.EntPreview.AngAdd = self.Weapon.EntPreview.AngAdd or Angle( 0, 0, 0 )
	if ( self:GetOwner():KeyDown( IN_USE ) ) then 
		self.Weapon.EntPreview.AngAdd = Angle( self.Weapon.EntPreview.AngAdd.pitch, self.Weapon.EntPreview.AngAdd.yaw + 1, self.Weapon.EntPreview.AngAdd.roll )
	end

	local vPos
	if infos.stayOnGround then
		local trace = util.TraceLine( {
				start = self:GetOwner():GetEyeTrace().HitPos,
				endpos = self:GetOwner():GetEyeTrace().HitPos + Vector( 0, 0, -10000000 ),
			} )
		vPos = trace.HitPos 
	else
		vPos = self:GetOwner():GetEyeTrace().HitPos
	end
	self.Weapon.EntPreview:SetColor( Color( 0, 255, 0, 150 ) )
	self.Weapon.EntPreview:SetAngles( self:GetOwner():GetEyeTrace().HitNormal:Angle() + ( infos.ang or Angle( 0, 0, 0 ) ) + self.Weapon.EntPreview.AngAdd )
	infos.vec = infos.vec or Vector( 0, 0, 0 )
	self.Weapon.EntPreview:SetPos( vPos + self.Weapon.EntPreview:GetAngles():Forward() * infos.vec.x + self.Weapon.EntPreview:GetAngles():Right() * infos.vec.y + self.Weapon.EntPreview:GetAngles():Up() * infos.vec.z ) 
end

if SERVER then return end

local bgcolor = Color( 200, 200, 200, 255 )
local bluecolor = Color( 0, 0, 120, 255 )
local darkbluecolor = Color( 0, 0, 50, 255 )
local redcolor = Color( 255, 0, 0, 255 )
local greycolor = Color( 0, 0, 0, 255 )

local function OpenGeneralConfig()
	local MainFrame = vgui.Create( "DFrame" )
	MainFrame:SetSize( 450, 500 )
	MainFrame:Center()
	MainFrame:SetTitle( "" )
	MainFrame:ShowCloseButton( false )
	MainFrame:MakePopup()
	MainFrame.Paint = function() end
	function MainFrame:OnClose()
		local configToSend = table.Copy( AdvancedRobbery.Config )
		AdvancedRobbery.Config.NPCPositions = nil
		AdvancedRobbery.Config.EntitiesSpawns = nil

		net.Start( "AdvancedRobbery.Tool" )
			net.WriteInt( 3, 5 )
			net.WriteTable( AdvancedRobbery.Config )
		net.SendToServer()	
	end
	
	local ContentPanel = vgui.Create( "DPanel", MainFrame )
	ContentPanel:SetSize( 450, 475 )
	function ContentPanel:Paint( w, h ) 
		draw.RoundedBox( 0, 0, 0, w, h, bgcolor )
		draw.RoundedBox( 0, 0, 0, w, 25, bluecolor )
	end
	
	local CloseButton = vgui.Create( "DButton", ContentPanel )
	CloseButton:SetText( "" )
	CloseButton:SetSize( 25, 25 )
	CloseButton:SetPos( MainFrame:GetWide() - 35, 0 )
	function CloseButton:Paint( w, h )
		if self:IsHovered() then
			draw.SimpleText( "X", "AdvancedRobbery.Font17", w / 2, h / 2, redcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		else
			draw.SimpleText( "X", "AdvancedRobbery.Font17", w / 2, h / 2, bgcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
	end
	function CloseButton:DoClick( w, h )
		MainFrame:Close() 
	end
	
	local title = vgui.Create( "DLabel", ContentPanel )
	title:Dock( TOP )
	title:DockMargin( 5, 0, 5, 5 )
	title:SetContentAlignment( 5 )
	title:SetFont( "AdvancedRobbery.Font17" )
	title:SetText( "Advanced Robbery - General Config" )
	title:SetTall( 30 )
	title:SetTextColor( Color( 255, 255, 255 ) )
	
	local LeftPanel = vgui.Create( "DScrollPanel", ContentPanel )
	LeftPanel:SetPos( 0, 25 )
	LeftPanel:SetSize( 280, ContentPanel:GetTall() - 30 )
	LeftPanel.Paint = function( pnl, w, h ) end
	local sbarHide = LeftPanel:GetVBar()
	sbarHide:SetWide( 0 )
	
	local RightPanel = vgui.Create( "DScrollPanel", ContentPanel )
	RightPanel:SetPos( LeftPanel:GetWide(), 25 )
	RightPanel:SetWide( ContentPanel:GetWide() - LeftPanel:GetWide() )
	RightPanel:SetTall( ContentPanel:GetTall() - 30 )
	RightPanel.Paint = function( pnl, w, h ) end
	
	local sbar = RightPanel:GetVBar( )
	sbar:SetHideButtons( true )
	
	function sbarHide:Think()
		self:SetScroll( sbar:GetScroll() ) 
	end

	function sbar:Paint( w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(255, 255, 255,0 ) )
	end	
	sbar:SetWide( 5 )
	function sbar.btnGrip:Paint( w, h )
		draw.RoundedBox( 5, 0, 0, w, h, bluecolor )
	end

	local isCPPoliceLabel = vgui.Create( "DLabel", LeftPanel )
	isCPPoliceLabel:Dock( TOP )
	isCPPoliceLabel:DockMargin( 5, 0, 5, 5 )
	isCPPoliceLabel:SetContentAlignment( 4 )
	isCPPoliceLabel:SetFont( "AdvancedRobbery.Font17" )
	isCPPoliceLabel:SetText( "Is jobs specified as CP in DarkRP considered as Police :" )
	isCPPoliceLabel:SetTall( 30 )
	isCPPoliceLabel:SetWrap( true )
	isCPPoliceLabel:SetTextColor( greycolor )
	
	local isCPPoliceLabelPanel = vgui.Create( "DPanel", RightPanel )
	isCPPoliceLabelPanel:SetTall( 30 )
	isCPPoliceLabelPanel:Dock( TOP )
	isCPPoliceLabelPanel:DockMargin( 5, 0, 5, 5 )
	isCPPoliceLabelPanel.Paint = function() end
	
	local isCPPoliceLabelCheck = vgui.Create( "DCheckBox", isCPPoliceLabelPanel )
	isCPPoliceLabelCheck:Dock( LEFT )
	isCPPoliceLabelCheck:DockMargin( 2.5, 2.5, 2.5, 2.5 )
	isCPPoliceLabelCheck:SetWide( 25 )
	isCPPoliceLabelCheck:SetChecked( AdvancedRobbery.Config.isCPPolice )
	isCPPoliceLabelCheck.OnChange = function( self, value )
		AdvancedRobbery.Config.isCPPolice = value
	end

	local otherPoliceTeamsLabel = vgui.Create( "DLabel", LeftPanel )
	otherPoliceTeamsLabel:Dock( TOP )
	otherPoliceTeamsLabel:DockMargin( 5, 5, 5, 5 )
	otherPoliceTeamsLabel:SetContentAlignment( 8 )
	otherPoliceTeamsLabel:SetFont( "AdvancedRobbery.Font17" )
	otherPoliceTeamsLabel:SetText( "Other Police teams:" )
	otherPoliceTeamsLabel:SetTall( 30 * ( table.Count( AdvancedRobbery.Config.OtherPoliceTeams ) + 1 ) )
	otherPoliceTeamsLabel:SetWrap( true )
	otherPoliceTeamsLabel:SetTextColor( greycolor )
	
	for k, v in pairs( AdvancedRobbery.Config.OtherPoliceTeams ) do

		local otherPoliceTeamsPanel = vgui.Create( "DPanel", RightPanel )
		otherPoliceTeamsPanel:Dock( TOP )
		otherPoliceTeamsPanel:SetTall( 30 )

		local otherPoliceTeamsEntry = vgui.Create( "DComboBox", otherPoliceTeamsPanel )
		otherPoliceTeamsEntry:Dock( LEFT )
		otherPoliceTeamsEntry:DockMargin( 5, 5, 5, 5 )
		otherPoliceTeamsEntry:SetWide( RightPanel:GetWide() - 30 )
		-- otherPoliceTeamsEntry:SetNumeric( false )
		otherPoliceTeamsEntry:SetValue( v )
		for k, v in pairs( RPExtraTeams ) do
			otherPoliceTeamsEntry:AddChoice( team.GetName( k ) )
		end
		-- otherPoliceTeamsEntry:SetUpdateOnType( true )
		otherPoliceTeamsEntry.OnSelect = function( self, index, value )
			AdvancedRobbery.Config.OtherPoliceTeams[ k ] = value
		end

		local otherPoliceTeamsRemove = vgui.Create( "DButton", otherPoliceTeamsPanel )
		otherPoliceTeamsRemove:SetText( "" )
		otherPoliceTeamsRemove:Dock( FILL )
		function otherPoliceTeamsRemove:Paint( w, h )
			if self:IsHovered() then
				draw.SimpleText( "X", "AdvancedRobbery.Font17", w / 2, h / 2, redcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			else
				draw.SimpleText( "X", "AdvancedRobbery.Font17", w / 2, h / 2, bluecolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
		end
		function otherPoliceTeamsRemove:DoClick( w, h )
			AdvancedRobbery.Config.OtherPoliceTeams[ k ] = nil
			MainFrame:Close()
			OpenGeneralConfig()
		end

	end
	
	local otherPoliceTeamsAdd = vgui.Create( "DButton", RightPanel )
	otherPoliceTeamsAdd:Dock( TOP )
	otherPoliceTeamsAdd:DockMargin( 5, 5, 5, 5 )
	otherPoliceTeamsAdd:SetTall( 25 )
	otherPoliceTeamsAdd:SetText( "" )
	function otherPoliceTeamsAdd:Paint( w, h )
		if self:IsHovered() then
			draw.RoundedBox( 0, 0, 0, w, h, darkbluecolor )
		else
			draw.RoundedBox( 0, 0, 0, w, h, bluecolor )
			draw.RoundedBoxEx( 0, 0, h - 5, w, 5, darkbluecolor, false, false, true, true )
		end
		
		draw.SimpleText( "+ADD", "AdvancedRobbery.Font17", w / 2, h / 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	function otherPoliceTeamsAdd:DoClick()
		table.insert( AdvancedRobbery.Config.OtherPoliceTeams, "Team name" )
		MainFrame:Close()
		OpenGeneralConfig()
	end

	local isLimitedRobbersLabel = vgui.Create( "DLabel", LeftPanel )
	isLimitedRobbersLabel:Dock( TOP )
	isLimitedRobbersLabel:DockMargin( 5, 0, 5, 5 )
	isLimitedRobbersLabel:SetContentAlignment( 4 )
	isLimitedRobbersLabel:SetFont( "AdvancedRobbery.Font17" )
	isLimitedRobbersLabel:SetText( "Is the robbery limited to the robbers team configured here :" )
	isLimitedRobbersLabel:SetTall( 30 )
	isLimitedRobbersLabel:SetWrap( true )
	isLimitedRobbersLabel:SetTextColor( greycolor )
	
	local isLimitedRobbersPanel = vgui.Create( "DPanel", RightPanel )
	isLimitedRobbersPanel:SetTall( 30 )
	isLimitedRobbersPanel:Dock( TOP )
	isLimitedRobbersPanel:DockMargin( 5, 0, 5, 5 )
	isLimitedRobbersPanel.Paint = function() end
	
	local isLimitedRobbersCheck = vgui.Create( "DCheckBox", isLimitedRobbersPanel )
	isLimitedRobbersCheck:Dock( LEFT )
	isLimitedRobbersCheck:DockMargin( 2.5, 2.5, 2.5, 2.5 )
	isLimitedRobbersCheck:SetWide( 25 )
	isLimitedRobbersCheck:SetChecked( AdvancedRobbery.Config.IsRobberyLimitedToRobbers )
	isLimitedRobbersCheck.OnChange = function( self, value )
		AdvancedRobbery.Config.IsRobberyLimitedToRobbers = value
	end

	local robbersTeamsLabel = vgui.Create( "DLabel", LeftPanel )
	robbersTeamsLabel:Dock( TOP )
	robbersTeamsLabel:DockMargin( 5, 5, 5, 5 )
	robbersTeamsLabel:SetContentAlignment( 8 )
	robbersTeamsLabel:SetFont( "AdvancedRobbery.Font17" )
	robbersTeamsLabel:SetText( "Robbers teams ( if limited to robbers ):" )
	robbersTeamsLabel:SetTall( 30 * ( table.Count( AdvancedRobbery.Config.RobberTeams ) + 1 ) )
	robbersTeamsLabel:SetWrap( true )
	robbersTeamsLabel:SetTextColor( greycolor )
	
	for k, v in pairs( AdvancedRobbery.Config.RobberTeams ) do

		local robbersTeamsPanel = vgui.Create( "DPanel", RightPanel )
		robbersTeamsPanel:Dock( TOP )
		robbersTeamsPanel:SetTall( 30 )

		local robbersTeamsEntry = vgui.Create( "DComboBox", robbersTeamsPanel )
		robbersTeamsEntry:Dock( LEFT )
		robbersTeamsEntry:DockMargin( 5, 5, 5, 5 )
		robbersTeamsEntry:SetWide( RightPanel:GetWide() - 30 )
		-- robbersTeamsEntry:SetNumeric( false )
		robbersTeamsEntry:SetValue( v )
		for k, v in pairs( RPExtraTeams ) do
			robbersTeamsEntry:AddChoice( team.GetName( k ) )
		end
		-- robbersTeamsEntry:SetUpdateOnType( true )
		robbersTeamsEntry.OnSelect = function( self, index, value )
			AdvancedRobbery.Config.RobberTeams[ k ] = value
		end

		local robbersTeamsRemove = vgui.Create( "DButton", robbersTeamsPanel )
		robbersTeamsRemove:SetText( "" )
		robbersTeamsRemove:Dock( FILL )
		function robbersTeamsRemove:Paint( w, h )
			if self:IsHovered() then
				draw.SimpleText( "X", "AdvancedRobbery.Font17", w / 2, h / 2, redcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			else
				draw.SimpleText( "X", "AdvancedRobbery.Font17", w / 2, h / 2, bluecolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
		end
		function robbersTeamsRemove:DoClick( w, h )
			AdvancedRobbery.Config.RobberTeams[ k ] = nil
			MainFrame:Close()
			OpenGeneralConfig()
		end

	end
	
	local robbersTeamsAdd = vgui.Create( "DButton", RightPanel )
	robbersTeamsAdd:Dock( TOP )
	robbersTeamsAdd:DockMargin( 5, 5, 5, 5 )
	robbersTeamsAdd:SetTall( 25 )
	robbersTeamsAdd:SetText( "" )
	function robbersTeamsAdd:Paint( w, h )
		if self:IsHovered() then
			draw.RoundedBox( 0, 0, 0, w, h, darkbluecolor )
		else
			draw.RoundedBox( 0, 0, 0, w, h, bluecolor )
			draw.RoundedBoxEx( 0, 0, h - 5, w, 5, darkbluecolor, false, false, true, true )
		end
		
		draw.SimpleText( "+ADD", "AdvancedRobbery.Font17", w / 2, h / 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	function robbersTeamsAdd:DoClick()
		table.insert( AdvancedRobbery.Config.RobberTeams, "Team name" )
		MainFrame:Close()
		OpenGeneralConfig()
	end

	for k, v in pairs( AdvancedRobbery.Config.DrawHUD ) do 
		local shouldDrawHud = vgui.Create( "DLabel", LeftPanel )
		shouldDrawHud:Dock( TOP )
		shouldDrawHud:DockMargin( 5, 0, 5, 5 )
		shouldDrawHud:SetContentAlignment( 4 )
		shouldDrawHud:SetFont( "AdvancedRobbery.Font17" )
		shouldDrawHud:SetText( "Should draw the HUD " .. k .. " :" )
		shouldDrawHud:SetTall( 25 )
		shouldDrawHud:SetWrap( true )
		shouldDrawHud:SetTextColor( greycolor )
		
		local shouldDrawPanelHud = vgui.Create( "DPanel", RightPanel )
		shouldDrawPanelHud:SetTall( 30 )
		shouldDrawPanelHud:Dock( TOP )
		shouldDrawPanelHud:DockMargin( 5, 0, 5, 5 )
		shouldDrawPanelHud.Paint = function() end
		
		local shouldDrawCheckHud = vgui.Create( "DCheckBox", shouldDrawPanelHud )
		shouldDrawCheckHud:Dock( LEFT )
		shouldDrawCheckHud:DockMargin( 2.5, 2.5, 2.5, 2.5 )
		shouldDrawCheckHud:SetWide( 25 )
		shouldDrawCheckHud:SetChecked( AdvancedRobbery.Config.DrawHUD[ k ] )
		shouldDrawCheckHud.OnChange = function( self, value )
			AdvancedRobbery.Config.DrawHUD[ k ] = value
		end
	end

	local percentagePoliceLabel = vgui.Create( "DLabel", LeftPanel )
	percentagePoliceLabel:Dock( TOP )
	percentagePoliceLabel:DockMargin( 5, 0, 5, 5 )
	percentagePoliceLabel:SetContentAlignment( 4 )
	percentagePoliceLabel:SetFont( "AdvancedRobbery.Font17" )
	percentagePoliceLabel:SetWrap( true )
	percentagePoliceLabel:SetText( "Percentage of the value of the bag earned by police when confiscated (0-100):" )
	percentagePoliceLabel:SetTall( 30 )
	percentagePoliceLabel:SetTextColor( greycolor )
	
	local percentagePoliceEntry = vgui.Create( "DNumberWang", RightPanel )
	percentagePoliceEntry:Dock( TOP )
	percentagePoliceEntry:DockMargin( 5, 0, 5, 5 )
	percentagePoliceEntry:SetTall( 30 )
	percentagePoliceEntry:SetNumeric( true )
	percentagePoliceEntry:SetValue( AdvancedRobbery.Config.PercentageEarnedByPolice )
	percentagePoliceEntry:SetMin( 0 )
	percentagePoliceEntry:SetMax( 100 )
	percentagePoliceEntry:SetUpdateOnType( true )
	percentagePoliceEntry.OnValueChange = function( self, value )
		AdvancedRobbery.Config.PercentageEarnedByPolice = tonumber( value )
	end

	local modelNPCLabel = vgui.Create( "DLabel", LeftPanel )
	modelNPCLabel:Dock( TOP )
	modelNPCLabel:DockMargin( 5, 0, 5, 5 )
	modelNPCLabel:SetContentAlignment( 4 )
	modelNPCLabel:SetFont( "AdvancedRobbery.Font17" )
	modelNPCLabel:SetText( "Blackmarket dealer NPC model :" )
	modelNPCLabel:SetWrap( true )
	modelNPCLabel:SetTall( 30 )
	modelNPCLabel:SetTextColor( greycolor )
	
	local modelNPCEntry = vgui.Create( "DTextEntry", RightPanel )
	modelNPCEntry:Dock( TOP )
	modelNPCEntry:DockMargin( 5, 0, 5, 5 )
	modelNPCEntry:SetTall( 30 )
	modelNPCEntry:SetNumeric( false )
	modelNPCEntry:SetValue( AdvancedRobbery.Config.NPC_Model )
	modelNPCEntry:SetUpdateOnType( true )
	modelNPCEntry.OnValueChange = function( self, value )
		AdvancedRobbery.Config.NPC_Model = value
	end

	local timeNPCLabel = vgui.Create( "DLabel", LeftPanel )
	timeNPCLabel:Dock( TOP )
	timeNPCLabel:DockMargin( 5, 0, 5, 5 )
	timeNPCLabel:SetContentAlignment( 4 )
	timeNPCLabel:SetFont( "AdvancedRobbery.Font17" )
	timeNPCLabel:SetText( "Time that the black market dealer wait once he's called: " )
	timeNPCLabel:SetTall( 30 )
	timeNPCLabel:SetWrap( true )
	timeNPCLabel:SetTextColor( greycolor )

	local timeNPCEntry = vgui.Create( "DTextEntry", RightPanel )
	timeNPCEntry:Dock( TOP )
	timeNPCEntry:DockMargin( 5, 0, 5, 5 )
	timeNPCEntry:SetTall( 30 )
	timeNPCEntry:SetNumeric( true )
	timeNPCEntry:SetValue( AdvancedRobbery.Config.TimeNPCWait )
	timeNPCEntry:SetUpdateOnType( true )
	timeNPCEntry.OnValueChange = function( self, value )
		AdvancedRobbery.Config.TimeNPCWait = tonumber( value )
	end

	local time2NPCLabel = vgui.Create( "DLabel", LeftPanel )
	time2NPCLabel:Dock( TOP )
	time2NPCLabel:DockMargin( 5, 0, 5, 5 )
	time2NPCLabel:SetContentAlignment( 4 )
	time2NPCLabel:SetFont( "AdvancedRobbery.Font17" )
	time2NPCLabel:SetText( "Time to wait to call the blackmarket dealer after he has despawned:" )
	time2NPCLabel:SetWrap( true )
	time2NPCLabel:SetTall( 30 )
	time2NPCLabel:SetTextColor( greycolor )

	local time2NPCEntry = vgui.Create( "DTextEntry", RightPanel )
	time2NPCEntry:Dock( TOP )
	time2NPCEntry:DockMargin( 5, 0, 5, 5 )
	time2NPCEntry:SetTall( 30 )
	time2NPCEntry:SetNumeric( true )
	time2NPCEntry:SetValue( AdvancedRobbery.Config.TimeBetween2CallNPC )
	time2NPCEntry:SetUpdateOnType( true )
	time2NPCEntry.OnValueChange = function( self, value )
		AdvancedRobbery.Config.TimeBetween2CallNPC = tonumber( value )
	end

	local timeResetLabel = vgui.Create( "DLabel", LeftPanel )
	timeResetLabel:Dock( TOP )
	timeResetLabel:DockMargin( 5, 0, 5, 5 )
	timeResetLabel:SetContentAlignment( 4 )
	timeResetLabel:SetFont( "AdvancedRobbery.Font17" )
	timeResetLabel:SetText( "Time the robbers have to rob:" )
	timeResetLabel:SetTall( 30 )
	timeResetLabel:SetTextColor( greycolor )

	local timeResetEntry = vgui.Create( "DTextEntry", RightPanel )
	timeResetEntry:Dock( TOP )
	timeResetEntry:DockMargin( 5, 0, 5, 5 )
	timeResetEntry:SetTall( 30 )
	timeResetEntry:SetNumeric( true )
	timeResetEntry:SetValue( AdvancedRobbery.Config.TimeToResetEverything )
	timeResetEntry:SetUpdateOnType( true )
	timeResetEntry.OnValueChange = function( self, value )
		AdvancedRobbery.Config.TimeToResetEverything = tonumber( value )
	end

	local timeBrokenAlarmLabel = vgui.Create( "DLabel", LeftPanel )
	timeBrokenAlarmLabel:Dock( TOP )
	timeBrokenAlarmLabel:DockMargin( 5, 0, 5, 5 )
	timeBrokenAlarmLabel:SetContentAlignment( 4 )
	timeBrokenAlarmLabel:SetWrap( true )
	timeBrokenAlarmLabel:SetFont( "AdvancedRobbery.Font17" )
	timeBrokenAlarmLabel:SetText( "Time that a broken alarm take to advert the police:" )
	timeBrokenAlarmLabel:SetTall( 30 )
	timeBrokenAlarmLabel:SetTextColor( greycolor )

	local timeBrokenAlarmEntry = vgui.Create( "DTextEntry", RightPanel )
	timeBrokenAlarmEntry:Dock( TOP )
	timeBrokenAlarmEntry:DockMargin( 5, 0, 5, 5 )
	timeBrokenAlarmEntry:SetTall( 30 )
	timeBrokenAlarmEntry:SetNumeric( true )
	timeBrokenAlarmEntry:SetValue( AdvancedRobbery.Config.TimeBrokenAlarmAdvert )
	timeBrokenAlarmEntry:SetUpdateOnType( true )
	timeBrokenAlarmEntry.OnValueChange = function( self, value )
		AdvancedRobbery.Config.TimeBrokenAlarmAdvert = tonumber( value )
	end
	
	local timeBet2RobLabel = vgui.Create( "DLabel", LeftPanel )
	timeBet2RobLabel:Dock( TOP )
	timeBet2RobLabel:DockMargin( 5, 0, 5, 5 )
	timeBet2RobLabel:SetContentAlignment( 4 )
	timeBet2RobLabel:SetFont( "AdvancedRobbery.Font17" )
	timeBet2RobLabel:SetWrap( true )
	timeBet2RobLabel:SetText( "Time to wait to rob again once a robbery is finished:" )
	timeBet2RobLabel:SetTall( 30 )
	timeBet2RobLabel:SetTextColor( greycolor )

	local timeBet2RobEntry = vgui.Create( "DTextEntry", RightPanel )
	timeBet2RobEntry:Dock( TOP )
	timeBet2RobEntry:DockMargin( 5, 0, 5, 5 )
	timeBet2RobEntry:SetTall( 30 )
	timeBet2RobEntry:SetNumeric( true )
	timeBet2RobEntry:SetValue( AdvancedRobbery.Config.TimeBetween2Robbery )
	timeBet2RobEntry:SetUpdateOnType( true )
	timeBet2RobEntry.OnValueChange = function( self, value )
		AdvancedRobbery.Config.TimeBetween2Robbery = tonumber( value )
	end

	local minPoliceLabel = vgui.Create( "DLabel", LeftPanel )
	minPoliceLabel:Dock( TOP )
	minPoliceLabel:DockMargin( 5, 0, 5, 5 )
	minPoliceLabel:SetContentAlignment( 4 )
	minPoliceLabel:SetFont( "AdvancedRobbery.Font17" )
	minPoliceLabel:SetText( "Number of police players minimum:" )
	minPoliceLabel:SetTall( 30 )
	minPoliceLabel:SetTextColor( greycolor )

	local minPoliceEntry = vgui.Create( "DTextEntry", RightPanel )
	minPoliceEntry:Dock( TOP )
	minPoliceEntry:DockMargin( 5, 0, 5, 5 )
	minPoliceEntry:SetTall( 30 )
	minPoliceEntry:SetNumeric( true )
	minPoliceEntry:SetValue( AdvancedRobbery.Config.NumberPoliceMin )
	minPoliceEntry:SetUpdateOnType( true )
	minPoliceEntry.OnValueChange = function( self, value )
		AdvancedRobbery.Config.NumberPoliceMin = tonumber( value )
	end

	local timeWantedLabel = vgui.Create( "DLabel", LeftPanel )
	timeWantedLabel:Dock( TOP )
	timeWantedLabel:DockMargin( 5, 0, 5, 5 )
	timeWantedLabel:SetContentAlignment( 4 )
	timeWantedLabel:SetFont( "AdvancedRobbery.Font17" )
	timeWantedLabel:SetText( "How much time the robber is wanted:" )
	timeWantedLabel:SetTall( 30 )
	timeWantedLabel:SetTextColor( greycolor )

	local timeWantedEntry = vgui.Create( "DTextEntry", RightPanel )
	timeWantedEntry:Dock( TOP )
	timeWantedEntry:DockMargin( 5, 0, 5, 5 )
	timeWantedEntry:SetTall( 30 )
	timeWantedEntry:SetNumeric( true )
	timeWantedEntry:SetValue( AdvancedRobbery.Config.TimeWanted )
	timeWantedEntry:SetUpdateOnType( true )
	timeWantedEntry.OnValueChange = function( self, value )
		AdvancedRobbery.Config.TimeWanted = tonumber( value )
	end
end

function TOOL:OpenConfigurationMenu()
	OpenGeneralConfig()
end

function TOOL:DrawToolScreen( sw, sh )
	-- local w = 10
	-- local h = 10
	-- local lineH = 0

	-- -- Anybody, a better way?
	-- for id, t in pairs( ListOfTools ) do
	-- 	surface.SetFont( "AdvancedRobbery.Font30" )
	-- 	local tw, th = surface.GetTextSize( t.name )
	-- 	w = math.max( tw + 10, w )
	-- 	h = h + th
	-- 	lineH = th
	-- end

	-- local x = 0
	-- local y = 10

	-- draw.RoundedBox( 4, 0, 0, sw, sh, Color( 0, 0, 0, 255 ) )

	-- for id, t in pairs( ListOfTools ) do
	-- 	if ( id == self:GetSelectedTool() ) then
	-- 		local clr = HSVToColor( 0, 0, 0.4 + math.sin( CurTime() * 4 ) * 0.1 )
	-- 		draw.RoundedBox( 0, 0, y + 5 + ( id - 1 ) * lineH, sw, lineH, clr )

	-- 		local a = surface.GetTextSize( t.name )
	-- 		if ( a > ( sw - 10 ) ) then
	-- 			x = -a + math.fmod( CurTime() * sw, sw + a )
	-- 		end
	-- 	else
	-- 		x = 0
	-- 	end
	-- 	draw.SimpleText( t.name, "AdvancedRobbery.Font30", x + 5, y + 5 + ( id - 1 ) * lineH, Color( 255, 255, 255 ) )
	-- end

	local w = 10
	local h = 10
	local lineH = 0

	-- Anybody, a better way?
	for id, t in pairs( ListOfTools ) do
		surface.SetFont( "AdvancedRobbery.Font40" )
		local tw, th = surface.GetTextSize( t.name )
		w = math.max( tw + 10, w )
		h = h + th
		lineH = th
	end

	local x = 0
	local y = ( sh - h ) / 2 + math.cos( self:GetSelectedTool() / #ListOfTools * math.pi ) * ( h - sh ) / 2

	draw.RoundedBox( 4, 0, 0, sw, sh, Color( 0, 0, 0, 255 ) )

	for id, t in pairs( ListOfTools ) do
		if ( id == self:GetSelectedTool() ) then
			local clr = HSVToColor( 0, 0, 0.4 + math.sin( CurTime() * 4 ) * 0.1 )
			draw.RoundedBox( 0, 0, y + 5 + ( id - 1 ) * lineH, sw, lineH, clr )

			local a = surface.GetTextSize( t.name )
			if ( a > ( sw - 10 ) ) then
				x = -a + math.fmod( CurTime() * sw, sw + a )
			end
		else
			x = 0
		end
		draw.SimpleText( t.name, "AdvancedRobbery.Font40", x + 5, y + 5 + ( id - 1 ) * lineH, Color( 255, 255, 255 ) )
	end

end
