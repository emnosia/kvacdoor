AdvancedRobbery = AdvancedRobbery or {}
AdvancedRobbery.Config = AdvancedRobbery.Config or {}
AdvancedRobbery.NPCChances = AdvancedRobbery.NPCChances or {}
AdvancedRobbery.Language = {}

function AdvancedRobbery:Init()

	local directories = { -- for priority order
		[ 1 ] = 'shared',
		[ 2 ] = 'server',
		[ 3 ] = 'client'
	}

	for _, file_name in pairs( file.Find( 'advanced-robbery/sh_*.lua', 'LUA' ) ) do
		-- include shared
		include( 'advanced-robbery/' .. file_name )
		if SERVER then
			-- AddCSLuaFile shared
			AddCSLuaFile( 'advanced-robbery/' .. file_name )
			print('loading ' .. file_name)
		end
	end
	for _, file_name in pairs( file.Find( 'advanced-robbery/cl_*.lua', 'LUA' ) ) do
		if SERVER then	
			-- AddCSLuaFile client
			AddCSLuaFile( 'advanced-robbery/' .. file_name )
			print('loading ' .. file_name)
		elseif CLIENT then
			-- include client
			include( 'advanced-robbery/' .. file_name )
		end
	end
	for _, file_name in pairs( file.Find( 'advanced-robbery/sv_*.lua', 'LUA' ) ) do
		if SERVER then	
			-- include server
			include( 'advanced-robbery/' .. file_name )
			print('loading ' .. file_name)
		end
	end

	for _, dir in pairs( directories ) do
		for _, file_name in pairs( file.Find( 'advanced-robbery/' .. dir .. '/sh_*.lua', 'LUA' ) ) do

			-- include shared
			include( 'advanced-robbery/' .. dir .. '/' .. file_name )
			if SERVER then
				-- AddCSLuaFile shared
				AddCSLuaFile( 'advanced-robbery/' .. dir .. '/' .. file_name )
				print('loading ' .. file_name)
			end
		end
		for _, file_name in pairs( file.Find( 'advanced-robbery/' .. dir .. '/cl_*.lua', 'LUA' ) ) do
			if SERVER then	
				-- AddCSLuaFile client
				AddCSLuaFile( 'advanced-robbery/' .. dir .. '/' .. file_name )
				print('loading ' .. file_name)
			elseif CLIENT then
				-- include client
				include( 'advanced-robbery/' .. dir .. '/' .. file_name )
			end
		end
		for _, file_name in pairs( file.Find( 'advanced-robbery/' .. dir .. '/sv_*.lua', 'LUA' ) ) do
			if SERVER then	
				-- include server
				include( 'advanced-robbery/' .. dir .. '/' .. file_name )
				print('loading ' .. file_name)
			end
		end
	end
end

AdvancedRobbery:Init()