if SERVER then
	local function InitializeTomasPrinters()
		print("[Tomas Printers] Printer config file loaded :]")
		
		TPRINTERS_CONFIG = {}
		
		TPRINTERS_CONFIG.BatteryAdd = 100 -- How much battery entity adds battery to the printer.

		TPRINTERS_CONFIG.CoolingCellAdd = 20 -- How much cooling cell entity adds cooling to the printer.

		------------------------------------------BLUE PRINTER----------------------------------------------------------
		
		TPRINTERS_CONFIG.Battery = 5 -- How much battery does it take from the printer when it prints something
		
		TPRINTERS_CONFIG.Cooling = 10 -- How much cooling gel does it take from the printer when it prints something
		
		TPRINTERS_CONFIG.Heat = 20 -- How much heat does the printer get if the cooling cell is empty
		
		TPRINTERS_CONFIG.Money = 50 -- How much money does it prints. This number is multiplied by the printer speed (stars).
		
		TPRINTERS_CONFIG.PrintRate = math.random(30,60) -- That will give random number between 30 and 60 for the print rate. Time is in seconds.
		
		------------------------------------------BLUE PRINTER----------------------------------------------------------
		
		------------------------------------------RED PRINTER----------------------------------------------------------
		
		TPRINTERS_CONFIG.Battery_Red = 5 -- How much battery does it take from the printer when it prints something
		
		TPRINTERS_CONFIG.Cooling_Red = 10 -- How much cooling gel does it take from the printer when it prints something
		
		TPRINTERS_CONFIG.Heat_Red = 20 -- How much heat does the printer get if the cooling cell is empty
		
		TPRINTERS_CONFIG.Money_Red = 60 -- How much money does it prints. This number is multiplied by the printer speed (stars).
		
		TPRINTERS_CONFIG.PrintRate_Red = math.random(30,60) -- That will give random number between 30 and 60 for the print rate. Time is in seconds.
		
		------------------------------------------RED PRINTER----------------------------------------------------------
		
		------------------------------------------GREEN PRINTER----------------------------------------------------------
		
		TPRINTERS_CONFIG.Battery_Green = 5 -- How much battery does it take from the printer when it prints something
		
		TPRINTERS_CONFIG.Cooling_Green = 10 -- How much cooling gel does it take from the printer when it prints something
		
		TPRINTERS_CONFIG.Heat_Green = 20 -- How much heat does the printer get if the cooling cell is empty
		
		TPRINTERS_CONFIG.Money_Green = 70 -- How much money does it prints. This number is multiplied by the printer speed (stars).
		
		TPRINTERS_CONFIG.PrintRate_Green = math.random(30,60) -- That will give random number between 30 and 60 for the print rate. Time is in seconds.
		
		------------------------------------------GREEN PRINTER----------------------------------------------------------

		------------------------------------------YELLOW PRINTER----------------------------------------------------------
		
		TPRINTERS_CONFIG.Battery_Yellow = 5 -- How much battery does it take from the printer when it prints something
		
		TPRINTERS_CONFIG.Cooling_Yellow = 10 -- How much cooling gel does it take from the printer when it prints something
		
		TPRINTERS_CONFIG.Heat_Yellow = 20 -- How much heat does the printer get if the cooling cell is empty
		
		TPRINTERS_CONFIG.Money_Yellow = 80 -- How much money does it prints. This number is multiplied by the printer speed (stars).
		
		TPRINTERS_CONFIG.PrintRate_Yellow = math.random(30,60) -- That will give random number between 30 and 60 for the print rate. Time is in seconds.
		
		------------------------------------------YELLOW PRINTER----------------------------------------------------------

		------------------------------------------PURPLE PRINTER----------------------------------------------------------
		
		TPRINTERS_CONFIG.Battery_Purple = 5 -- How much battery does it take from the printer when it prints something
		
		TPRINTERS_CONFIG.Cooling_Purple = 10 -- How much cooling gel does it take from the printer when it prints something
		
		TPRINTERS_CONFIG.Heat_Purple = 10 -- How much heat does the printer get if the cooling cell is empty
		
		TPRINTERS_CONFIG.Money_Purple = 100 -- How much money does it prints. This number is multiplied by the printer speed (stars).
		
		TPRINTERS_CONFIG.PrintRate_Purple = math.random(30,60) -- That will give random number between 30 and 60 for the print rate. Time is in seconds.
		
		------------------------------------------PURPLE PRINTER----------------------------------------------------------
	end
	
	hook.Add("Initialize","InitializeTomasPrinters",InitializeTomasPrinters)

end