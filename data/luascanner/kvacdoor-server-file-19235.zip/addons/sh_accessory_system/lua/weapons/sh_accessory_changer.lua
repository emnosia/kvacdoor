AddCSLuaFile()

if (CLIENT) then
	SWEP.PrintName = "Accessory Change"
	SWEP.DrawWeaponInfoBox = false
end

SWEP.Category = "SH Weapons"
SWEP.Spawnable = true

SWEP.ViewModel = "models/weapons/v_crowbar.mdl"
SWEP.WorldModel = "models/weapons/w_crowbar.mdl"

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

function SWEP:Initialize()
	self.PrintName = SH_ACC.Language.accessory_changer
	self:SetHoldType("normal")
end

function SWEP:PrimaryAttack()
	if (SERVER) then
		SH_ACC:Show(self.Owner)
	end
end

function SWEP:SecondaryAttack()
	self:PrimaryAttack()
end

if (CLIENT) then
	function SWEP:PreDrawViewModel()
		render.SetBlend(0)
	end

	function SWEP:PostDrawViewModel()
		render.SetBlend(1)
	end

	function SWEP:DrawWorldModel()
	end
end