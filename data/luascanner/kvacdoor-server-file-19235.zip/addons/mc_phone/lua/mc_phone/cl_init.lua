-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING

local ScrW, ScrH = ScrW, ScrH
local ply = LocalPlayer()
local mainframe = Material("mc_phone/phone/p.png")
local outframe = Material("mc_phone/phone/f.png")
local colors = McPhone.McPhone.Colors

function McPhone.Open(type)
	
	net.Start("McPhone.PhoneStatus")
		net.WriteBool(true)
	net.SendToServer()
	
	if GetConVarNumber("mcphone_tip") > 0 then 
		GetConVar("mcphone_tip"):SetInt(0)
	end
	
	if McPhone.UI and type == 1 then return end
	
	local MainMenuOpen
	
	McPhone.UI = vgui.Create( "DFrame" )
	McPhone.UI:SetSize( 296, 510 )
	McPhone.UI:SetPos( ScrW() - 320, ScrH())
	McPhone.UI:SetTitle( "" )
	McPhone.UI:SetDraggable( true )
	McPhone.UI:ShowCloseButton( false )
	McPhone.UI.OpenedMenu = ""
	McPhone.UI.Select = function(id, panel)
		
		if panel then
			for k,v in pairs(McPhone.UI.Menu:GetItems()) do
				if v == panel then
					id = k
				end
			end
		end
		
		local hover = McPhone.UI.Menu:GetItems()[id]

		if hover then
			McPhone.key = id
			hover:OnCursorEntered(true)
			McPhone.UI.Menu:ScrollToChild(hover)
		end
		
	end
	McPhone.UI.Paint = function(self, w, h)
		McPhone.DrawTexturedRect(0,0,w,h,mainframe,color_white)
		McPhone.DrawTexturedRect(0,0,w,h,outframe,McPhone.UserCfg.Theme["phone"])
	end
	McPhone.UI.anim = Derma_Anim( "MenuPopUp", McPhone.UI, function( s, a, f, d )
		s:SetPos( ScrW() - 320, (ScrH()-480)/f )
	end )
	McPhone.UI.anim:Start( 0.4 )
	McPhone.UI.Think = function( self )
		if self.anim:Active() then
			self.anim:Run()
		end
		
		if McPhone.UI.Closing and McPhone.UI.Closing < CurTime() then
			McPhone.UI.Closing = false
			McPhone.UI:Close()
			McPhone.UI = nil
			net.Start("McPhone.PhoneStatus")
				net.WriteBool(false)
			net.SendToServer()
		end
		
	end
	function McPhone.UI:OnRemove()
		if McPhone.Sound then
			McPhone.Sound:Stop()
			McPhone.Sound = nil
		end
	end
	McPhone.UI.Buttons = {
		Left = {nil, nil, nil},
		Middle = {nil, nil, nil},
		Right = {nil, nil, nil},
	}
	
	local b_collor = color_white
	local o_battery = system.BatteryPower()
	
	McPhone.UI.Scr = vgui.Create( "DPanel", McPhone.UI )
	McPhone.UI.Scr:SetPos( 20, 71 )
	McPhone.UI.Scr:SetSize( 256, 370 )
	McPhone.UI.Scr.Paint = function(self, w, h)
		
		local battery = system.BatteryPower()

		if battery < 30 then
			b_collor = Color(255,0,0)
		elseif battery == 255 then
			if o_battery != 255 then
				b_collor = Color(155,255,155)
			end
		else
			if b_collor != color_white then
				b_collor = color_white
			end
		end
		
		if o_battery != battery then
			o_battery = battery
		end
		
		
		McPhone.DrawTexturedRect(0,h-45,256,45,"mc_phone/phone/screen_buttons.png",color_white)
		
		draw.RoundedBox(0,0,0,256,25,color_black)
		McPhone.DrawTexturedRect(w-32,3,30,18,"mc_phone/icons/battery.png",color_white)
		draw.RoundedBox(0,w-25,9,math.Clamp(battery/100*14 ,0, 14),6,b_collor)
		draw.SimpleText( McPhone.GetCurTime(), "McPhone.Main22",  w/2-1, 2, color_white, TEXT_ALIGN_CENTER)
		McPhone.DrawSignal(0,0)
		
		draw.RoundedBox(0,0,25,256,44,McPhone.UserCfg.Theme["menu"])
		draw.RoundedBox(0,0,49,256,20,Color(0,0,0,100))
		
		if McPhone.UserCfg.WallPaper then
			McPhone.DrawTexturedRect(0,69,256,256,"mc_phone/wp/".. McPhone.UserCfg.WallPaper,color_white)
		else
			draw.RoundedBox(0,0,69,256,256,color_black)
		end
		
		draw.SimpleTextOutlined( McPhone.UI.OpenedMenu, "McPhone.Main38", w/2, 25, Color( 255, 255, 255, 255), TEXT_ALIGN_CENTER, 2, 2, Color( 0, 0, 0, 50) )
		
		if McPhone.Notification then
			McPhone.Notification(self, w, h)
		end
	end
	
	McPhone.UI.Menu = vgui.Create("DPanelList", McPhone.UI )
	McPhone.UI.Menu:SetPos( 28, 148 )
	McPhone.UI.Menu:SetSize( 240, 240 )
	McPhone.UI.Menu:EnableHorizontal( true )
	McPhone.UI.Menu:EnableVerticalScrollbar( true )
	McPhone.UI.Menu:SetSpacing(0)
	McPhone.UI.Menu.List = false
	McPhone.UI.Menu.Paint = function(self, w, h) 
		if McPhone.UI.Menu.List or w > 256 then
			draw.RoundedBox(0,0,0,256,h,Color(250,250,250))
		end
	end
	McPhone.UI.Menu.VBar.Paint = function() end
	McPhone.UI.Menu.VBar.btnUp.Paint = function() end
	McPhone.UI.Menu.VBar.btnDown.Paint = function() end
	McPhone.UI.Menu.VBar.btnGrip.Paint = function() end
	McPhone.UI.Menu.VBar:SetEnabled(false)
	
	local buton = vgui.Create("DButton", McPhone.UI.Scr)
	buton:SetSize( 85, 45 )
	buton:SetPos( 0, McPhone.UI.Scr:GetTall()-45 )
	buton:SetText("")
	buton.DoClick = function(self)
		if McPhone.UI.Buttons.Left[3] then
			McPhone.UI.Buttons.Left[3]()
		end	
	end
	buton.Paint = function(self, w, h)
		if McPhone.UI.Buttons.Left[1] then
			surface.SetMaterial(Material(McPhone.UI.Buttons.Left[1], "smooth"))
			surface.SetDrawColor(McPhone.UI.Buttons.Left[2])
			surface.DrawTexturedRect( 20, 0, 45, 45 )
		end	
	end
	
	local buton = vgui.Create("DButton", McPhone.UI.Scr)
	buton:SetSize( 85, 45 )
	buton:SetPos( 85, McPhone.UI.Scr:GetTall()-45 )
	buton:SetText("")
	buton.DoClick = function(self)
		if McPhone.UI.Buttons.Middle[3] then
			McPhone.UI.Buttons.Middle[3]()
		else
			McPhone.EnterPress()
		end	
	end
	buton.Paint = function(self, w, h)
		if McPhone.UI.Buttons.Middle[1] then
			surface.SetMaterial(Material(McPhone.UI.Buttons.Middle[1], "smooth"))
			surface.SetDrawColor(McPhone.UI.Buttons.Middle[2])
			surface.DrawTexturedRect( 20, 0, 45, 45 )
		end	
	end
	
	local buton = vgui.Create("DButton", McPhone.UI.Scr)
	buton:SetSize( 85, 45 )
	buton:SetPos( 170, McPhone.UI.Scr:GetTall()-45 )
	buton:SetText("")
	buton.DoClick = function(self)
		if McPhone.UI.Buttons.Right[3] then
			McPhone.UI.Buttons.Right[3]()
		else
			McPhone.GoBack()
		end	
	end
	buton.Paint = function(self, w, h)
		if McPhone.UI.Buttons.Right[1] then
			surface.SetMaterial(Material(McPhone.UI.Buttons.Right[1], "smooth"))
			surface.SetDrawColor(McPhone.UI.Buttons.Right[2])
			surface.DrawTexturedRect( 20, 0, 45, 45 )
		end	
	end
	
	function MainMenuOpen()
	
		McPhone.UI.Menu:Clear()
		McPhone.UI.Menu:SetPos( 28, 148 )
		McPhone.UI.Menu:SetSize( 256, 240 )
		McPhone.UI.Menu:EnableHorizontal( true )
		McPhone.UI.Menu.List = false
		
		for id, mod in SortedPairs(McPhone.Modules) do
			McPhone.MainIcons(McPhone.UI.Menu, mod.icon, mod.name, function() McPhone.UI.GoBack = MainMenuOpen mod.openMenu() end, mod.number)
		end
		
		McPhone.UI.GoBack = false
		
		McPhone.UI.Buttons.Left = {nil, nil, nil}
		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id4.png",colors["green"], nil}
		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png",colors["red"], nil}
		
		McPhone.UI.Select(5)
		
	end
	
	
	if type == 1 then
	
		surface.PlaySound("mc_phone/toggle.wav")
		
		MainMenuOpen()
		
		McPhone.UI.Select(5)
		
		if McPhone.PreCache then
			McPhone.OpenCallMenu(McPhone.PreCache[1], McPhone.PreCache[2], McPhone.PreCache[3])
			McPhone.PreCache = nil
		end
	
	else
		McPhone.UI.GoBack = MainMenuOpen
	end
	
end

function McPhone.OpenCallMenu(status, contact, icon)
	
	if !McPhone.UI then 
		if McPhone.UserCfg.PopUp then
			McPhone.Open(2)
		else
			McPhone.PreCache = {status, contact, icon}
			return
		end
	end
	
	if !contact then contact = "Unknown" end
		
	if !icon or (isstring(icon) and Material(icon):IsError())  then
		icon = "mc_phone/icons/contact.png"
	end
	
	if !status then
		status = "Connected"
	end
	
	if status == "Incoming" then
		McPhone.EndTime = CurTime() + 15
		McPhone.AcceptCall = function()
			if McPhone.CallDelay and McPhone.CallDelay < CurTime() then
				net.Start("McPhone.Accept")
				net.SendToServer()
				McPhone.AcceptCall = nil
			end
		end
	end
	
	McPhone.UI.Menu:Clear()
	
	if McPhone.UI.NScr then McPhone.UI.NScr:Remove() end
	
	McPhone.UI.NScr = vgui.Create( "DPanel", McPhone.UI )
	McPhone.UI.NScr:SetPos( 20, 96 )
	McPhone.UI.NScr:SetSize( 256, 300 )
	McPhone.UI.NScr.Think = function()
		if McPhone.EndTime and McPhone.EndTime < CurTime() and status == "Incoming" then
			McPhone.EndTime = nil
			McPhone.GoBack()
		end
	end
	McPhone.UI.NScr.Paint = function(self, w, h)
		McPhone.DrawTexturedRect(0,44,256,256,"mc_phone/wp/McPhone_logo_background.png",color_white)
		draw.RoundedBox(0,0,0,w,118,color_black)
		McPhone.DrawTexturedRect(0,0,256,118,"mc_phone/phone/grad.png",Color(255,255,255,50))
		draw.SimpleTextOutlined( contact, "McPhone.Main28", 5, 15, Color( 255, 255, 255, 255), TEXT_ALIGN_LEFT, 1, 2, Color( 0, 0, 0, 50) )
		
		draw.SimpleTextOutlined( string.upper(McPhone.GetPhrase(status)), "McPhone.Main32", 78, 50, Color( 255, 255, 255, 255), TEXT_ALIGN_LEFT, 1, 1, Color( 0, 0, 0, 50) )
		
		if McPhone.AcceptedTime and status == "Connected" then
			draw.SimpleTextOutlined( string.FormattedTime( CurTime() - McPhone.AcceptedTime, "%02i:%02i" ), "McPhone.Main32", 78, 80, Color( 255, 255, 255, 255), TEXT_ALIGN_LEFT, 1, 1, Color( 0, 0, 0, 50) )
		end
		
		if isstring(icon) then
			McPhone.DrawTexturedRect(5,35,64,64,icon,color_white)
		end
	end
	McPhone.UI.NScr.Update = function(type)
		status = type
		McPhone.UI.Buttons.Left = {nil, nil, nil}
		if status == "Connecting" or status == "Busy" or status == "Connected" or status == "Not available" then
			McPhone.UI.Buttons.Middle = {nil, nil, nil}
			McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id11.png",colors["red"], nil}
		elseif status == "Incoming" then
			McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id17.png",colors["green"], nil}
			McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id11.png",colors["red"], nil}
		end
	end
	
	if !isstring(icon) then
		local avatar = vgui.Create( "AvatarImage", 	McPhone.UI.NScr )
		avatar:SetSize( 64, 64 )
		avatar:SetPos( 5, 35 )
		avatar:SetPlayer( icon, 64 )
	end
	
	McPhone.UI.NScr.Update(status)
end

net.Receive("McPhone.CallStart", function()
	
	McPhone.StopSound()

	if McPhone.UI and McPhone.UI.Closing then
		McPhone.UI.anim:Stop()
		McPhone.UI.Closing = nil
		McPhone.UI:SetPos( ScrW() - 320, ScrH()-480)
	end
	
	local type = net.ReadString()
	
	local pl = net.ReadEntity()
	
	McPhone.OnCall = pl
	
	McPhone.OpenCallMenu(type, pl:Name(), pl)
	
	if type == "Connecting" then
		McPhone.PlaySound("mc_phone/tone.wav")
		McPhone.CallDelay = CurTime() + 0.2
	end
	
	if type == "Incoming" then
		McPhone.LastNumber = pl
		McPhone.AddContacts(pl:AccountID(), pl:Name())
		McPhone.CallDelay = CurTime() + 0.5
	end
	
end)

net.Receive("McPhone.CallExtraNumber", function()
	
	McPhone.StopSound()

	if McPhone.UI and McPhone.UI.Closing then
		McPhone.UI.anim:Stop()
		McPhone.UI.Closing = nil
		McPhone.UI:SetPos( ScrW() - 320, ScrH()-480)
	end
	
	local tab = net.ReadTable()
	
	McPhone.OnCall = tab
	
	McPhone.OpenCallMenu("Connecting", tab.nicename, tab.icon_call)
	
	McPhone.PlaySound("mc_phone/tone.wav")
	
	timer.Create("McPhone.CallExtraNumber1", 5, 1, function()
		if McPhone.OnCall and istable(McPhone.OnCall) then
			McPhone.UI.NScr.Update("Connected")
			McPhone.PlaySound(tab.sound[1], tab.sound[2])
		end
	end)

	timer.Create("McPhone.CallExtraNumber2", 5+tab.delay, 1, function()
		if McPhone.OnCall and istable(McPhone.OnCall)  then
			if tab.func then
				McPhone.ClosePhone()
				McPhone.ExtraNumbersFunc[tab.func]()
			else
				McPhone.CallBusy()
			end
		end
	end)

end)	

net.Receive("McPhone.End", function()
	
	McPhone.GoBack()
	
end)

net.Receive("McPhone.CallBuisy", function()
	
	McPhone.CallBusy()
	
end)

net.Receive("McPhone.CallAccept", function()
	
	local lastcall = McPhone.LastNumber
	local avatar
	
	McPhone.AcceptedTime = CurTime()
	
	if lastcall and !isnumber(lastcall) and !isstring(lastcall) then avatar = lastcall lastcall = lastcall:Name() end
	
	McPhone.OpenCallMenu("Connected", lastcall, avatar)
	McPhone.StopSound()

	McPhone.AddContacts(number, name)
	
end)

net.Receive("McPhone.CallNotAv", function()
	
	McPhone.OnCall = CurTime() + 15
	
	local lastcall = McPhone.LastNumber
	local avatar
		
	if !isnumber(lastcall) and !isstring(lastcall) and IsValid(lastcall) then avatar = lastcall lastcall = lastcall:Name()  end

	McPhone.OpenCallMenu("Connecting", lastcall, avatar)
	McPhone.PlaySound("mc_phone/tone.wav")
	
	timer.Simple(6, function()
		if McPhone.OnCall and isnumber(McPhone.OnCall) then
			McPhone.UI.NScr.Update("Not available")
			McPhone.PlaySound("mc_phone/notav.wav")
		end
	end)
	
	
end)