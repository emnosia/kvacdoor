-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING
-- Here you can create easter eggs :)

McPhone.ExtraNumbers = {}

McPhone.ExtraNumbers["88005553535"] = {
	delay = 12,
	icon = "nope.png",
	nicename = "Домашние деньги",
	sound = {"http://macnco.one/sounds/88005553535.mp3", true},
}

McPhone.ExtraNumbers["1990"] = {
	delay = 60,
	icon = "nope.png",
	nicename = "Big Bill Hell's Cars",
	sound = {"http://macnco.one/sounds/big_bill.mp3", true},
}

McPhone.ExtraNumbersFunc = {}

if EmergencyResponse then
	McPhone.ExtraNumbers ["911"] = {
		delay = 3,
		icon = {"emergencyresponse_fleodon/911dispatch_logo.png", true},
		icon_call = "emergencyresponse_fleodon/911dispatch_logo.png",
		nicename = "Emergency services",
		addtoсontacts = true,
		sound = {"http://macnco.one/sounds/911.wav", true},
		func = "911",
		delay_func = "911_check",
		
	}
	McPhone.ExtraNumbersFunc["911"] = function() EmergencyResponse:CreateVictimInterface( false, "" ) end
	
	if SERVER then
		
		hook.Remove( "PlayerSay", "EmergencyResponse:VictimInterface:PlayerSay")
		
		McPhone.ExtraNumbersFunc["911_check"] = function() 
			local nUse = cookie.GetNumber( "_cooldownDelayNextUse", 0 )
			local nTime = os.time()
			local stop = false
			
			if not EmergencyDispatch.InstantEmergencyCall then
				if nTime < nUse then
					stop = true
				end
				
				cookie.Set( "_cooldownDelayNextUse", nTime + EmergencyDispatch.DispatchCallouts.CallCooldown )
			end
			
			return stop
		end
		
	end
end

if AdvancedRobbery then
	McPhone.ExtraNumbers ["9523877"] = {
		delay = 5.5,
		icon = {"mc_phone/icons/contact.png", true},
		icon_call = "mc_phone/icons/contact.png",
		nicename = "Dealer",
		addtoсontacts = true,
		sound = {"http://macnco.one/sounds/dealer.wav", true},
		func = nil,
		delay_func = "AdvancedRobbery_del",
		
	}
	
	if SERVER then
				
		McPhone.ExtraNumbersFunc["AdvancedRobbery_del"] = function(caller)
		
			AdvancedRobbery.NPCInfos = AdvancedRobbery.NPCInfos or {
				free = true,
				pos = Vector( 0, 0, 0 ),
				lastCall = -AdvancedRobbery.Config.TimeBetween2CallNPC,
				caller = NULL,
			}
			
			local stop = false
			
			if AdvancedRobbery_IsRobber( caller ) and AdvancedRobbery.NPCInfos.free and CurTime() - AdvancedRobbery.NPCInfos.lastCall > AdvancedRobbery.Config.TimeBetween2CallNPC then
				timer.Simple(7, function() if caller and IsValid(caller) then AdvancedRobbery.CreateNPC( caller ) end end)
			else
				stop = true
			end
			
			return stop
		end
		
	end
end

function McPhone.GetCurTime()
	
	local time = "00:00"
	
	time = os.date( "%H:%M", os.time())
	
	if McPhone.Config.AtmosTime then
		if GetGlobalInt("McPhone.AtmosTime", 0) > 0 then
			time = os.date( "!%H:%M", GetGlobalInt("McPhone.AtmosTime", 0) * 3600)
		end
	elseif McPhone.Config.StormFoxTime then
		if StormFox then
			time = StormFox.GetRealTime(nil,false)
		end
	end

	return time
	
end

function McPhone.GetByNumber(number)
	
	if McPhone.ExtraNumbers[number] then
		return McPhone.ExtraNumbers[number]
	end
	
	if string.Explode("#",number)[1] == "268" then
		return Player(tonumber(string.Explode("#",number)[2]))
	else
		return player.GetByAccountID(tonumber(number))
	end
	
	return false
	
end