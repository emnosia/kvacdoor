-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING

local files, folders = file.Find("mc_phone/language/*", "LUA")

for k,v in pairs(files) do
	if (SERVER) then
		include("mc_phone/language/" .. v)
		AddCSLuaFile("mc_phone/language/" .. v)
		MsgC( Color(0, 0, 255), "[McPhone] Найден языковый файл:"..v.."\n" )
	else
		include("mc_phone/language/" .. v)
	end
end

function McPhone.GetPhrase(name, ...)
	
	local lang = McPhone.Language[McPhone.Config.Language] or McPhone.Language["en"]
	
	local prase = lang[name]
	
	if !prase then return "NULL" end
	
    return string.format(prase, ...)
	
end

