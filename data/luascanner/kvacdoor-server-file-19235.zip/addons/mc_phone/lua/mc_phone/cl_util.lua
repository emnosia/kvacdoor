-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING

local render = render
local surface = surface
local cam = cam
local rt, rtm1, rtm2
local table = table
local CurTimeL = UnPredictedCurTime
local ScrW, ScrH = ScrW, ScrH
local ScreenScale = ScreenScale
local math = math
local NewFont = surface.CreateFont
local ply = LocalPlayer()

NewFont( "McPhone.Main38", { font = "Calibri", extended = true, size = 38, antialias = true, weight = 500} )
NewFont( "McPhone.Main32", { font = "Calibri", extended = true, size = 32, antialias = true, weight = 500} )
NewFont( "McPhone.Main28", { font = "Calibri", extended = true, size = 28, antialias = true, weight = 500} )
NewFont( "McPhone.Main24", { font = "Calibri", extended = true, size = 24, antialias = true, weight = 500} )
NewFont( "McPhone.Main22", { font = "Calibri", extended = true, size = 22, antialias = true, weight = 800} )
NewFont( "McPhone.Main20", { font = "Calibri", extended = true, size = 20, antialias = true, weight = 500} )
NewFont( "McPhone.Main16", { font = "Calibri", extended = true, size = 16, antialias = true, weight = 800} )

-- ───────── Contacts ─────────--

McPhone.Contacts = {}

function McPhone.UpdateContacts()
	
	json_table = util.TableToJSON( McPhone.Contacts, true )
	
	file.Write("mcphone_user_contacts.txt",json_table)

end

function McPhone.GetContacts()
	
	if !file.Exists("mcphone_user_contacts.txt","DATA") then
		
		McPhone.UpdateContacts()
		
	else
	
		local config = util.JSONToTable(file.Read("mcphone_user_contacts.txt","DATA"))
		
		McPhone.Contacts = config
		
	end

end

function McPhone.AddContacts(number, name)
	
	if McPhone.Contacts[number] then 
		
		if McPhone.Contacts[number] != name then
			McPhone.Contacts[number] = name
		end
		
		return 
	end
	
	if !number or !name then return end
	
	McPhone.Contacts[number] = name
	
	McPhone.Notify(McPhone.GetPhrase("new_сontact"), nil)
	
	McPhone.UpdateContacts()

end

McPhone.GetContacts()

-- ────── Notifications ───────--

function McPhone.Notify(title, text, snd)
	
	if snd then
		McPhone.PlaySound("mc_phone/sms/"..McPhone.UserCfg.Profile.Smstone..".wav")
	end
	
	if McPhone.UI and McPhone.UI.Scr then
		local stimer = CurTime() + 3
		
		local pos = -255
		local tall = 23

		if text then
			tall = 52
			
			surface.SetFont("McPhone.Main28")
			local wh = surface.GetTextSize( text )
				
			if wh > 200 then
				text = string.sub(text,0,10).."..."
			end
		end
		
		McPhone.Notification = function(self, w, h)
			
			if stimer > CurTime() then
				pos = Lerp(FrameTime() * 7, pos, 1)
			end
			
			draw.RoundedBox(2,pos,0,254,tall+4,color_black)
			draw.RoundedBox(4,pos+2,2,250,tall,color_white)
			draw.RoundedBoxEx(2,pos+2,2+(tall/2),250,tall/2,Color(0,0,0,100),false,false,true,true)
			
			draw.SimpleTextOutlined( title, "McPhone.Main22", pos + 10, 2, color_white, TEXT_ALIGN_LEFT, 0, 1, color_black)
			
			if text then
				draw.SimpleTextOutlined( text, "McPhone.Main28", pos + 10, 25, color_black, TEXT_ALIGN_LEFT, 0, 1, color_white)
			end
			
			if stimer < CurTime() then
				pos = Lerp(FrameTime() * 7, pos, 256 )
				if pos > 255 then
					McPhone.Notification = nil
				end
			end
		end
	else
		
		local stimer = CurTime() + 3
		
		local alpha = 0
		local tall = 35

		if text then
			tall = 70
			
			surface.SetFont("McPhone.Main28")
			local wh = surface.GetTextSize( text )
				
			if wh > 250 then
				text = string.sub(text,0,10).."..."
			end
		end
			
		surface.SetFont("McPhone.Main32")
		local w = surface.GetTextSize( title )
		
		if w > 250 then
			title = string.sub(title, 0, 9) .. "..."
		end
		
		local x, y = ScrW() - 320, ScrH()
		
		McPhone.HudNotification = function()
			if stimer > CurTime() then
				alpha = Lerp(FrameTime() * 7, alpha, 255)
			end
			
			draw.RoundedBox(0,x,y-(alpha-180),256,tall,Color(0,0,0,alpha-100))
			McPhone.DrawTexturedRect(x,y-(alpha-180),256,tall,"gui/gradient",Color(0,0,0,alpha-100))
			
			draw.SimpleTextOutlined( title, "McPhone.Main32", x+10, y-(alpha-180), Color(255,200,100,alpha), TEXT_ALIGN_LEFT, 0, 1, Color(0,0,0,alpha))
			
			if text then
				draw.SimpleTextOutlined( text, "McPhone.Main28", x+10, y-(alpha-210), Color(255,255,255,alpha), TEXT_ALIGN_LEFT, 0, 1, Color(0,0,0,alpha))
			end
			
			if stimer < CurTime() then
				alpha = Lerp(FrameTime() * 3, alpha, 0 )
				if alpha < 2 then
					McPhone.HudNotification = function() end
				end
			end
		end
	end
	
end

net.Receive("McPhone.Notify", function()

	local title = net.ReadString()
	local text = net.ReadString()
	local snd = net.ReadBool()
	
	McPhone.Notify(title, text, snd)
	
end)

-- ───────── Sound fx ─────────--

function McPhone.PlaySound(snd, url)
	
	if McPhone.Sound then
		McPhone.Sound:Stop()
		McPhone.Sound = nil
	end
	
	if url then
		sound.PlayURL ( snd, "mono", function( station )
			if ( IsValid( station ) ) then
				McPhone.Sound = station
				McPhone.Sound:Play()
			end
		end )
	else
		McPhone.Sound = CreateSound(ply, snd)
		McPhone.Sound:ChangeVolume(1, 0)
		McPhone.Sound:ChangePitch(100, 0)
		McPhone.Sound:Play()
	end
end

function McPhone.StopSound()
	
	if McPhone.Sound then
		McPhone.Sound:Stop()
		McPhone.Sound = nil
	end
	
end

function McPhone.StopCall()
	if McPhone.OnCall then
		
		if istable(McPhone.OnCall) then
			net.Start("McPhone.CallExtraNumber")
			net.SendToServer()
			if timer.Exists( "McPhone.CallExtraNumber1" ) then
				timer.Remove( "McPhone.CallExtraNumber1" )
			end
			if timer.Exists( "McPhone.CallExtraNumber2" ) then
				timer.Remove( "McPhone.CallExtraNumber2" )
			end
		end
		
		McPhone.OnCall = nil
		
		if McPhone.UI then
			if McPhone.UI.NScr then McPhone.UI.NScr:Remove() end
		else
			McPhone.PreCache = nil
		end
		
		net.Start("McPhone.CallDeny")
		net.SendToServer()
		
		McPhone.StopSound()
		
	end
end

-- ─────────── Calls ──────────--

function McPhone.CallBusy()

	McPhone.OnCall = CurTime() + 2.3
	
	local avatar
	local lastcall = McPhone.LastNumber
	
	if !isnumber(lastcall) and !isstring(lastcall) then lastcall = lastcall:Name() avatar = lastcall end
	
	McPhone.OpenCallMenu("Busy", lastcall, avatar)
	McPhone.PlaySound("mc_phone/bs.wav")
	
end

-- ──────────── UI ────────────--

function McPhone.DrawTexturedRect(x,y,w,h,mat,color)
	
	if isstring(mat) then
		mat = Material(mat)
	end
	
	surface.SetDrawColor(color)
	surface.SetMaterial(mat)
	surface.DrawTexturedRect(x,y,w,h)
end

McPhone.Signal = 3

function McPhone.DrawSignal(x,y)
	
	if McPhone.Signal < 1 then
		draw.SimpleText( "No signal", "McPhone.Main16",  x+5, y+5, color_white, TEXT_ALIGN_LEFT)
	else
		for i=0,McPhone.Signal-1 do
			draw.RoundedBox(0,x+5+(i*5+i*2),y+13-(i*5),5,8+(i*5),color_white)
		end
		for i=0,2 do
			draw.RoundedBox(0,x+5+(i*5+i*2),y+19,5,2,color_white)
		end
	end
end

timer.Create("McPhone.SignalChange", 10, 0, function() McPhone.Signal = math.random(1,3) end)

function McPhone.MainIcons(parent, icon, text, func, label)
	
	local alpha, a = 0, 0
	
	local buton = vgui.Create("DButton")
	buton:SetSize( 80, 80)
	buton:SetText("")
	buton.DoClick = function(self)
	
		surface.PlaySound("mc_phone/open_1.wav")
		
		if func then
			func(self)
		end
		
	end	
	buton.Paint = function(self, w, h)
		
		if self.hover then
			alpha = Lerp(0.05, alpha, 100)
			a = 10
		else
			alpha = Lerp(0.05, alpha, 0)
			a = 0
		end
		
		draw.RoundedBox(8,8,8,64,64,Color(255,255,255,alpha))
		
		surface.SetMaterial(Material(icon, "smooth"))
		surface.SetDrawColor(color_white)
		surface.DrawTexturedRect( 15-a/2, 15-a/2, 50+a, 50+a )
		
		if label and label > 0 then
			surface.SetFont("McPhone.Main20")
			local w = surface.GetTextSize( label )
			local wh = 18
			
			if w  > wh - 10 then
				wh = w + 10
			end
			draw.RoundedBox(12,5,5,wh,18,Color(255,0,0))
			draw.SimpleText( label, "McPhone.Main20", 10, 2, color_white, TEXT_ALIGN_LEFT)
		end
		
	end
	buton.OnCursorEntered = function(self, mute) 
		if !mute then
			surface.PlaySound("mc_phone/click.wav")
		end
		
		self.hover = true
		if McPhone.UI then
			McPhone.UI.OpenedMenu = text
		end
		
		for k,v in pairs(parent:GetItems()) do
			if v == self then continue end
			v:OnCursorExited()
		end
		
	end
	buton.OnCursorExited = function(self) self.hover = false end
	
	parent:AddItem(buton)
	
end

function McPhone.NumberIcons(parent, size, text, text2)
	
	local alpha, a = 0, 0
	
	local buton = vgui.Create("DButton")
	buton:SetSize( size, 64 )
	buton:SetText("")
	buton.DoClick = function(self)
	
		surface.PlaySound("mc_phone/open_1.wav")
		
		if McPhone.UI.OpenedMenu == McPhone.GetPhrase("enter_number") then
			McPhone.UI.OpenedMenu = text
		else
			McPhone.UI.OpenedMenu = McPhone.UI.OpenedMenu .. text
		end
		
		return true
		
	end
	buton.Paint = function(self, w, h)
		
		if self.hover then
			draw.RoundedBox(0,0,0,w,h,McPhone.UserCfg.Theme["buttons"])
		else
			draw.RoundedBox(0,0,0,w,h,Color(33,42,47,255))
		end
		
		surface.SetDrawColor(0,0,0,120)
		surface.DrawOutlinedRect(0, 0, w, h)
		
		draw.SimpleText( text, "McPhone.Main38", w/2, 7, color_white, TEXT_ALIGN_CENTER)
		
		if text2 then
			draw.SimpleText( text2, "McPhone.Main22", w/2, h-25, Color(220,220,220), TEXT_ALIGN_CENTER)
		end
		
	end
	buton.OnCursorEntered = function(self, mute) 
		if !mute then
			surface.PlaySound("mc_phone/click.wav")
		end
		
		self.hover = true
		
		for k,v in pairs(parent:GetItems()) do
			if v == self then continue end
			v:OnCursorExited()
		end
		
	end
	buton.OnCursorExited = function(self) self.hover = false end
	
	parent:AddItem(buton)
	
end

local function drawScrSpaceText( text, x, y, mx, color)
	
	local font = "McPhone.Main32"
	
	surface.SetFont(font)
	local w = surface.GetTextSize( text )
	
	if w + x > mx then
		font = "McPhone.Main24"
		y = y + 3
	end
	
	draw.SimpleText( text, font, x, y, color, TEXT_ALIGN_LEFT)
	
end

function McPhone.ListIcons(parent, icon, text, check, func, ignore, snd, supress)
	
	local icon_nohover
	
	if istable(icon) then
		icon_nohover = icon[2]
		icon = icon[1]
	end

	local buton = vgui.Create("DButton")
	buton.icon = icon
	buton.check = check
	buton:SetSize(256, 51)
	buton:SetText("")
	buton.DoClick = function(self)
		if !snd then
			surface.PlaySound("mc_phone/open_1.wav")
		end
		
		if func then
			func(self)
		end
		
		if McPhone.UI and !ignore then
			McPhone.UI.OpenedMenu = text
		end
		
		return supress
		
	end
	buton.Paint = function(self, w, h)
		
		if self.check then
			icon = "mc_phone/icons/settings/id_9.png"
		elseif icon != buton.icon then
			icon = buton.icon
		end
		
		if self.hover then
			draw.RoundedBox(0,0,0,w,h,McPhone.UserCfg.Theme["buttons"])
			if isstring(icon) and !icon_nohover then
				McPhone.DrawTexturedRect(5,10,32,32,icon,color_white)
			end
			drawScrSpaceText( text, 45, 7, w, color_white)
		else
			if isstring(icon) and !icon_nohover then
				McPhone.DrawTexturedRect(5,10,32,32,icon,color_black)
			end
			
			drawScrSpaceText( text, 45, 7, w, color_black)
		end
		
		if icon_nohover then
			McPhone.DrawTexturedRect(5,10,32,32,icon,color_white)
		end
		
		draw.RoundedBox(0,0,h-3,w,3,Color(0,0,0,100))
	end
	buton.OnCursorEntered = function(self, mute) 
		if !mute and !snd then
			surface.PlaySound("mc_phone/click.wav")
		end
		
		if snd then
			if snd == "snd" then
				McPhone.StopSound()
			else
				McPhone.PlaySound(snd)
			end
		end
		
		self.hover = true
		
		for k,v in pairs(parent:GetItems()) do
			if v == self then continue end
			v:OnCursorExited()
		end
	end
	buton.OnCursorExited = function(self)
		self.hover = false
	end
	
	if !isstring(icon) then
		local avatar = vgui.Create( "AvatarImage", buton )
		avatar:SetSize( 32, 32 )
		avatar:SetPos( 5, 10 )
		avatar:SetPlayer( icon, 32 )
	end
	
	parent:AddItem(buton)
	
	return buton
	
end

function McPhone.ListTexts(parent, sms, name, text, time, check, func, ismail, ignore, snd, supress)
	
	if sms then
		if ismail then
			sms = McPhone.Mail[sms]
		else
			sms = McPhone.SMS[sms]
		end
	end
	
	surface.SetFont("McPhone.Main32")
	local w = surface.GetTextSize( name )
	
	if w > 230 then
		name = string.sub(name, 0, 10) .. "..."
	end

	surface.SetFont("McPhone.Main22")
	local w = surface.GetTextSize( text )
		
	if w > 200 then
		text = string.sub(text,0,10).."..."
	end

	local hcolor = color_black
	
	local buton = vgui.Create("DButton")
	buton:SetSize(256, 51)
	buton:SetText("")
	buton.DoClick = function(self)
		if !snd then
			surface.PlaySound("mc_phone/open_1.wav")
		end
		
		if func then
			func(self)
		end
		
		if McPhone.UI and !ignore then
			McPhone.UI.OpenedMenu = name
		end
		
		return supress
		
	end
	buton.Paint = function(self, w, h)
		
		if self.hover then
			draw.RoundedBox(0,0,0,w,h,McPhone.UserCfg.Theme["buttons"])
			if sms and sms.New then
				McPhone.DrawTexturedRect(5,h/2-8,16,16,"mc_phone/icons/round.png",color_white)
			end
			hcolor = color_white
		else
			if sms and sms.New then
				McPhone.DrawTexturedRect(5,h/2-8,16,16,"mc_phone/icons/round.png",McPhone.UserCfg.Theme["buttons"])
			end
			hcolor = color_black
		end
		
		draw.SimpleText( name, "McPhone.Main32", 30, 0, hcolor, TEXT_ALIGN_LEFT)
		draw.SimpleText( time, "McPhone.Main22", w-2, 0, hcolor, TEXT_ALIGN_RIGHT)
		draw.SimpleText( text, "McPhone.Main22", 30, 25, hcolor, TEXT_ALIGN_LEFT)
		draw.RoundedBox(0,0,h-3,w,3,Color(0,0,0,100))
	end
	buton.OnCursorEntered = function(self, mute) 
		if !mute and !snd then
			surface.PlaySound("mc_phone/click.wav")
		end
		
		if snd then
			if snd == "snd" then
				McPhone.StopSound()
			else
				McPhone.PlaySound(snd)
			end
		end
		
		self.hover = true
		
		for k,v in pairs(parent:GetItems()) do
			if v == self then continue end
			v:OnCursorExited()
		end
	end
	buton.OnCursorExited = function(self)
		self.hover = false
	end

	
	parent:AddItem(buton)
	
	return buton
	
end