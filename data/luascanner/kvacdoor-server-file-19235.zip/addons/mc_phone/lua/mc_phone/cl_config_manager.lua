-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING

local ply = LocalPlayer()

local LocalCFG

local matBlurScreen = Material( "pp/blurscreen" )

local function MCDrawBackgroundBlur( panel )

	panel.Atime = Lerp( FrameTime() * 5, panel.Atime, 1 )

	local x, y = panel:LocalToScreen( 0, 0 )
	
	DisableClipping( true )
	
	surface.SetDrawColor( McPhone.UserCfg.Theme["buttons"].r, McPhone.UserCfg.Theme["buttons"].g, McPhone.UserCfg.Theme["buttons"].b, 25 * panel.Atime )
	surface.DrawRect( x * -1, y * -1, ScrW(), ScrH() )
	
	if ( !MENU_DLL ) then
		surface.SetMaterial( matBlurScreen )
		surface.SetDrawColor( 255, 255, 255, 255 )

		for i=0.33, 1, 0.33 do
			matBlurScreen:SetFloat( "$blur", panel.Atime * 5 * i )
			matBlurScreen:Recompute()
			if ( render ) then render.UpdateScreenEffectTexture() end -- Todo: Make this available to menu Lua
			surface.DrawTexturedRect( x * -1, y * -1, ScrW(), ScrH() )
		end
	end

	surface.SetDrawColor( 0, 0, 0, 200 * panel.Atime )
	surface.DrawRect( x * -1, y * -1, ScrW(), ScrH() )

	DisableClipping( false )

end

local function McUpperButton(parent, text, func, hovered)

	local buton = vgui.Create("DButton")
	buton:SetSize( 300, 50 )
	buton:SetText("")
	if hovered then
		self.hovered = hovered
	end
	buton.DoClick = function(self)
		func(self)
	end
	buton.Paint = function(self, w, h)
		draw.RoundedBox(0,0,3,w,h-3,Color(0,0,0,200))
		
		if self.hover or self.hovered then
			draw.RoundedBox(0,0,0,w,3,McPhone.UserCfg.Theme["buttons"])
			draw.RoundedBox(0,0,3,w,h-3,Color(255,255,255,200))
			draw.SimpleText( string.upper(text), "McPhone.Main28", w/2, 12, color_black, TEXT_ALIGN_CENTER)
		else
			draw.SimpleText( string.upper(text), "McPhone.Main28", w/2, 12, color_white, TEXT_ALIGN_CENTER)
		end
		
		
	end
	buton.OnCursorEntered = function(self) self.hover = true end
	buton.OnCursorExited = function(self) self.hover = false end
	parent:AddItem(buton)
	
	return buton
	
end

local function McTButton(parent, text, func)
	local button = vgui.Create("DButton")
	button:SetSize( 300, 50 )
	button:SetText("")
	button.Paint = function(self, w, h)
		draw.RoundedBox(0,0,3,w,h-3,Color(0,0,0,200))
		
		if self.hover then
			draw.RoundedBox(0,0,3,w,h-3,Color(255,255,255,200))
			draw.SimpleText( text, "McPhone.Main28", 10, 12, color_black, TEXT_ALIGN_LEFT)
		else
			draw.SimpleText( text, "McPhone.Main28", 10, 12, color_white, TEXT_ALIGN_LEFT)
		end
	end
	button.DoClick = function(self)
		func(self)
	end
	button.OnCursorEntered = function(self) self.hover = true end
	button.OnCursorExited = function(self) self.hover = false end
	parent:AddItem(button)
end

local function McTextPanel(parent, text, etc)
	local panel = vgui.Create("DPanel")
	panel:SetSize( 300, 50 )
	panel.Paint = function(self, w, h)
		draw.RoundedBox(0,0,3,w,h-3,Color(0,0,0,200))
		
		if etc then
			draw.SimpleText( text, "McPhone.Main28", 10, 5, color_white, TEXT_ALIGN_LEFT)
			draw.SimpleText( etc, "McPhone.Main22", 12, 30, Color(255,0,0,255), TEXT_ALIGN_LEFT)
		else
			draw.SimpleText( text, "McPhone.Main28", 10, 12, color_white, TEXT_ALIGN_LEFT)
		end
	end

	parent:AddItem(panel)
end

local function McBinder(parent, text, var, func)
	
	local binder = vgui.Create( "DBinder" )
	binder:SetSize( 200, 50 )
	binder:SetValue( var )
	binder.Paint = function(self, w, h)
	
		draw.RoundedBox(0,0,0,w-w/4-5,h,Color(0,0,0,200))
		draw.RoundedBox(0,w-w/4,0,w/4,h,Color(0,0,0,200))
		
		if self.hover or self.Trapping then
			draw.RoundedBox(0,0,0,w-w/4-5,h,Color(255,255,255,200))
			draw.SimpleText( text, "McPhone.Main28", 10, 12, color_black, TEXT_ALIGN_LEFT)
		else
			draw.SimpleText( text, "McPhone.Main28", 10, 12, color_white, TEXT_ALIGN_LEFT)
		end
		
		if self.Trapping then
			draw.RoundedBox(0,w-w/4,0,w/4,h,Color(255,255,255,200))
			draw.SimpleText( binder:GetText(), "McPhone.Main28", w-w/8, 12, McPhone.UserCfg.Theme["buttons"], TEXT_ALIGN_CENTER)
		else
			draw.SimpleText( binder:GetText(), "McPhone.Main28", w-w/8, 12, color_white, TEXT_ALIGN_CENTER)
			
		end
		
		return true
	end
	binder.OnCursorEntered = function(self) self.hover = true end
	binder.OnCursorExited = function(self) self.hover = false end
	
	function binder:OnChange( num )
		if num > 106 and num < 114 then
			binder:SetValue( var )
		else
			func(num)
		end
	end
	
	parent:AddItem(binder)
end

local function McButton(parent, text, var, func)
	
	local status
	
	local button = vgui.Create( "DButton" )
	button:SetSize( 200, 50 )
	button:SetText( "" )
	button.Paint = function(self, w, h)
		
		if var then
			status = McPhone.GetPhrase("on")
		else
			status = McPhone.GetPhrase("off")
		end
		
		draw.RoundedBox(0,0,0,w-w/4-5,h,Color(0,0,0,200))
		draw.RoundedBox(0,w-w/4,0,w/4,h,Color(0,0,0,200))
		
		if self.hover then
			draw.RoundedBox(0,w-w/4,0,w/4,h,Color(255,255,255,200))
			draw.RoundedBox(0,0,0,w-w/4-5,h,Color(255,255,255,200))
			draw.SimpleText( text, "McPhone.Main28", 10, 12, color_black, TEXT_ALIGN_LEFT)
			draw.SimpleText( status, "McPhone.Main28", w-w/8, 12, McPhone.UserCfg.Theme["buttons"], TEXT_ALIGN_CENTER)
		else
			draw.SimpleText( status, "McPhone.Main28", w-w/8, 12, color_white, TEXT_ALIGN_CENTER)
			draw.SimpleText( text, "McPhone.Main28", 10, 12, color_white, TEXT_ALIGN_LEFT)
		end
		
		return true
	end
	button.OnCursorEntered = function(self) self.hover = true end
	button.OnCursorExited = function(self) self.hover = false end
	function button:DoClick()
		var = !var
		func(var)
	end
	
	parent:AddItem(button)
end

local function Sets_TextBox(name, upd)
	
	local menu = vgui.Create( "DFrame" )
	menu:SetSize( 550, 150 )
	menu:Center()
	menu:SetDraggable( false )
	menu:ShowCloseButton( false )
	menu:SetTitle( "" )
	menu:MakePopup()
	menu.Alpha = 0
	menu.Paint = function(self, w, h)
		Derma_DrawBackgroundBlur( self )
	
		draw.RoundedBox(0,0,0,w,h,Color(0,0,0,200))
		
		if self.hover then
			draw.SimpleText( McPhone.GetPhrase("sets_gps_set_name"), "McPhone.Main28", 5, 12, color_black, TEXT_ALIGN_LEFT)
		else
			draw.SimpleText( McPhone.GetPhrase("sets_gps_set_name"), "McPhone.Main28", 5, 12, color_white, TEXT_ALIGN_LEFT)
		end
	end
	
	local cb = vgui.Create("DButton", menu)
	cb:SetSize( 75, 25 )
	cb:SetPos( menu:GetWide()-100, 25 )
	cb:SetText( "" )	
	cb.Paint = function(self, w, h)
		if self.hover then
			draw.SimpleText( McPhone.GetPhrase("close"), "McPhone.Main28", 5, 0, McPhone.UserCfg.Theme["buttons"], TEXT_ALIGN_LEFT)
		else
			draw.SimpleText( McPhone.GetPhrase("close"), "McPhone.Main28", 5, 0, color_white, TEXT_ALIGN_LEFT)
		end
	end
	cb.DoClick = function()
		menu:Close()
	end
	cb.OnCursorEntered = function(self) self.hover = true end
	cb.OnCursorExited = function(self) self.hover = false end
	
	local drme = vgui.Create("DTextEntry",menu)
	drme:SetText("")
	drme:SetFont("McPhone.Main28")
	drme:SetValue(name)
	drme:SetMultiline(false)
	drme:SetSize( menu:GetWide()-50, 25 )
	drme:SetPos( 25, 60 )
	drme:RequestFocus()
	drme.Paint = function( self, w, h )
		self:DrawTextEntryText(color_white, McPhone.UserCfg.Theme["buttons"], color_white)
	end
	drme.OnEnter = function( self )
		menu:Close()
		if name != drme:GetValue() then
			LocalCFG.GPSList[game.GetMap()][drme:GetValue()] = LocalCFG.GPSList[game.GetMap()][name]
			LocalCFG.GPSList[game.GetMap()][name] = nil
		end
		upd()
	end
	
	local cb = vgui.Create("DButton", menu)
	cb:SetSize( 75, 25 )
	cb:SetPos( menu:GetWide()-100, menu:GetTall()-50 )
	cb:SetText( "" )	
	cb.Paint = function(self, w, h)
		if self.hover then
			draw.SimpleText( "OK", "McPhone.Main28", 5, 0, McPhone.UserCfg.Theme["buttons"], TEXT_ALIGN_LEFT)
		else
			draw.SimpleText( "OK", "McPhone.Main28", 5, 0, color_white, TEXT_ALIGN_LEFT)
		end
	end
	cb.DoClick = function()
		menu:Close()
		if name != drme:GetValue() then
			LocalCFG.GPSList[game.GetMap()][drme:GetValue()] = LocalCFG.GPSList[game.GetMap()][name]
			LocalCFG.GPSList[game.GetMap()][name] = nil
		end
		upd()
	end
	cb.OnCursorEntered = function(self) self.hover = true end
	cb.OnCursorExited = function(self) self.hover = false end
	
end

local function Normal_TextBox(name, text, upd)
	
	local menu = vgui.Create( "DFrame" )
	menu:SetSize( 550, 150 )
	menu:Center()
	menu:SetDraggable( false )
	menu:ShowCloseButton( false )
	menu:SetTitle( "" )
	menu:MakePopup()
	menu.Alpha = 0
	menu.Paint = function(self, w, h)
		Derma_DrawBackgroundBlur( self )
	
		draw.RoundedBox(0,0,0,w,h,Color(0,0,0,200))
		
		if self.hover then
			draw.SimpleText( name, "McPhone.Main28", 5, 12, color_black, TEXT_ALIGN_LEFT)
		else
			draw.SimpleText( name, "McPhone.Main28", 5, 12, color_white, TEXT_ALIGN_LEFT)
		end
	end
	
	local cb = vgui.Create("DButton", menu)
	cb:SetSize( 75, 25 )
	cb:SetPos( menu:GetWide()-100, 25 )
	cb:SetText( "" )	
	cb.Paint = function(self, w, h)
		if self.hover then
			draw.SimpleText( McPhone.GetPhrase("close"), "McPhone.Main28", 5, 0, McPhone.UserCfg.Theme["buttons"], TEXT_ALIGN_LEFT)
		else
			draw.SimpleText( McPhone.GetPhrase("close"), "McPhone.Main28", 5, 0, color_white, TEXT_ALIGN_LEFT)
		end
	end
	cb.DoClick = function()
		menu:Close()
	end
	cb.OnCursorEntered = function(self) self.hover = true end
	cb.OnCursorExited = function(self) self.hover = false end
	
	local drme = vgui.Create("DTextEntry",menu)
	drme:SetText("")
	drme:SetFont("McPhone.Main28")
	drme:SetValue(text)
	drme:SetMultiline(false)
	drme:SetSize( menu:GetWide()-50, 25 )
	drme:SetPos( 25, 60 )
	drme:RequestFocus()
	drme.Paint = function( self, w, h )
		self:DrawTextEntryText(color_white, McPhone.UserCfg.Theme["buttons"], color_white)
	end
	drme.OnEnter = function( self )
		menu:Close()
		upd(drme:GetValue())
	end
	
	local cb = vgui.Create("DButton", menu)
	cb:SetSize( 75, 25 )
	cb:SetPos( menu:GetWide()-100, menu:GetTall()-50 )
	cb:SetText( "" )	
	cb.Paint = function(self, w, h)
		if self.hover then
			draw.SimpleText( "OK", "McPhone.Main28", 5, 0, McPhone.UserCfg.Theme["buttons"], TEXT_ALIGN_LEFT)
		else
			draw.SimpleText( "OK", "McPhone.Main28", 5, 0, color_white, TEXT_ALIGN_LEFT)
		end
	end
	cb.DoClick = function()
		menu:Close()
		upd(drme:GetValue())
	end
	cb.OnCursorEntered = function(self) self.hover = true end
	cb.OnCursorExited = function(self) self.hover = false end
	
end

local function McButtonGPS(parent, gps, x, upd)
	
	local panel = vgui.Create("DPanel")
	panel:SetSize( x, 50 )
	panel.Paint = function(self, w, h)
		draw.RoundedBox(0,0,0,w-(w/6)*3-15,h,Color(0,0,0,200))

		draw.SimpleText( gps, "McPhone.Main28", 10, 12, color_white, TEXT_ALIGN_LEFT)
	end
	
	local button = vgui.Create( "DButton", panel )
	button:SetSize( panel:GetWide()/6, 50 )
	button:SetPos( panel:GetWide()-(panel:GetWide()/6)*3-10, 0 )
	button:SetText( "" )
	button.Paint = function(self, w, h)

		draw.RoundedBox(0,0,0,w,h,Color(0,0,0,200))
		
		if self.hover then
			draw.RoundedBox(0,0,0,w,h,Color(255,255,255,200))
			draw.SimpleText( McPhone.GetPhrase("sets_gps_set_name"), "McPhone.Main28", w/2, 12, color_black, TEXT_ALIGN_CENTER)
		else
			draw.SimpleText( McPhone.GetPhrase("sets_gps_set_name"), "McPhone.Main28", w/2, 12, color_white, TEXT_ALIGN_CENTER)
		end
		
		return true
	end
	button.OnCursorEntered = function(self) self.hover = true end
	button.OnCursorExited = function(self) self.hover = false end
	function button:DoClick()
		Sets_TextBox(gps, upd)
	end
	
	local button = vgui.Create( "DButton", panel )
	button:SetSize( panel:GetWide()/6, 50 )
	button:SetPos( panel:GetWide()-(panel:GetWide()/6)*2-5, 0 )
	button:SetText( "" )
	button.Paint = function(self, w, h)

		draw.RoundedBox(0,0,0,w,h,Color(0,0,0,200))
		
		if self.hover then
			draw.RoundedBox(0,0,0,w,h,Color(255,255,255,200))
			draw.SimpleText( McPhone.GetPhrase("sets_gps_upd"), "McPhone.Main28", w/2, 12, color_black, TEXT_ALIGN_CENTER)
		else
			draw.SimpleText( McPhone.GetPhrase("sets_gps_upd"), "McPhone.Main28", w/2, 12, color_white, TEXT_ALIGN_CENTER)
		end
		
		return true
	end
	button.OnCursorEntered = function(self) self.hover = true end
	button.OnCursorExited = function(self) self.hover = false end
	function button:DoClick()
		LocalCFG.GPSList[game.GetMap()][gps] = ply:GetPos()
		upd()
	end
	
	local button = vgui.Create( "DButton", panel )
	button:SetSize( panel:GetWide()/6, 50 )
	button:SetPos( panel:GetWide()-(panel:GetWide()/6), 0 )
	button:SetText( "" )
	button.Paint = function(self, w, h)

		draw.RoundedBox(0,0,0,w,h,Color(0,0,0,200))
		
		if self.hover then
			draw.RoundedBox(0,0,0,w,h,Color(255,255,255,200))
			draw.SimpleText( McPhone.GetPhrase("sets_gps_rmv"), "McPhone.Main28", w/2, 12, color_black, TEXT_ALIGN_CENTER)
		else
			draw.SimpleText( McPhone.GetPhrase("sets_gps_rmv"), "McPhone.Main28", w/2, 12, color_white, TEXT_ALIGN_CENTER)
		end
		
		return true
	end
	button.OnCursorEntered = function(self) self.hover = true end
	button.OnCursorExited = function(self) self.hover = false end
	function button:DoClick()
		LocalCFG.GPSList[game.GetMap()][gps] = nil
		upd()
	end
	
	parent:AddItem(panel)
end

function McPhone.OpenConfigManager()
	
	local sW, sH = ScrW(), ScrH()
	
	local frame = vgui.Create("DFrame")
	frame:SetSize(sW-sW/8,sH-sH/6)
	frame:Center()
	frame:SetTitle("")
	frame:SetDraggable(false)
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame.Atime = 0
	frame.Paint = function(self,w,h)
		MCDrawBackgroundBlur( self )
		draw.SimpleTextOutlined( "McPhone", "McPhone.Main38", 0, 0, color_white, TEXT_ALIGN_LEFT, 0, 1, color_black)
	end
	
	local x, y = frame:GetWide(), frame:GetTall()
	
	local f_list = vgui.Create("DPanelList", frame )
	f_list:SetPos( 0, 40 )
	f_list:SetSize( x, 50 )
	f_list:EnableHorizontal( true )
	f_list:EnableVerticalScrollbar( false )
	f_list:SetSpacing(2)
	f_list.Paint = function() end
	f_list.VBar.Paint = function() end
	f_list.VBar.btnUp.Paint = function() end
	f_list.VBar.btnDown.Paint = function() end
	f_list.VBar.btnGrip.Paint = function() end
	
	local sets_m, open_bm, open_sm
	local bind_m = McUpperButton(f_list, McPhone.GetPhrase("key_binds"), function() open_bm() end)
	
	if ply:IsSuperAdmin() then
		sets_m = McUpperButton(f_list, McPhone.GetPhrase("server_setts"), function() open_sm() end)
	end
	
	McUpperButton(f_list, "Close", function() frame:Close() end)
	
	local s_list = vgui.Create("DPanelList", frame )
	s_list:SetPos( 0, 100 )
	s_list:SetSize( x, y-100 )
	s_list:EnableHorizontal( false )
	s_list:EnableVerticalScrollbar( true )
	s_list:SetSpacing(5)
	s_list.Paint = function() end
	s_list.VBar.Paint = function() end
	s_list.VBar.btnUp.Paint = function() end
	s_list.VBar.btnDown.Paint = function() end
	s_list.VBar.btnGrip.Paint = function() end
	
	function open_bm()
		bind_m.hovered = true
		if sets_m then
			sets_m.hovered = false
		end
		s_list:Clear()
		
		local LocalBinds = table.Copy(McPhone.UserCfg.Binds)
		
		if ply:IsSuperAdmin() then
			McTextPanel(s_list, McPhone.GetPhrase("sa_notification"))
		end
		
		local panel = vgui.Create("DPanel")
		panel:SetSize( 300, 175 )
		panel.Paint = function(self, w, h)
			draw.RoundedBox(0,0,3,w,h-3,Color(0,0,0,200))
			McPhone.DrawTexturedRect(w-500,0,500,174,"mc_phone/icons/binds.png",color_white)
			draw.SimpleText( McPhone.GetPhrase("sets_mkb"), "McPhone.Main28", 10, 10, color_white, TEXT_ALIGN_LEFT)
			draw.SimpleText( McPhone.GetPhrase("sets_lmb"), "McPhone.Main28", 10, 40, color_white, TEXT_ALIGN_LEFT)
			draw.SimpleText( McPhone.GetPhrase("sets_rmb"), "McPhone.Main28", 10, 70, color_white, TEXT_ALIGN_LEFT)
			draw.SimpleText( McPhone.GetPhrase("sets_mmb"), "McPhone.Main28", 10, 100, color_white, TEXT_ALIGN_LEFT)
			draw.SimpleText( McPhone.GetPhrase("sets_wscr"), "McPhone.Main28", 10, 130, color_white, TEXT_ALIGN_LEFT)
		end

		s_list:AddItem(panel)
		
		McButton(s_list, McPhone.GetPhrase("sets_umb"), McPhone.UserCfg.UseMouse, function(var) McPhone.UserCfg.UseMouse = var end)
		McButton(s_list, McPhone.GetPhrase("sets_popup"), McPhone.UserCfg.PopUp, function(var) McPhone.UserCfg.PopUp = var end)
		
		McTextPanel(s_list, McPhone.GetPhrase("ui_binds"))
		
		McBinder(s_list, McPhone.GetPhrase("sets_kupb"), LocalBinds.up, function(num) LocalBinds.up = num end)
		McBinder(s_list, McPhone.GetPhrase("sets_kdwnb"), LocalBinds.down, function(num) LocalBinds.down = num end)
		McBinder(s_list, McPhone.GetPhrase("sets_klfb"), LocalBinds.left, function(num) LocalBinds.left = num end)
		McBinder(s_list, McPhone.GetPhrase("sets_krtb"), LocalBinds.right, function(num) LocalBinds.right = num end)
		McBinder(s_list, McPhone.GetPhrase("sets_kcls"), LocalBinds.close, function(num) LocalBinds.close = num end)
		McBinder(s_list, McPhone.GetPhrase("sets_kbkb"), LocalBinds.back, function(num) LocalBinds.back = num end)
		McBinder(s_list, McPhone.GetPhrase("sets_kent"), LocalBinds.click, function(num) LocalBinds.click = num end)
		McBinder(s_list, McPhone.GetPhrase("sets_kopt"), LocalBinds.click2, function(num) LocalBinds.click2 = num end)
		
		McTButton(s_list, McPhone.GetPhrase("sets_reset"), function() McPhone.UserCfg.Binds = McPhone.Binds McPhone.SaveUserConfig() frame:Close() end)
		McTButton(s_list, McPhone.GetPhrase("sets_save"), function() McPhone.UserCfg.Binds = LocalBinds McPhone.SaveUserConfig() frame:Close() end)
	end
	
	function open_sm()
		bind_m.hovered = false
		sets_m.hovered = true
		
		local sm_main, sm_gps
		
		LocalCFG = table.Copy(McPhone.Config)
		
		function sm_main()
			s_list:Clear()
			McTButton(s_list, McPhone.GetPhrase("sets_manage_gps") , function() sm_gps() end)
			McTButton(s_list, "Language: "..McPhone.GetPhrase("lang_name"), function()
				local Menu = DermaMenu()
				
				for k,v in pairs(McPhone.Language) do
					Menu:AddOption(v.lang_name, function() 
						LocalCFG.Language = k
						McPhone.Config = LocalCFG McPhone.SaveConfig() frame:Close()
						McPhone.ModuleLoader()
					end)
				end
				
				Menu:Open()
				
			end)
			
			McButton(s_list, McPhone.GetPhrase("GlobalContacts"), LocalCFG.GlobalContacts, function(var) LocalCFG.GlobalContacts = var end)
			
			McButton(s_list, McPhone.GetPhrase("DarkRPLog"), LocalCFG.DarkRPLog, function(var) LocalCFG.DarkRPLog = var end)
			
			McButton(s_list, McPhone.GetPhrase("Draw3DModel"), LocalCFG.Draw3DModel, function(var) LocalCFG.Draw3DModel = var end)
			
			if GetGlobalInt("McPhone.AtmosTime", 0) > 0 then
				McButton(s_list, McPhone.GetPhrase("AtmosTime"), LocalCFG.AtmosTime, function(var) LocalCFG.AtmosTime = var end)
			end
			
			if StormFox then
				McButton(s_list, McPhone.GetPhrase("StormFoxTime"), LocalCFG.StormFoxTime, function(var) LocalCFG.StormFoxTime = var end)
			end
			
			McButton(s_list, McPhone.GetPhrase("EmailFee"), LocalCFG.EmailFee, function(var) LocalCFG.EmailFee = var end)
			
			McTButton(s_list, McPhone.GetPhrase("EmailFeeSize")..": "..LocalCFG.EmailFeeSize , function() Normal_TextBox("Enter numbers only", LocalCFG.EmailFeeSize, function(var) if isnumber(tonumber(var)) then LocalCFG.EmailFeeSize = var sm_main() end end) end)

			McTButton(s_list, McPhone.GetPhrase("CameraWaterMark")..": "..LocalCFG.CameraWaterMark , function() Normal_TextBox("Watermark", LocalCFG.CameraWaterMark, function(var) LocalCFG.CameraWaterMark = var sm_main() end) end)
			
			McTButton(s_list,  McPhone.GetPhrase("ServerCurensy")..": "..LocalCFG.Curensy , function() Normal_TextBox("Currency", LocalCFG.Curensy, function(var) LocalCFG.Curensy = var sm_main() end) end)
			
			McTButton(s_list, McPhone.GetPhrase("sets_save") , function() McPhone.Config = LocalCFG McPhone.SaveConfig() frame:Close() end)
		end
		
		function sm_gps()
			s_list:Clear()
			
			McTextPanel(s_list, McPhone.GetPhrase("sets_gps_info"))
			
			McTButton(s_list, McPhone.GetPhrase("go_back") , function() sm_main() end)
			McTButton(s_list, McPhone.GetPhrase("sets_new_gps") , function() 
			
				if !LocalCFG.GPSList[game.GetMap()] then
					LocalCFG.GPSList[game.GetMap()] = {}
				end
				
				LocalCFG.GPSList[game.GetMap()]["New marker"] = ply:GetPos()
				
				sm_gps()
				
			end)

			if LocalCFG.GPSList[game.GetMap()] then
				for k,v in pairs( LocalCFG.GPSList[game.GetMap()]) do
					McButtonGPS(s_list, k, x, function() sm_gps() end)
				end
				
				McTButton(s_list, McPhone.GetPhrase("sets_save") , function() McPhone.Config = LocalCFG McPhone.SaveConfig() frame:Close() end)
				
			end
			
			
		
		end
		
		sm_main()
	end
	
	open_bm()
end