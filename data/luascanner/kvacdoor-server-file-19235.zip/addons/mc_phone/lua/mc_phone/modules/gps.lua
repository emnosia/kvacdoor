-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

local module_id = 3

McPhone.Modules[module_id] = {}

McPhone.Modules[module_id].name = McPhone.GetPhrase("GPS")

McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/gps.png"

McPhone.Modules[module_id].openMenu = function()
		
	if !McPhone.UI or !McPhone.UI.Menu then return end
	
	local m_list, m_active
	
	function m_list()
		
		McPhone.UI.Menu:Clear()
		McPhone.UI.Menu:SetPos( 20, 140 )
		McPhone.UI.Menu:SetSize( 270, 256 )
		McPhone.UI.Menu.List = true
		McPhone.UI.Menu:EnableHorizontal( true )
		
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("GPS")
		
		if McPhone.Config.GPSList[game.GetMap()] then
			for k,v in SortedPairs( McPhone.Config.GPSList[game.GetMap()], false) do
				McPhone.ListTexts(McPhone.UI.Menu, nil, k, "", "", false, function() McPhone.ToggleGPS(k, v) McPhone.GPSMenuRebuild = function() m_list() end m_active() end, false, true)
			end
		end
		McPhone.UI.Buttons.Left = {nil,nil, nil}
		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id4.png",McPhone.McPhone.Colors["green"], nil}
		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png",McPhone.McPhone.Colors["red"], nil}
		
	end
	
	function m_active()
		McPhone.UI.Menu:Clear()
		McPhone.UI.Menu:SetPos( 20, 140 )
		McPhone.UI.Menu:SetSize( 270, 256 )
		McPhone.UI.Menu.List = true
		McPhone.UI.Menu:EnableHorizontal( true )
		
		McPhone.UI.OpenedMenu = McPhone.IsGPSOn
		
		McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/buttons/id15.png",  McPhone.GetPhrase("stop_gps"), false, function()
			McPhone.ToggleGPS()
		end, true)
		
	end
	
	if McPhone.IsGPSOn then
		m_active()
	else
		m_list()
	end
	
end