-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

local module_id = 6

McPhone.Modules[module_id] = {}

McPhone.Modules[module_id].name = McPhone.GetPhrase("settings")

McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/sets.png"

McPhone.Modules[module_id].openMenu = function()
		
	if !McPhone.UI or !McPhone.UI.Menu then return end
	
	local back = McPhone.UI.GoBack
	
	McPhone.UI.Menu:Clear()
	McPhone.UI.Menu:SetPos( 20, 140 )
	McPhone.UI.Menu:SetSize( 270, 256 )
	McPhone.UI.Menu.List = true
	McPhone.UI.Menu:EnableHorizontal( true )
	
	local m_sets, m_themes, m_bgs, m_profile, m_tones
	
	local function UpdatePanels(panel)
		panel.check = true
		for _,p in pairs(McPhone.UI.Menu:GetItems()) do
			if p == panel or !p.check then continue end
			p.check = false
		end
	end
	
	function m_sets()
		McPhone.UI.Menu:Clear()
		McPhone.StopSound()
		
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("settings")
		
		McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/settings/id_5.png", McPhone.GetPhrase("background"), false, function() 
			m_bgs() 
			McPhone.UI.GoBack = m_sets 
		end)
		McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/settings/id_3.png", McPhone.GetPhrase("profile"), false, function() 
			m_profile() 
			McPhone.UI.GoBack = m_sets 
		end)
		McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/settings/id_1.png", McPhone.GetPhrase("ringtone"), false,function() 
			m_tones() 
			McPhone.UI.GoBack = m_sets 
		end)
		McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/settings/id_5.png", McPhone.GetPhrase("theme"), false, function() 
			m_themes() 
			McPhone.UI.GoBack = m_sets 
		end)
		McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/settings/id_11.png", McPhone.GetPhrase("advanced"), false, function() 
			McPhone.ClosePhone()
			McPhone.OpenConfigManager()
		end)
		McPhone.UI.GoBack = back
	end
	
	function m_themes()
		McPhone.UI.Menu:Clear()
		
		for name,theme in SortedPairs(McPhone.McPhone.Themes) do
			
			McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/settings/id_5.png", McPhone.GetPhrase("Theme "..name), McPhone.UserCfg.Theme == theme or false, 
			function(self)
				McPhone.UserCfg.Theme = theme
				McPhone.UserCfg.Profile.PhoneColor = theme["phone"]
				McPhone.UserCfg.WallPaper = McPhone.McPhone.WallPapers[theme["def_wp"]]
				UpdatePanels(self)
				McPhone.SaveUserConfig()
			end, 
			true, nil, true)
		end
	end
	
	function m_bgs()
		McPhone.UI.Menu:Clear()
		
		for name,bg in SortedPairs(McPhone.McPhone.WallPapers) do
			McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/settings/id_5.png",  McPhone.GetPhrase(name), McPhone.UserCfg.WallPaper == bg or false, 
			function(self)
				McPhone.UserCfg.WallPaper = bg
				UpdatePanels(self)
				McPhone.SaveUserConfig()
			end, 
			true, nil, true)
		end
	end
	
	function m_tones()
		McPhone.UI.Menu:Clear()
		
		for name,tone in SortedPairs(McPhone.McPhone.Ringtone) do
			
			local icon = "mc_phone/icons/settings/id_6.png"
			
			if !tone then
				icon = "mc_phone/icons/settings/id_7.png"
			end
			
			local t_name = McPhone.GetPhrase("ringtone").." "..name
			
			if name == "Silent" then
				t_name = McPhone.GetPhrase("silent")
			end
			
			McPhone.ListIcons(McPhone.UI.Menu, icon, t_name, McPhone.UserCfg.Profile.Ringtone == tone or false, 
			function(self)
				McPhone.UserCfg.Profile.Ringtone = tone
				UpdatePanels(self)
				McPhone.SaveUserConfig()
			end, 
			true, tone and "mc_phone/ring/"..tone..".wav" or "stop", true)
		end
		
	end
	
	function m_profile()
		McPhone.UI.Menu:Clear()
		
		McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/settings/id_3.png", McPhone.GetPhrase("normal_mode"), !McPhone.UserCfg.Profile.Sleep,  function(self) 
			McPhone.UserCfg.Profile.Sleep = false
			UpdatePanels(self)
			McPhone.SaveUserConfig()
		end, true, nil, true)
		McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/settings/id_4.png", McPhone.GetPhrase("sleep_mode"), McPhone.UserCfg.Profile.Sleep,  function(self) 
			McPhone.UserCfg.Profile.Sleep = true
			UpdatePanels(self)
			McPhone.SaveUserConfig()
		end, true, nil, true)
		
	end
	
	m_sets()
	
end