-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

local module_id = 0

McPhone.Modules[module_id] = {}

McPhone.Modules[module_id].name = "Advert"

McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/task.png"

McPhone.Modules[module_id].number = 0

McPhone.Mail = {}
-- Save resent email as local varibles

local e_topic, e_text = "", ""

McPhone.Modules[module_id].openMenu = function()
	
	local ply = LocalPlayer()
	
	if !McPhone.UI or !McPhone.UI.Menu then return end
	
	local back = McPhone.UI.GoBack
	
	local m_list, m_send, m_reed, m_sendmail, m_feescr
	
	function m_list()
		McPhone.UI.Menu:Clear()
		McPhone.UI.Menu:SetPos( 20, 140 )
		McPhone.UI.Menu:SetSize( 270, 256 )
		McPhone.UI.Menu.List = true
		McPhone.UI.Menu:EnableHorizontal( true )
		
		McPhone.UI.OpenedMenu = "Advert"
		
		for k,v in SortedPairs(McPhone.Mail, true) do
			McPhone.ListTexts(McPhone.UI.Menu, k, v.Name, v.Text, v.Time, false, function() McPhone.UI.GoBack = function() m_list() end m_reed(v.Name, v.Text, k) end, true, true)
		end
		
		McPhone.UI.Buttons.Left = {"mc_phone/icons/buttons/id5.png",McPhone.McPhone.Colors["blue"], function() m_send() McPhone.UI.GoBack = function() m_list() end end}
		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id4.png",McPhone.McPhone.Colors["green"], nil}
		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png",McPhone.McPhone.Colors["red"], nil}
		
		McPhone.UI.GoBack = back
	end
	
	function m_reed(name, text, email)
		
		McPhone.Mail[email].New = false
		McPhone.UpdateAdvert()
		
		McPhone.UI.Menu:Clear()
		
		McPhone.UI.OpenedMenu = name
		
		local drme = vgui.Create("DTextEntry")
		drme:SetText("")
		drme:SetFont("McPhone.Main28")
		drme:SetMultiline(true)
		drme:SetValue(text)
		drme:SetDisabled( true )
		drme:SetSize( 256, 256 )
		drme.Paint = function( self, w, h )
			self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
		end
		
		McPhone.UI.Menu:AddItem(drme)
		
		
		McPhone.UI.Buttons.Left = {"mc_phone/icons/buttons/id13.png",McPhone.McPhone.Colors["blue"], function() table.remove( McPhone.Mail, email ) McPhone.UpdateAdvert() McPhone.UI.GoBack()  end}
		McPhone.UI.Buttons.Middle = {nil,nil, nil}
		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png",McPhone.McPhone.Colors["red"], nil}
		
	end
	
	function m_send()
		McPhone.UI.Menu:Clear()
		
		e_topic = ply:Name()
		
		McPhone.UI.OpenedMenu = e_topic
		
		local frame = vgui.Create( "DPanel" )
		frame:SetSize( 256, 256 )
		frame:SetDisabled( true )
		frame.Chasher = true
		
		McPhone.UI.Menu:AddItem(frame)
		
		local x, y = frame:LocalToScreen(0, 0)
		
		local panel = vgui.Create( "DFrame" )
		panel:SetPos( x, y )
		panel:SetSize( 256, 256 )
		panel:SetTitle( "" )
		panel:SetDraggable( false )
		panel:ShowCloseButton( false )
		panel:MakePopup()
		panel.Paint = function() end
		panel.Think = function()
			if !McPhone.UI or !McPhone.UI.Menu:GetItems()[1] or !McPhone.UI.Menu:GetItems()[1].Chasher then
				panel:Remove()
			end
			if x < 1 then
				x, y = frame:LocalToScreen(0, 0)
				panel:SetPos( x, y )
			end
		end
		
		local drme = vgui.Create("DTextEntry",panel)
		drme:SetText("")
		drme:SetFont("McPhone.Main28")
		drme:SetValue(e_text)
		drme:SetMultiline(true)
		drme:SetSize( 256, 256 )
		drme:SetPos( 0, 0 )
		drme:RequestFocus()
		drme.Paint = function( self, w, h )
			self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
		end
		
		McPhone.UI.Buttons.Left = {nil,nil,nil}
		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id5.png",McPhone.McPhone.Colors["green"], function()
			if drme:GetValue() != "" then
				e_text = drme:GetValue()
				if McPhone.Config.EmailFee then
					m_feescr()
					McPhone.UI.GoBack = back
				else
					m_sendmail()
				end
			end
		end}
		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png",McPhone.McPhone.Colors["red"], nil}
	end
	
	function m_feescr()
		McPhone.UI.Menu:Clear()
		
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("email_last")
		
		local drme = vgui.Create("DTextEntry")
		drme:SetText("")
		drme:SetFont("McPhone.Main28")
		drme:SetMultiline(true)
		drme:SetValue(McPhone.GetPhrase("email_fee", McPhone.Config.EmailFeeSize, McPhone.Config.Curensy))
		drme:SetDisabled( true )
		drme:SetSize( 256, 256 )
		drme.Paint = function( self, w, h )
			self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
		end
		
		McPhone.UI.Menu:AddItem(drme)
		
		McPhone.UI.Buttons.Left = {nil,nil,nil}
		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id1.png",McPhone.McPhone.Colors["green"], function()
			m_sendmail()
		end}
		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png",McPhone.McPhone.Colors["red"], nil}
	end
	
	function m_sendmail()
		net.Start("McPhone.SendAdvert")
			net.WriteString(e_topic)
			net.WriteString(e_text)
		net.SendToServer()
		McPhone.UI.GoBack = nil
		back()
	end
	
	m_list()
	
end

if SERVER then
	util.AddNetworkString("McPhone.SendAdvert")
	
	net.Receive("McPhone.SendAdvert", function(l, ply)
		
		if McPhone.Config.EmailFee then
			if ply:canAfford(McPhone.Config.EmailFeeSize) then
				ply:addMoney(-McPhone.Config.EmailFeeSize)
			else
				McPhone.Notify(ply, McPhone.GetPhrase("email_canceled"), McPhone.GetPhrase("email_notenough"), true)
				return
			end
		end
		
		local topic = net.ReadString()
		local str = net.ReadString()
		
		net.Start("McPhone.SendAdvert")
			net.WriteString(topic)
			net.WriteString(str)
		net.Send(player.GetAll())
		
		if McPhone.Config.DarkRPLog then
			DarkRP.log("[McPhone] "..ply:Nick() .. " (" .. ply:SteamID() .. ") email advert '".. topic .. "': "..str, Color(255, 200, 30))
		end
		
	end)
	
else
	
	net.Receive("McPhone.SendAdvert", function(l)
		local name = net.ReadString()
		local str = net.ReadString()
		
		table.insert(McPhone.Mail, { New = true, Name = name, Text = str, Time = McPhone.GetCurTime()} )
		McPhone.UpdateAdvert()
		McPhone.Notify(name, str, true)
		
		chat.AddText( Color( 255, 155, 0 ), "[Advert] ", name, ": ", Color( 255, 255, 255 ), str )
		
	end)
	
	function McPhone.UpdateAdvert()
		
		local num = 0
		
		for k,v in pairs(McPhone.Mail) do
			if v.New then
				num = num + 1
			end
		end
		
		McPhone.Modules[module_id].number = num
		
		json_table = util.TableToJSON( McPhone.Mail, true )
		
		file.Write("mcphone_user_advert.txt",json_table)

	end

	function McPhone.GetAdvert()
		
		if !file.Exists("mcphone_user_advert.txt","DATA") then
			
			McPhone.UpdateAdvert()
			
		else
		
			local sms = util.JSONToTable(file.Read("mcphone_user_advert.txt","DATA"))
			
			McPhone.Mail = sms
			
		end

	end

	McPhone.GetAdvert()

	
end