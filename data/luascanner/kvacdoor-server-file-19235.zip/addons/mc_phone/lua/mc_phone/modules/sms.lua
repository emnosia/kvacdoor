-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

local module_id = 2

McPhone.Modules[module_id] = {}

McPhone.Modules[module_id].name = McPhone.GetPhrase("texts")

McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/sms.png"

McPhone.Modules[module_id].number = 0

McPhone.SMS = {}

McPhone.Modules[module_id].openMenu = function()
	
	local ply = LocalPlayer()
	
	if !McPhone.UI or !McPhone.UI.Menu then return end
	
	local back = McPhone.UI.GoBack
	
	local m_list, m_numbers, m_send, m_reed
	
	function m_list()
		McPhone.UI.Menu:Clear()
		McPhone.UI.Menu:SetPos( 20, 140 )
		McPhone.UI.Menu:SetSize( 270, 256 )
		McPhone.UI.Menu.List = true
		McPhone.UI.Menu:EnableHorizontal( true )
		
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("texts")
		
		for k,v in SortedPairs(McPhone.SMS, true) do
			McPhone.ListTexts(McPhone.UI.Menu, k, v.Name, v.Text, v.Time, false, function() McPhone.UI.GoBack = function() m_list() end m_reed(v.Name, v.Text, k) end, false, true)
		end
		
		McPhone.UI.Buttons.Left = {"mc_phone/icons/buttons/id5.png",McPhone.McPhone.Colors["blue"], function() m_numbers() McPhone.UI.GoBack = function() m_list() end end}
		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id4.png",McPhone.McPhone.Colors["green"], nil}
		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png",McPhone.McPhone.Colors["red"], nil}
		
		McPhone.UI.GoBack = back
	end
	
	function m_reed(name, text, sms)
		
		McPhone.SMS[sms].New = false
		McPhone.UpdateSMS()
		
		McPhone.UI.Menu:Clear()
		
		McPhone.UI.OpenedMenu = name
		
		local drme = vgui.Create("DTextEntry")
		drme:SetText("")
		drme:SetFont("McPhone.Main28")
		drme:SetMultiline(true)
		drme:SetValue(text)
		drme:SetDisabled( true )
		drme:SetSize( 256, 256 )
		drme.Paint = function( self, w, h )
			self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
		end
		
		McPhone.UI.Menu:AddItem(drme)
		
		
		McPhone.UI.Buttons.Left = {"mc_phone/icons/buttons/id13.png",McPhone.McPhone.Colors["blue"], function() table.remove( McPhone.SMS, sms ) McPhone.UpdateSMS() McPhone.UI.GoBack()  end}
		McPhone.UI.Buttons.Middle = {nil,nil, nil}
		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png",McPhone.McPhone.Colors["red"], nil}
		
	end
	
	function m_numbers()
		McPhone.UI.Menu:Clear()
		
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("texts")
		
		if McPhone.Config.GlobalContacts then
			for k,pl in pairs(player.GetAll()) do
				if ply == pl then continue end
				if pl:IsBot() then continue end
				McPhone.ListIcons(McPhone.UI.Menu, pl, pl:Name(), false, function()
					m_send(pl)
					McPhone.UI.GoBack = function() m_numbers() end
				end)
			end
		else
			
			for k,v in pairs(McPhone.Contacts) do
			
				local pl = McPhone.GetByNumber(k)
				
				if pl and IsValid(pl) then
					if pl:IsBot() then continue end
					McPhone.ListIcons(McPhone.UI.Menu, pl, pl:Name(), false, function()
						m_send(pl)
						McPhone.UI.GoBack = function() m_numbers() end
					end)
				end
				
			end
		end
		McPhone.UI.GoBack = function() m_list() end
		McPhone.UI.Buttons.Left = {nil,nil,nil}
		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id4.png",McPhone.McPhone.Colors["green"], nil}
		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png",McPhone.McPhone.Colors["red"], nil}
	end
	
	function m_send(pl)
		McPhone.UI.Menu:Clear()
		
		McPhone.UI.OpenedMenu = pl:Name()
		
		local frame = vgui.Create( "DPanel" )
		frame:SetSize( 256, 256 )
		frame:SetDisabled( true )
		frame.Chasher = true
		
		McPhone.UI.Menu:AddItem(frame)
		
		local x, y = frame:LocalToScreen(0, 0)
		
		
		local panel = vgui.Create( "DFrame" )
		panel:SetPos( x, y )
		panel:SetSize( 256, 256 )
		panel:SetTitle( "" )
		panel:SetDraggable( false )
		panel:ShowCloseButton( false )
		panel:MakePopup()
		panel.Paint = function() end
		panel.Think = function()
			if !McPhone.UI or !McPhone.UI.Menu:GetItems()[1] or !McPhone.UI.Menu:GetItems()[1].Chasher then
				panel:Remove()
			end
			if x < 1 then
				x, y = frame:LocalToScreen(0, 0)
				panel:SetPos( x, y )
			end
		end
		
		local drme = vgui.Create("DTextEntry",panel)
		drme:SetText("")
		drme:SetFont("McPhone.Main28")
		drme:SetValue("")
		drme:SetMultiline(true)
		drme:SetSize( 256, 256 )
		drme:SetPos( 0, 0 )
		drme:RequestFocus()
		drme.Paint = function( self, w, h )
			self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
		end
		
		McPhone.UI.Buttons.Left = {nil,nil,nil}
		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id5.png",McPhone.McPhone.Colors["green"], function()
			if drme:GetValue() != "" and IsValid(pl) then
				local str = drme:GetValue()
				
				net.Start("McPhone.SendSMS")
					net.WriteEntity(pl)
					net.WriteString(str)
				net.SendToServer()
			end
			McPhone.GoBack()
		end}
		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png",McPhone.McPhone.Colors["red"], nil}
	end
	
	m_list()
	
end

if SERVER then
	util.AddNetworkString("McPhone.SendSMS")
	
	net.Receive("McPhone.SendSMS", function(l, ply)
		
		if ply.McPhoneLastSMS and ply.McPhoneLastSMS + 5 > CurTime() then
			McPhone.Notify(ply, "Spam Alert!", "", false)
			return 
		end
		
		ply.McPhoneLastSMS = CurTime()
		
		local pl = net.ReadEntity()
		local str = net.ReadString()
		
		if IsValid(pl) then
			net.Start("McPhone.SendSMS")
				net.WriteString(str)
				net.WriteString(ply:Name())
			net.Send(pl)
		end
		
		if McPhone.Config.DarkRPLog then
			DarkRP.log("[McPhone] "..ply:Nick() .. " (" .. ply:SteamID() .. ") text to "..pl:Name().. " (" .. pl:SteamID() .."): "..str, Color(255, 200, 30))
		end
		
		hook.Call("McPhone.Hook.SendSMS", nil, ply, pl, str)
		
	end)
	
else
	
	net.Receive("McPhone.SendSMS", function(l)
		local str = net.ReadString()
		local name = net.ReadString()
		
		table.insert(McPhone.SMS, { New = true, Name = name, Text = str, Time = McPhone.GetCurTime()} )
		McPhone.UpdateSMS()
		McPhone.Notify(name, str, true)
	end)
	
	function McPhone.UpdateSMS()
		
		local num = 0
		
		for k,v in pairs(McPhone.SMS) do
			if v.New then
				num = num + 1
			end
		end
		
		McPhone.Modules[module_id].number = num
		
		json_table = util.TableToJSON( McPhone.SMS, true )
		
		file.Write("mcphone_user_sms.txt",json_table)

	end

	function McPhone.GetSMS()
		
		if !file.Exists("mcphone_user_sms.txt","DATA") then
			
			McPhone.UpdateSMS()
			
		else
		
			local sms = util.JSONToTable(file.Read("mcphone_user_sms.txt","DATA"))
			
			McPhone.SMS = sms
			
		end

	end

	McPhone.GetSMS()

	
end