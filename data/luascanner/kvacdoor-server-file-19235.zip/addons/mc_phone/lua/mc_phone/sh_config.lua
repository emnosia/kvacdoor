-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

-- To disable modules you won't use, just change false to true

McPhone.DisableModules = {
	["contacts.lua"] = false,		-- Contacts/call module (not recommended to disable)
	["gps.lua"] = false,			-- GPS module
	["mail.lua"] = false,			-- Email advert module
	["advert.lua"] = true,			-- This module is alternative module for adverts, if you use this on, then disable mail module
	["settings.lua"] = false,		-- Settings module (NOT RECOMMENDED TO DISABLE AT ALL)
	["sms.lua"] = false,			-- SMS module
}


-- ╔══╦════╦════╦═══╦╗─╔╦════╦══╦══╦╗─╔╦╦╦╗
-- ║╔╗╠═╗╔═╩═╗╔═╣╔══╣╚═╝╠═╗╔═╩╗╔╣╔╗║╚═╝║║║║
-- ║╚╝║─║║───║║─║╚══╣╔╗─║─║║──║║║║║║╔╗─║║║║
-- ║╔╗║─║║───║║─║╔══╣║╚╗║─║║──║║║║║║║╚╗╠╩╩╝
-- ║║║║─║║───║║─║╚══╣║─║║─║║─╔╝╚╣╚╝║║─║╠╦╦╗
-- ╚╝╚╝─╚╝───╚╝─╚═══╩╝─╚╝─╚╝─╚══╩══╩╝─╚╩╩╩╝

-- You can edit the config throw the game!!!
-- Just open advanced setting inside your phone

McPhone.LockedConfig = false				-- Locking the config disable ingame configurator menu

McPhone.Config.GlobalContacts = false

McPhone.Config.DarkRPLog = true

McPhone.Config.AtmosTime = false

McPhone.Config.StormFoxTime = false

McPhone.Config.EmailFee = true

McPhone.Config.Draw3DModel = true

McPhone.Config.EmailFeeSize = 10

McPhone.Config.Language = "en"

McPhone.Config.Curensy = "$"

McPhone.Config.CameraWaterMark = "McPhone"

McPhone.Config.GPSList = {}

/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
////-- ───────────────────────────────────────────────────────--/////
////-- Do not edit anything below, unless you know what to do --/////
////-- ───────────────────────────────────────────────────────--/////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////

McPhone.Binds = {
	up = KEY_UP,
	down = KEY_DOWN,
	left = KEY_LEFT,
	right = KEY_RIGHT,
	close = KEY_APP,
	back = KEY_BACKSPACE,
	click = KEY_ENTER,
	click2 = KEY_SPACE
}

McPhone.McPhone = {}

McPhone.McPhone.Colors = {
	["red"] = Color(220,0,0),
	["green"] = Color(0,220,0),
	["blue"] = Color(80,130,220),
}

McPhone.McPhone.Themes = {
	["Green"] = {
		["menu"] = Color(0,120,0),
		["buttons"] = Color(50,200,50),
		["phone"] = Color(20,140,30),
		["def_wp"] = "Green Glow",
	},
	["Orange"] = {
		["menu"] = Color(240,90,0),
		["buttons"] = Color(255,145,40),
		["phone"] = Color(190,120,50),
		["def_wp"] = "Orange Halftone",
	},
	["Blue"] = {
		["menu"] = Color(134,172,234),
		["buttons"] = Color(0,175,240),
		["phone"] = Color(80,130,200),
		["def_wp"] = "Default",
	},
	["Red"] = {
		["menu"] = Color(170,0,0),
		["buttons"] = Color(130,0,0),
		["phone"] = Color(110,20,20),
		["def_wp"] = "Red Triangles",
	},
	["Grey"] = {
		["menu"] = Color(110,110,110),
		["buttons"] = Color(115,115,115),
		["phone"] = Color(100,100,100),
		["def_wp"] = "None",
	},
	["Purple"] = {
		["menu"] = Color(50,0,110),
		["buttons"] = Color(190,115,235),
		["phone"] = Color(150,0,210),
		["def_wp"] = "Purple Glow",
	},
	["Pink"] = {
		["menu"] = Color(225,0,140),
		["buttons"] = Color(250,110,200),
		["phone"] = Color(185,95,155),
		["def_wp"] = "Purple Tartan",
	},
}

McPhone.McPhone.WallPapers = {
	["None"] = false,
	["Default"] = "phone_wallpaper_McPhonedefault.png",
	["Blue Shards"] = "phone_wallpaper_blueshards.png",
	["Blue Angles"] = "phone_wallpaper_blueangles.png",
	["Blue Circles"] = "phone_wallpaper_bluecircles.png",
	["Diamonds"] = "phone_wallpaper_diamonds.png",
	["Green Glow"] = "phone_wallpaper_greenglow.png",
	["Green Shards"] = "phone_wallpaper_greenshards.png",
	["Green Squares"] = "phone_wallpaper_greensquares.png",
	["Green Triangles"] = "phone_wallpaper_greentriangles.png",
	["Orange 8bit"] = "phone_wallpaper_orange8bit.png",
	["Orange Halftone"] = "phone_wallpaper_orangehalftone.png",
	["Orange Herringbone"] = "phone_wallpaper_orangeherringbone.png",
	["Orange Triangles"] = "phone_wallpaper_orangetriangles.png",
	["Red Triangles"] = "phone_wallpaper_redtriangles.png",
	["Purple Glow"] = "phone_wallpaper_purpleglow.png",
	["Purple Tartan"] = "phone_wallpaper_purpletartan.png",
}

McPhone.McPhone.Ringtone = {
	["1"] = "tone_1",
	["2"] = "tone_2",
	["3"] = "tone_3",
	["4"] = "tone_4",
	["5"] = "tone_5",
	["6"] = "tone_6",
	["7"] = "tone_7",
	["8"] = "tone_8",
	["Silent"] = false,
}

McPhone.NotificationTone = {
	["1"] = "tone_1",
	["2"] = "tone_2",
	["3"] = "tone_3",
}

McPhone.UserCfg.Theme = McPhone.McPhone.Themes["Blue"]

McPhone.UserCfg.Binds = table.Copy(McPhone.Binds)

McPhone.UserCfg.UseMouse = true

McPhone.UserCfg.PopUp = true

McPhone.UserCfg.WallPaper = McPhone.McPhone.WallPapers[McPhone.UserCfg.Theme["def_wp"]]

McPhone.UserCfg.Profile = {
	Ringtone = McPhone.McPhone.Ringtone["3"],
	Smstone = McPhone.NotificationTone["1"],
	Sleep = false,
	PhoneColor = McPhone.UserCfg.Theme["phone"]
}

if CLIENT then
	
	CreateClientConVar( "mcphone_tip", 1, true, false )
	
	McPhone.SaveUserConfig = function()
		
		json_table = util.TableToJSON( McPhone.UserCfg, true )
		
		file.Write("mcphone_user_cfg.txt",json_table)
		
		net.Start("McPhone.GetUserData")
			net.WriteTable(McPhone.UserCfg.Profile)
		net.SendToServer()
		
	end
	
	if !file.Exists("mcphone_user_cfg.txt","DATA") then
		
		json_table = util.TableToJSON( McPhone.UserCfg, true )
		
		file.Write("mcphone_user_cfg.txt",json_table)
		
	else
	
		local config = util.JSONToTable(file.Read("mcphone_user_cfg.txt","DATA"))
		
		McPhone.UserCfg = config
	end

	net.Start("McPhone.GetUserData")
		net.WriteTable(McPhone.UserCfg.Profile)
	net.SendToServer()
	
end

net.Receive( "McPhone.GetData", function(l, ply)
	
	if CLIENT then
		local config = net.ReadTable()
			
		McPhone.Config = config
	else
		net.Start("McPhone.GetData")
			net.WriteTable(McPhone.Config)
		net.Send(ply)
	end
		
end)

if CLIENT then 
	
	net.Start("McPhone.GetData") net.SendToServer()
	
end

McPhone.SaveConfig = function()
	
	net.Start("McPhone.SaveConfig")
		net.WriteTable(McPhone.Config)
	net.SendToServer()
	
end

if SERVER then
	
	net.Receive( "McPhone.SaveConfig", function(l, ply)
		
		if !ply:IsSuperAdmin() then return end
		
		if McPhone.LockedConfig then return end
		
		local config = net.ReadTable()
		
		McPhone.Config = config
		
		net.Start("McPhone.GetData")
			net.WriteTable(config)
		net.Send(player.GetAll())
		
		json_table = util.TableToJSON( config, true )
		
		file.Write("mcphone_config.txt",json_table)
		
	end)
	
	if McPhone.LockedConfig then return end
	
	if !file.Exists("mcphone_config.txt","DATA") then
		
		json_table = util.TableToJSON( McPhone.Config, true )
		
		file.Write("mcphone_config.txt",json_table)
		
	else
	
		local config = util.JSONToTable(file.Read("mcphone_config.txt","DATA"))
		
		McPhone.Config = config
		
		if #player.GetAll() > 0 then
			net.Start("McPhone.GetData")
				net.WriteTable(config)
			net.Send(player.GetAll())
		end
		
	end
	
end