-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--

-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING

McPhone = {}
McPhone.UserCfg = {}
McPhone.Config = {}
McPhone.Modules = {}
McPhone.Language = {}

McPhone.Version = "1.1.2"
McPhone.ServerID = "GLeaks.Space"

util.PrecacheModel( "models/mactavish/mactavish_phone.mdl" )

if SERVER then
	resource.AddWorkshop( '2011745721' )
end

function McPhone.ModuleLoader()
	local files, folders = file.Find("mc_phone/modules/*", "LUA")

	for k,v in pairs(files) do
		if McPhone.DisableModules and McPhone.DisableModules[v] then continue end
		if (SERVER) then
			include("mc_phone/modules/" .. v)
			AddCSLuaFile("mc_phone/modules/" .. v)
			MsgC( Color(0, 0, 255), "[McPhone] "..v.." добавлен\n" )
		else
			include("mc_phone/modules/" .. v)
		end
	end
end

local function McPhoneLoad()
	
	MsgC( Color(0, 255, 0), "[McPhone] Инициализация...\n" )
	
	if !DarkRP then 
		MsgC( Color(255, 0, 0), "[McPhone] Инициализация ПРЕРВАНА!\n" )
		MsgC( Color(255, 0, 0), "[McPhone] DarkRP не загружен!\n" )
		McPhone = nil
		return
	end

	
	if !file.Exists(McPhone.ServerID, "DATA") then
		file.CreateDir(McPhone.ServerID)
	end
	
	if SERVER then
		include("mc_phone/sh_config.lua")
		include("mc_phone/sh_init.lua")
		include("mc_phone/sh_language.lua")
		include("mc_phone/sv_init.lua")
		AddCSLuaFile("mc_phone/sh_config.lua")
		AddCSLuaFile("mc_phone/sh_init.lua")
		AddCSLuaFile("mc_phone/sh_language.lua")
		AddCSLuaFile("mc_phone/cl_hooks.lua")
		AddCSLuaFile("mc_phone/cl_init.lua")
		AddCSLuaFile("mc_phone/cl_util.lua")
		AddCSLuaFile("mc_phone/cl_config_manager.lua")
	else
		include("mc_phone/sh_config.lua")
		include("mc_phone/sh_init.lua")
		include("mc_phone/sh_language.lua")
		include("mc_phone/cl_hooks.lua")
		include("mc_phone/cl_init.lua")
		include("mc_phone/cl_util.lua")
		include("mc_phone/cl_config_manager.lua")
	end
	
	McPhone.ModuleLoader()
	
	MsgC( Color(0, 255, 0), "[McPhone] Загрузка завершена\n" )
	
end

if SERVER then
	hook.Add("PostGamemodeLoaded", "McPhone.LoadSV", function() McPhoneLoad() end)	
else
	hook.Add("InitPostEntity", "McPhone.LoadCL", function() McPhoneLoad() end)
end

if GAMEMODE then
	McPhoneLoad()
end