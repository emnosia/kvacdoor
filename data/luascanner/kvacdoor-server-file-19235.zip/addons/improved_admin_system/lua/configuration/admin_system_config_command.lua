----------- // SCRIPT BY INJ3
----------- // SCRIPT BY INJ3
----------- // SCRIPT BY INJ3
--- // https://steamcommunity.com/id/Inj3/
--- // Improved Admin System
--- // true = activer, false = désactiver

--- Redémarrage du serveur nécessaire (obligatoire), si vous changez une commande !

--- // Commande Console
Admin_System_Global.Mode_AddCmd_NoClip = "admin_noclip" --- Activer/Désactiver le noclip.
Admin_System_Global.Mode_AddCmd_Cloak = "admin_cloak" --- Activer/Désactiver le cloak.
Admin_System_Global.Mode_AddCmd_GodMod = "admin_godmod" --- Activer/Désactiver le godmod.
-- //

--- // Commande Chat/Console
Admin_System_Global.Mode_Cmd = "!admin" --- // Activer le Mode Admin.
Admin_System_Global.Cmd_General = "admin_general" --- // Panneau général qui regroupe toutes les commandes ci-dessous.
Admin_System_Global.Ticket_Cmd = "!ticket" --- // Panel pour générer un ticket, inclure votre commande ici (ne pas inclure ///, celui-ci est déjà inclu automatiquement via la variable "Admin_System_Global.OverrideOpenTick").
Admin_System_Global.ModeAdmin_Chx = "!cadmin" --- // Panel de configuration Admin pour gérer les différents états (cloak, noclip, godmod).
Admin_System_Global.Remb_Cmd = "admin_remb" --- // Panel de remboursement.
Admin_System_Global.Stats_Cmd = "admin_verification" --- // Panel des statistiques de vos tickets (log).
Admin_System_Global.ZoneAdmin_Cmd = "admin_config_zoneadmin" --- // Panel pour ajouter/supprimer des Zones Admin.
Admin_System_Global.Service_Cmd = "admin_service" --- // Panel pour vos administrateurs en service/hors service.
Admin_System_Global.Chat_Cmd = "admin_chat" --- // Panel chat administrateur.
Admin_System_Global.StreamMod_Cmd = "admin_stream_mode" --- // Activer la visibilité des tickets.
-- //