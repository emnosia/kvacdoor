----------- // SCRIPT BY INJ3
----------- // SCRIPT BY INJ3
----------- // SCRIPT BY INJ3
--- // https://steamcommunity.com/id/Inj3/
--- // Improved Admin System
if SERVER then return end
----------------------\\ Notification - Ticket
Admin_System_Global.NotifTick = Color(49, 71, 94, 250)
Admin_System_Global.NotifTickText = Color( 	236, 240, 241 )
--\\ 
----------------------\\ Notification - Popup
Admin_System_Global.NotifPopup = Color(52, 73, 94) 
--\\ 
----------------------\\ Ticket
Admin_System_Global.TicketBorder = Color(52, 73, 94, 250)
Admin_System_Global.TicketText = Color(236, 240, 241)
Admin_System_Global.TicketBut = Color(52,73,94)
Admin_System_Global.TicketButText = Color(236, 240, 241)
Admin_System_Global.Ticket_ColPrdrTick = Color(52,73,94)
Admin_System_Global.Ticket_ColTickReso =  Color(52,73,94)
Admin_System_Global.TicketScrollBar = Color(52,73,94)
Admin_System_Global.TicketScrollUp = Color(236, 240, 241)
Admin_System_Global.TicketScrollDown = Color(236, 240, 241)
Admin_System_Global.TicketScrollRichText = Color(52,73,94) 
--\\
----------------------\\ Context menu - Action
Admin_System_Global.ButContextActionHover = Color(192, 57, 43)
Admin_System_Global.ButTextContextAction = Color(236, 240, 241)
Admin_System_Global.ButContextAction = Color(52,73,94) 
--\\
----------------------\\ Context menu - Left
Admin_System_Global.ColorContextLeft = Color(52,73,94) 
----------------------\\ Context menu - Right
Admin_System_Global.ContextTitleRight = Color(236, 240, 241)
Admin_System_Global.ContextRight = Color(52,73,94) 
Admin_System_Global.ContextBackButtonRight = Color( 0, 0, 0, 100)

Admin_System_Global.ContextActionAdminHoverRight = Color( 39, 174, 96 ) 
Admin_System_Global.ContextActionAdminHoverRight_1 = Color( 236, 240, 241 )
Admin_System_Global.ContextActionAdminButtonRight = Color(52,73,94) 
Admin_System_Global.ColorTextAdminRight = Color( 236, 240, 241 )

Admin_System_Global.ContextActionPlayerHoverRight = Color(	39, 174, 96 )
Admin_System_Global.ContextActionPlayerHover_1Right = Color( 236, 240, 241 )
Admin_System_Global.ContextActionPlayerButtonRight = Color(52,73,94) 
Admin_System_Global.ContextTextPlayerRight = Color( 236, 240, 241 )

Admin_System_Global.ContextButton = Color(52,73,94) 
Admin_System_Global.ContextTextButton = Color( 236, 240, 241 )
--\\
----------------------\\ Commande general
Admin_System_Global.CmdGeneralColor = Color(52,73,94)
Admin_System_Global.CmdGeneralColorTitle = Color( 236, 240, 241 )
Admin_System_Global.CmdGeneralColorBut = Color(52,73,94)
Admin_System_Global.CmdGeneralColorButText = Color(236, 240, 241)
--\\
----------------------\\ Creation ticket
Admin_System_Global.CreatetickColorCtr = {r = 52, g = 73, b = 94}
Admin_System_Global.CreatetickColorInfos = Color(52 ,73 , 94)
Admin_System_Global.CreatetickColor = Color(44, 62, 80)
Admin_System_Global.CreatetickColorTitle = Color(236, 240, 241)
Admin_System_Global.CreatetickColorBackground = Color(0,0,0,100)
Admin_System_Global.CreatetickColorBut = Color(52,73,94)
Admin_System_Global.CreatetickColorText = Color( 236, 240, 241 )

Admin_System_Global.CreatetickScrollBar = Color(44, 62, 80)
Admin_System_Global.CreatetickScrollBar_Up = Color(236, 240, 241)
Admin_System_Global.CreatetickScrollBar_Down = Color(236, 240, 241)
--\\
----------------------\\ Creation ticket - Complement
Admin_System_Global.CreatetickColorCompCtr = {r = 52, g = 73, b = 94}
Admin_System_Global.CreatetickColorComp = Color(44, 62, 80)
Admin_System_Global.CreatetickColorCompTitle = Color(236, 240, 241)
Admin_System_Global.CreatetickColorCompTextChar = Color(192, 57, 43)
Admin_System_Global.CreatetickColorCompValid = Color(52,73,94)
Admin_System_Global.CreatetickColorCompText = Color(236, 240, 241)
--\\ 