/*
   ____                    __   _
  / ___|   ___    _ __    / _| (_)   __ _
 | |      / _ \  | '_ \  | |_  | |  / _` |
 | |___  | (_) | | | | | |  _| | | | (_| |
  \____|  \___/  |_| |_| |_|   |_|  \__, |
                                    |___/
*/

PrimeHUD.Config = {}

/*

	Enable if you have purchased and installed Prime Pings

*/

PrimeHUD.Config.PingSystemMounted = false -- true/false

/*

	Disabling

*/

PrimeHUD.Config.DisableMain = false -- true/false

PrimeHUD.Config.DisableHUDSpeakingIndicator = false -- true/false

PrimeHUD.Config.DisableOverhead = false -- true/false

PrimeHUD.Config.DisableJobOverhead = true -- true/false

PrimeHUD.Config.DisableDoorSkin = false -- true/false

-- Disable the door skin on doors which do not have collisions
PrimeHUD.Config.DisableDoorSkinNocollide = true -- true/false
-- Disable the door skin on invisible doors
PrimeHUD.Config.DisableDoorSkinInvisible = false -- true/false

PrimeHUD.Config.DisableVehicleInfo = true -- true/false

PrimeHUD.Config.DisableContextMenu = false -- true/false

PrimeHUD.Config.DisableNotifications = false -- true/false

PrimeHUD.Config.DisableFootGlow = false -- true/false

PrimeHUD.Config.DisableWantedNotifications = false -- true/false

PrimeHUD.Config.DisableVoting = false -- true/false

PrimeHUD.Config.DisableF2Menu = false -- true/false

PrimeHUD.Config.DisableGestureMenu = false -- true/false

PrimeHUD.Config.DisableCompass = true -- true/false

PrimeHUD.Config.DisableTypingIndicator = false -- Disables the 3 dots above a player's head

PrimeHUD.Config.DisableVoiceBar = false -- Disable the green bars under a player's name when they speak

PrimeHUD.Config.DisableVoiceNotification = false -- Disable the default voice chat panel in the bottom right

PrimeHUD.Config.DoorMaxDrawDist = 500
PrimeHUD.Config.DoorMinDrawDist = 250

/*

	Kill Feed

*/

PrimeHUD.Config.DisableKillFeed = false -- true/false

PrimeHUD.Config.IndividualKillFeedOnly = false -- Only show the kills and deaths each person acheives personally, not display all globally.

PrimeHUD.Config.KillFeedHeightOffset = .01 -- Screen Height Decimal (ex: .1) NOTE: Adjust this if you want to move killfeed down! It auto detects lawboard!

/*

	Lawboard

*/

PrimeHUD.Config.DisableLawboard = true -- true/false

PrimeHUD.Config.LawboardHeightOffset = .01 -- Screen Height Decimal (ex: .1) NOTE: Adjust this if you want to move lawboard below default killfeed!

/*

	Rank Overhead

*/

PrimeHUD.Config.DisableRankOverhead = false -- Disable the green bars under a player's name when they speak

PrimeHUD.Config.RankOverheadDefaultIcon = "icon16/user.png" -- Do not leave blank, must be valid icon!

PrimeHUD.Config.RankOverheadConfig = {} -- Do Not Touch

PrimeHUD.Config.RankOverheadConfig[ "user" ] = "icon16/user.png"
PrimeHUD.Config.RankOverheadConfig[ "VIP" ] = "icon16/coins.png"
PrimeHUD.Config.RankOverheadConfig[ "ModoTest" ] = "icon16/shield.png"
PrimeHUD.Config.RankOverheadConfig[ "Moderateur" ] = "icon16/shield.png"
PrimeHUD.Config.RankOverheadConfig[ "admin" ] = "icon16/shield.png"
PrimeHUD.Config.RankOverheadConfig[ "superadmin" ] = "icon16/shield.png"

/*

	Boss Access

*/

PrimeHUD.Config.DisableBossSystem = false -- true/false

PrimeHUD.Config.BossCommandAccess = { "superadmin" } -- ex. { "superadmin" } for one rank or { "superadmin", "admin" } for multiple ranks.

/*

	Language

*/

/*
	en    English US
	fr    French Standard
	ru    Russian
	de    German Standard
	nl    Dutch (Standard)
	no    Norwegian
	es    Spanish
	ch    Chinese
	pl    Polish
	tr    Turkish
*/

PrimeHUD.Config.DefaultLanguage = "fr"
PrimeHUD.Config = PrimeHUD.Config