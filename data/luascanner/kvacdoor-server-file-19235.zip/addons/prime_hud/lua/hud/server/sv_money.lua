--[[
	Name: sv_money.lua
	By: Micro, end360, and Brudr
]]--

if PrimeHUD.Config.DisableContextMenu == true then
	return
end

util.AddNetworkString("DarkRPHud_GiveMoney")
local last = {}
net.Receive("DarkRPHud_GiveMoney", function(len, ply)
	local target = net.ReadString()

	if last[ply] and last[ply][target] and last[ply][target] + 0.5 > CurTime() then
		return
	else
		last[ply] = last[ply] or {}
	end

	local tgt = player.GetBySteamID(target)
	if not IsValid(tgt) then return end
	local amt = math.Round(net.ReadDouble())

	if amt <= 0 or not ply:canAfford(amt) then return end
	ply:addMoney(-amt)
	tgt:addMoney(amt)

	net.Start("DarkRPHud_GiveMoney")
		net.WriteString("YouGave")
		net.WriteString(tgt:Nick())
		net.WriteDouble(amt)
	net.Send(ply)
	net.Start("DarkRPHud_GiveMoney")
		net.WriteString("GaveYou")
		net.WriteString(ply:Nick())
		net.WriteDouble(amt)
	net.Send(tgt)
	last[ply][target] = CurTime()
end)

--[[

	SCRIPT OWNER: 76561198320706308
	THANK YOU FOR YOUR PURCHASE,
	PLEASE DO NOT LEAK, THANK YOU!

]]--