--[[
	Name: sv_hud_overhead.lua
	By: Micro, end360, and Brudr
]]--

if PrimeHUD.Config.DisableOverhead == true then
	return
end

if (SERVER) then
 RunConsoleCommand('mp_show_voice_icons', '0')
end