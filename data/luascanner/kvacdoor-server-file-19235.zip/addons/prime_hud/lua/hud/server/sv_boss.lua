--[[
	Name: sv_boss.lua
	By: Micro, end360, and Brudr
]]--

if PrimeHUD.Config.DisableBossSystem == true then
	return
end

util.AddNetworkString("SetBoss")
util.AddNetworkString("StopBoss")
util.AddNetworkString("GetBossStats")
util.AddNetworkString("DetectBossDeath")

concommand.Add( 'stopboss', function( ply, cmd, args )
    if !table.HasValue( PrimeHUD.Config.BossCommandAccess, ply:GetUserGroup() ) then
		print("Access Denied!") return
    end
	if bossActive then
		bossActive = false
		_match:SetHealth(_match.oldhealth)
		_match:SetArmor(_match.oldarmor)
		_match.oldhealth, _match.oldarmor = nil, nil
		print("Boss Fight Ended")
		net.Start("StopBoss")
		net.WriteBool(false)
		net.Broadcast()
	end
end)

concommand.Add( 'setboss', function( ply, cmd, args )
    if !table.HasValue( PrimeHUD.Config.BossCommandAccess, ply:GetUserGroup() ) then
		print("Access Denied!") return
    end
	if bossActive then
		print("Boss Fight already active! Try 'stopboss' to end Boss Fight first.")
		return;
	end
	if table.Count(args) != 3 then
		print("Invalid SetBoss.")
		print("Format: 'setboss player<name> health<value> armor<value>")
		return;
	end
	if tonumber(args[2]) >= (2^32)/2-1 or tonumber(args[3]) >= (2^32)/2-1 then
		print("Your numbers are too powerful.")
		print("Health/Armor cannot excede ".. tostring((2^32)/2-1))
		return
	end
	for k, v in pairs( player.GetAll() ) do
			local _find = string.find( string.lower( v:Nick() ), string.lower( args[ 1 ] ) );
			if  !_find then
			continue;
		else
			_match = v
			break;
		end
	end
	if (IsValid( _match) && _match:IsPlayer()) then
		boss = _match
		print("Boss Fight Activated; Boss Name:")
		print(_match:Nick())
		bossActive = true
		local bosshp = args[2]
		local bossap = args[3]
		_match.oldhealth = _match:Health()
		_match.oldarmor = _match:Armor()
		bossMAX = bosshp + bossap
		_match:SetHealth(bosshp)
		_match:SetArmor(bossap)
			net.Start("SetBoss")
			net.WriteEntity( _match )
			net.Broadcast()
		else
			print("Invalid Set Boss. Player not found.")
			print("Format: 'setboss player<name> health<value> armor<value>")
		end
end)

hook.Add("Think", "BossUpdate", function()
	if boss == nil or bossActive == false then
			net.Start("DetectBossDeath")
			net.WriteBool(bossActive)
			net.Broadcast()
		return;
	end
	if bossMAX < boss:Health() + boss:Armor() then
		bossMAX = boss:Health() + boss:Armor()
	end
	if bossActive && boss:Alive() then
			net.Start("GetBossStats")
			net.WriteEntity(boss)
			net.WriteInt(bossMAX, 32)
			net.Broadcast()
		else
			bossActive = false
	end
	net.Start("DetectBossDeath")
	net.WriteBool(bossActive)
	net.Broadcast()
end)