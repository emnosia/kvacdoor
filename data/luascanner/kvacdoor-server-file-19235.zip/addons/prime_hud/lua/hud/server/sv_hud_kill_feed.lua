--[[
	Name: sv_hud_kill_feed.lua
	By: Micro, end360, and Brudr
]]--

if PrimeHUD.Config.DisableKillFeed == false then
	if (SERVER) then
	 	RunConsoleCommand('hud_deathnotice_time', '0')
	end

	util.AddNetworkString("killFeed")

	hook.Add("PlayerDeath", "killFeedDataSend", function(victim, attacker)

		local filter
		if PrimeHUD.Config.IndividualKillFeedOnly then 
			filter = {}
			if IsValid(victim) and victim:IsPlayer() then 
				table.insert(filter, victim)
			end
			if IsValid(attacker) and attacker:IsPlayer() then 
				table.insert(filter, attacker)
			end
		else 
			filter = player.GetAll()
		end

		net.Start("killFeed")
			net.WriteEntity(victim)
			net.WriteEntity(attacker)
		net.Send(filter)
	end)
end