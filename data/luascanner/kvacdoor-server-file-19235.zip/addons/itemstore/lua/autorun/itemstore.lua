itemstore = {}

if SERVER then
	include( "itemstore/sv_init.lua" )
else
	include( "itemstore/cl_init.lua" )
end

-- iHaxCommunity - Greg - https://ihax.fr/members/greg.11822/