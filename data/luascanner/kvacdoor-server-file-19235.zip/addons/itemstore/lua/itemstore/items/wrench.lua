ITEM.Name = "Wrench" 
ITEM.Description = "An engineer's favourite tool."
ITEM.Model = "models/props_c17/tools_wrench01a.mdl"
ITEM.Base = "base_entity" 
ITEM.Stackable = true