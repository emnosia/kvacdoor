ITEM.Name = "Overclocker" 
ITEM.Description = "A money printer upgrade."
ITEM.Model = "models/props_lab/reciever01d.mdl"
ITEM.Base = "base_entity" 
ITEM.Stackable = true