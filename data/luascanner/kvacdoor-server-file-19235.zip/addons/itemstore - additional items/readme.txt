This addon contains support for several addons not supported in vanilla ItemStore.

Included in this folder is support for:
NG1 printers
Gemstone printers
Several old coderhire created by an author known by Fat Jesus.

If you wish to use these with ItemStore, place this folder inside your addons folder.