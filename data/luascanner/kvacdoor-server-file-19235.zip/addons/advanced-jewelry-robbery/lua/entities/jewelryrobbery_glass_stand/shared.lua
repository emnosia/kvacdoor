AddCSLuaFile()
ENT.Type = "anim"
ENT.Base = "jewelryrobbery_glass_base"
ENT.PrintName = "Jewelry glass stand"
ENT.Author = "Venatuss"
ENT.Spawnable = true

ENT.model = Model("models/sterling/ajr_cabnet3.mdl")
ENT.displayPos = Vector(25, 0, 65)

ENT.JewelryPos = {
	{
		up = 51,
		forward = 0,
		right = 0,
	},
}