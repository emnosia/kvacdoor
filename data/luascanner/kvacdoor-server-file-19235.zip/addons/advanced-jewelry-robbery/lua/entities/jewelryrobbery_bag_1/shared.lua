AddCSLuaFile()

ENT.Type = 'anim'
ENT.Base = 'advancedrobbery_robbery_bag_base'
ENT.BagWeight = 30
ENT.BagModel = 'models/sterling/ajr_backpack.mdl'
ENT.PrintName = 'Bag : Jewelry 1'
ENT.Category = 'Advanced Robbery'
ENT.Author = 'Venatuss'
ENT.Spawnable = true
ENT.BagColor = 	Color( 255, 255, 255, 255 )
AdvancedRobbery.BagPos = AdvancedRobbery.BagPos or {}
AdvancedRobbery.BagPos[ 'models/sterling/ajr_backpack.mdl' ] = {
	Angle = Angle( 0, 120, 90 ),
	Position = Vector( -10.5, 0,0 ),
}
