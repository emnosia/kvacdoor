﻿--[[
	Advanced Robbery Compatibility :
	Add here the specific functions of the script
	The identifier of the script should be unique ( here 0 )
]]

AdvancedRobbery = AdvancedRobbery or {}
AdvancedRobbery.ScriptFunc = AdvancedRobbery.ScriptFunc or {}
-- 0 = jewelryrob 
AdvancedRobbery.ScriptFunc[ 0 ] = {
	GetConfig = function( tConfig )
		return Jewelry_Robbery.Config
	end,
	SetConfig = function( tConfig )
		Jewelry_Robbery.Config = table.Copy( tConfig )
	end,
	NetToolReceived = function()
		Jewelry_Robbery.Config= net.ReadTable()
		AdvancedRobbery:SaveConfiguration( 0, Jewelry_Robbery.Config or {} )
	end,
	GrabCheck = function( ent )
		if ( not ent or not isfunction( ent.GetShowcase ) ) then return false end
		local eShowcase = ent:GetShowcase()
		if ( not IsValid( eShowcase ) ) then return false end
		local tConfig = Jewelry_Robbery.Config.ListJewelry or {}

		if not tConfig[ ent:GetModel() ] then return false end
		local tConfigWeight = tConfig[ ent:GetModel() ].weight or 1000

		local bFirstCheck = AdvancedRobbery_GetBagWeight( LocalPlayer() ) + tConfigWeight <= AdvancedRobbery_GetBagMaxWeight( LocalPlayer() ) and LocalPlayer():HasWeapon( 'advancedrobbery_robbery_bag' )
		local bSecondCheck = ent:GetScript() ~= 0 or eShowcase:GetIsBroken()
		return bFirstCheck and bSecondCheck
	end,
	GrabFunction = function( pCaller, eStolenEnt )
		if not AdvancedRobbery_IsRobber( pCaller ) then return end
		
		if ( not isfunction( eStolenEnt.GetShowcase ) ) then return end
		local eShowcase = eStolenEnt:GetShowcase()
		if ( not IsValid( eShowcase ) ) then return end		
		
		local iWeight = AdvancedRobbery_GetBagWeight( pCaller )
		if not iWeight or not isnumber( iWeight ) then return end

		if not eShowcase:GetIsBroken() then return end
		local tConfig = Jewelry_Robbery.Config.ListJewelry
		if not tConfig then return end
		if not tConfig[ eStolenEnt:GetModel() ] then return end

		local tConfigWeight = tConfig[ eStolenEnt:GetModel() ].weight or 1000
		-- weight of showcase
		if iWeight + tConfigWeight > AdvancedRobbery_GetBagMaxWeight( pCaller ) then 
			AdvancedRobbery.Notify( 1, Jewelry_Robbery.Config.Lang[7][ Jewelry_Robbery.Config.Language ], pCaller )
			return
		end

		pCaller.ListJewelry = pCaller.ListJewelry or {}
		pCaller.ListJewelry[ 'jewelry' ] = pCaller.ListJewelry[ 'jewelry' ] or {}
		pCaller.ListJewelry[ 'jewelry' ][ eStolenEnt:GetModel() ] = pCaller.ListJewelry[ 'jewelry' ][ eStolenEnt:GetModel() ] or {}

		pCaller.ListJewelry[ 'jewelry' ][ eStolenEnt:GetModel() ] = {
			number = ( pCaller.ListJewelry[ 'jewelry' ][ eStolenEnt:GetModel() ].number or 0 ) + 1,
			weight = tConfigWeight,
			price_blackmarket = tConfig[ eStolenEnt:GetModel() ].price_blackmarket,
			name = tConfig[ eStolenEnt:GetModel() ].name
		}

		AdvancedRobbery.Notify( 0, string.format( Jewelry_Robbery.Config.Lang[2][ Jewelry_Robbery.Config.Language ], tConfig[ eStolenEnt:GetModel() ].name or "jewelry" ), pCaller )

		eStolenEnt:Remove()

		AdvancedRobbery.Networking:Send( 'AdvancedRobbery:SendJewelryListToPlayer', pCaller, pCaller.ListJewelry )
	end
}

local bgcolor = Color( 200, 200, 200, 255 )
local bluecolor = Color( 0, 0, 120, 255 )
local darkbluecolor = Color( 0, 0, 50, 255 )
local redcolor = Color( 255, 0, 0, 255 )
local redcolordark = Color( 120, 0, 0, 255 )
local greycolor = Color( 0, 0, 0, 255 )

local function OpenShowcaseConfigMenu()
	local MainFrame = vgui.Create( "DFrame" )
	MainFrame:SetSize( 450, 500 )
	MainFrame:Center()
	MainFrame:SetTitle( "" )
	MainFrame:ShowCloseButton( false )
	MainFrame:MakePopup()
	MainFrame.Paint = function() end
	function MainFrame:OnClose()
		local configToSend = table.Copy( Jewelry_Robbery.Config )
		AdvancedRobbery.Config.NPCPositions = nil
		AdvancedRobbery.Config.EntitiesSpawns = nil

		net.Start( "AdvancedRobbery.Tool" )
			net.WriteInt( 4, 5 )
			net.WriteInt( 0, 6 )
			net.WriteTable( configToSend )
		net.SendToServer()	
	end
	
	local ContentPanel = vgui.Create( "DPanel", MainFrame )
	ContentPanel:SetSize( 450, 475 )
	function ContentPanel:Paint( w, h ) 
		draw.RoundedBox( 0, 0, 0, w, h, bgcolor )
		draw.RoundedBox( 0, 0, 0, w, 25, bluecolor )
	end
	
	local CloseButton = vgui.Create( "DButton", ContentPanel )
	CloseButton:SetText( "" )
	CloseButton:SetSize( 25, 25 )
	CloseButton:SetPos( MainFrame:GetWide() - 35, 0 )
	function CloseButton:Paint( w, h )
		if self:IsHovered() then
			draw.SimpleText( "X", "AdvancedRobbery.Font17b", w / 2, h / 2, redcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		else
			draw.SimpleText( "X", "AdvancedRobbery.Font17b", w / 2, h / 2, bgcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
	end
	function CloseButton:DoClick( w, h )
		MainFrame:Close() 
	end
	
	local title = vgui.Create( "DLabel", ContentPanel )
	title:Dock( TOP )
	title:DockMargin( 5, 0, 5, 5 )
	title:SetContentAlignment( 5 )
	title:SetFont( "AdvancedRobbery.Font17b" )
	title:SetText( "Advanced Robbery - Showcase Config" )
	title:SetTall( 30 )
	title:SetTextColor( Color( 255, 255, 255 ) )
	
	local LeftPanel = vgui.Create( "DScrollPanel", ContentPanel )
	LeftPanel:SetPos( 0, 25 )
	LeftPanel:SetSize( 280, ContentPanel:GetTall() - 30 )
	LeftPanel.Paint = function( pnl, w, h ) end
	local sbarHide = LeftPanel:GetVBar()
	sbarHide:SetWide( 0 )
	
	local RightPanel = vgui.Create( "DScrollPanel", ContentPanel )
	RightPanel:SetPos( LeftPanel:GetWide(), 25 )
	RightPanel:SetWide( ContentPanel:GetWide() - LeftPanel:GetWide() )
	RightPanel:SetTall( ContentPanel:GetTall() - 30 )
	RightPanel.Paint = function( pnl, w, h ) end
	
	local sbar = RightPanel:GetVBar( )
	sbar:SetHideButtons( true )
	
	function sbarHide:Think()
		self:SetScroll( sbar:GetScroll() ) 
	end

	function sbar:Paint( w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(255, 255, 255,0 ) )
	end	
	sbar:SetWide( 5 )
	function sbar.btnGrip:Paint( w, h )
		draw.RoundedBox( 5, 0, 0, w, h, bluecolor )
	end

	local listJewelryLabel = vgui.Create( "DLabel", LeftPanel )
	listJewelryLabel:Dock( TOP )
	listJewelryLabel:DockMargin( 5, 5, 5, 5 )
	listJewelryLabel:SetContentAlignment( 7 )
	listJewelryLabel:SetFont( "AdvancedRobbery.Font17b" )
	listJewelryLabel:SetWrap( true )
	listJewelryLabel:SetText( "List of jewelry in the stands:" )
	listJewelryLabel:SetTall( ( 105 + 5 ) * table.Count( Jewelry_Robbery.Config.ListJewelry ) ) 
	listJewelryLabel:SetTextColor( greycolor )

	for sModel, tInfos in pairs( Jewelry_Robbery.Config.ListJewelry ) do
		local PanelList = vgui.Create( "DPanel", RightPanel )
		PanelList:Dock( TOP )
		PanelList:DockMargin( 5, 5, 5, 5 )
		PanelList:SetTall( 105 )

		local SpawnIcon = vgui.Create( "SpawnIcon", PanelList )
		SpawnIcon:SetSize( 50, 50 )
		SpawnIcon:SetModel( sModel )

		local ModelEntry = vgui.Create( "DTextEntry", PanelList )
		ModelEntry:SetPos( 0, 80 )
		ModelEntry:SetSize( RightPanel:GetWide() - 10, 20 )
		ModelEntry:SetText( sModel )
		ModelEntry:SetUpdateOnType( true )
		ModelEntry.OnValueChange = function( self, value )
			SpawnIcon:SetModel( value )
			local config = table.Copy( Jewelry_Robbery.Config.ListJewelry[ sModel ] )
			Jewelry_Robbery.Config.ListJewelry[ sModel ] = nil
			sModel = value 
			Jewelry_Robbery.Config.ListJewelry[ sModel ] = config
			Jewelry_Robbery.Config.ListJewelry[ sModel ].model = sModel
		end

		local NameEntry = vgui.Create( "DTextEntry", PanelList )
		NameEntry:SetPos( 102, 0  )
		NameEntry:SetSize( 50, 18 )
		NameEntry:SetText( tInfos.name )
		NameEntry:SetUpdateOnType( true )
		NameEntry.OnValueChange = function( self, value )
			Jewelry_Robbery.Config.ListJewelry[ sModel ].name = value
		end

		local PriceEntry = vgui.Create( "DTextEntry", PanelList )
		PriceEntry:SetPos( 102, 20  )
		PriceEntry:SetSize( 50, 18 )
		PriceEntry:SetNumeric( true )
		PriceEntry:SetUpdateOnType( true )
		PriceEntry:SetText( tInfos.price_blackmarket )
		PriceEntry.OnValueChange = function( self, value )
			Jewelry_Robbery.Config.ListJewelry[ sModel ].price_blackmarket = value
		end

		local WeightEntry = vgui.Create( "DTextEntry", PanelList )
		WeightEntry:SetPos( 102, 40  )
		WeightEntry:SetSize( 50, 18 )
		WeightEntry:SetNumeric( true )
		WeightEntry:SetText( tInfos.weight )
		WeightEntry:SetUpdateOnType( true )
		WeightEntry.OnValueChange = function( self, value )
			Jewelry_Robbery.Config.ListJewelry[ sModel ].weight = value
		end

		local ScaleEntry = vgui.Create( "DTextEntry", PanelList )
		ScaleEntry:SetPos( 102, 60  )
		ScaleEntry:SetSize( 50, 18 )
		ScaleEntry:SetNumeric( true )
		ScaleEntry:SetText( tInfos.scale )
		ScaleEntry:SetUpdateOnType( true )
		ScaleEntry.OnValueChange = function( self, value )
			Jewelry_Robbery.Config.ListJewelry[ sModel ].scale = value
		end

		local NameLabel = vgui.Create( "DLabel", PanelList )
		NameLabel:SetPos( 52, 0 )
		NameLabel:SetFont( "AdvancedRobbery.Font17b" )
		NameLabel:SetWrap( false )
		NameLabel:SetText( "Name:" )
		NameLabel:SetTextColor( greycolor )

		local PriceLabel = vgui.Create( "DLabel", PanelList )
		PriceLabel:SetPos( 52, 20 )
		PriceLabel:SetFont( "AdvancedRobbery.Font17b" )
		PriceLabel:SetWrap( false )
		PriceLabel:SetText( "Price:" )
		PriceLabel:SetTextColor( greycolor )

		local WeightLabel = vgui.Create( "DLabel", PanelList )
		WeightLabel:SetPos( 52, 40 )
		WeightLabel:SetFont( "AdvancedRobbery.Font17b" )
		WeightLabel:SetWrap( false )
		WeightLabel:SetText( "Weight:" )
		WeightLabel:SetTextColor( greycolor )

		local ScaleLabel = vgui.Create( "DLabel", PanelList )
		ScaleLabel:SetPos( 52, 60 )
		ScaleLabel:SetFont( "AdvancedRobbery.Font17b" )
		ScaleLabel:SetWrap( false )
		ScaleLabel:SetText( "Scale:" )
		ScaleLabel:SetTextColor( greycolor )

		local jewelryRemove = vgui.Create( "DButton", PanelList )
		jewelryRemove:SetPos( 12, 52 )
		jewelryRemove:SetSize( 28, 20 )
		jewelryRemove:SetTall( 25 )
		jewelryRemove:SetText( "" )
		function jewelryRemove:Paint( w, h )
			if self:IsHovered() then
				draw.RoundedBox( 0, 0, 0, w, h, redcolordark )
			else
				draw.RoundedBox( 0, 0, 0, w, h, redcolordark )
				draw.RoundedBoxEx( 0, 0, h - 5, w, 5, redcolordark, false, false, true, true )
			end
			
			draw.SimpleText( "X", "AdvancedRobbery.Font22", w / 2, h / 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
		function jewelryRemove:DoClick()
			Jewelry_Robbery.Config.ListJewelry[ sModel ] = nil
			MainFrame:Close()
			OpenShowcaseConfigMenu()
		end
	end

	local jewelryAdd = vgui.Create( "DButton", RightPanel )
	jewelryAdd:Dock( TOP )
	jewelryAdd:DockMargin( 5, 5, 5, 5 )
	jewelryAdd:SetTall( 25 )
	jewelryAdd:SetText( "" )
	function jewelryAdd:Paint( w, h )
		if self:IsHovered() then
			draw.RoundedBox( 0, 0, 0, w, h, darkbluecolor )
		else
			draw.RoundedBox( 0, 0, 0, w, h, bluecolor )
			draw.RoundedBoxEx( 0, 0, h - 5, w, 5, darkbluecolor, false, false, true, true )
		end
		
		draw.SimpleText( "+ADD", "AdvancedRobbery.Font17", w / 2, h / 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	function jewelryAdd:DoClick()
		Jewelry_Robbery.Config.ListJewelry[ "model" ] = {
			name = "Name",
			model = "model",
			price_blackmarket = 150,
			weight = 1,
			scale = 1,
		}
		MainFrame:Close()
		OpenShowcaseConfigMenu()
	end
end

AdvancedRobbery.ListOfTools = AdvancedRobbery.ListOfTools or {}

local ListOfTools = { 
	{
		name = "Jewlery : Stand#1",
		model = "models/sterling/ajr_cabnet.mdl",
		ang = Angle( 90, 0, 0 ),
		vec = Vector( 0, 0, 37 ),
		stayOnGround = false,
		onLeftClick = function( tool, tTool )
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] = AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] or {}
			if CLIENT then 
				if not IsValid( tool.EntPreview ) then return end

				local class = "jewelryrobbery_glass_long"
				AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] = AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] or {}
				
				local id = #AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] + 1
				AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ][ id ] = {
					pos = tool.EntPreview:GetPos(),
					ang = tool.EntPreview:GetAngles(),
					type = "jewelry"
				}
				
				net.Start( "AdvancedRobbery.Tool" )
					net.WriteInt( 1, 5 )
					net.WriteString( class )
					net.WriteInt( id, 32 )
					net.WriteTable( AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ][ id ] )
				net.SendToServer()

			end

			tTool:NextToolFunction( 0 )
		end,
		onRightClick = function( tool, tTool )
			local class = "jewelryrobbery_glass_long"
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] = {}
			
			if CLIENT then
				net.Start( "AdvancedRobbery.Tool" )
					net.WriteInt( 2, 5 )
					net.WriteString( class )
				net.SendToServer()
			end
			
			if SERVER then
				AdvancedRobbery:SaveConfiguration()
			end
			
			tTool:NextToolFunction( 0 )
		end
	},
	{
		name = "Jewlery : Stand#2",
		model = "models/sterling/ajr_cabnet2.mdl",
		ang = Angle( 90, 0, 0 ),
		stayOnGround = false,
		onLeftClick = function( tool, tTool )
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] = AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] or {}
			if CLIENT then 
				if not IsValid( tool.EntPreview ) then return end

				local class = "jewelryrobbery_glass_corner"
				AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] = AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] or {}
				
				local id = #AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] + 1
				AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ][ id ] = {
					pos = tool.EntPreview:GetPos(),
					ang = tool.EntPreview:GetAngles(),
					type = "jewelry"
				}
				
				net.Start( "AdvancedRobbery.Tool" )
					net.WriteInt( 1, 5 )
					net.WriteString( class )
					net.WriteInt( id, 32 )
					net.WriteTable( AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ][ id ] )
				net.SendToServer()

			end

			tTool:NextToolFunction( 0 )
		end,
		onRightClick = function( tool, tTool )
			local class = "jewelryrobbery_glass_corner"
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] = {}
			
			if CLIENT then
				net.Start( "AdvancedRobbery.Tool" )
					net.WriteInt( 2, 5 )
					net.WriteString( class )
				net.SendToServer()
			end
			
			if SERVER then
				AdvancedRobbery:SaveConfiguration()
			end
			
			tTool:NextToolFunction( 0 )
		end
	},
	{
		name = "Jewlery : Stand#3",
		model = "models/sterling/ajr_cabnet3.mdl",
		ang = Angle( 90, 0, 0 ),
		stayOnGround = false,
		onLeftClick = function( tool, tTool )
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] = AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] or {}
			if CLIENT then 
				if not IsValid( tool.EntPreview ) then return end

				local class = "jewelryrobbery_glass_stand"
				AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] = AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] or {}
				
				local id = #AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] + 1
				AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ][ id ] = {
					pos = tool.EntPreview:GetPos(),
					ang = tool.EntPreview:GetAngles(),
					type = "jewelry"
				}
				
				net.Start( "AdvancedRobbery.Tool" )
					net.WriteInt( 1, 5 )
					net.WriteString( class )
					net.WriteInt( id, 32 )
					net.WriteTable( AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ][ id ] )
				net.SendToServer()

			end

			tTool:NextToolFunction( 0 )
		end,
		onRightClick = function( tool, tTool )
			local class = "jewelryrobbery_glass_stand"
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] = {}
			
			if CLIENT then
				net.Start( "AdvancedRobbery.Tool" )
					net.WriteInt( 2, 5 )
					net.WriteString( class )
				net.SendToServer()
			end
			
			if SERVER then
				AdvancedRobbery:SaveConfiguration()
			end
			
			tTool:NextToolFunction( 0 )
		end
	},
	{
		name = "Jewlery : Alarm",
		model = "models/sterling/ajr_alarm.mdl",
		ang = Angle( 0, 0, 0 ),
		stayOnGround = false,
		onLeftClick = function( tool, tTool )
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] = AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ] or {}
			if CLIENT then 
				if not IsValid( tool.EntPreview ) then return end

				local class = "jewelryrobbery_alarm_1"
				AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] = AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] or {}
				
				local id = #AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] + 1
				AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ][ id ] = {
					pos = tool.EntPreview:GetPos(),
					ang = tool.EntPreview:GetAngles(),
					type = "jewelry"
				}
				
				net.Start( "AdvancedRobbery.Tool" )
					net.WriteInt( 1, 5 )
					net.WriteString( class )
					net.WriteInt( id, 32 )
					net.WriteTable( AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ][ id ] )
				net.SendToServer()

			end

			tTool:NextToolFunction( 0 )
		end,
		onRightClick = function( tool, tTool )
			local class = "jewelryrobbery_alarm_1"
			AdvancedRobbery.Config.EntitiesSpawns[ game.GetMap() ][ class ] = {}
			
			if CLIENT then
				net.Start( "AdvancedRobbery.Tool" )
					net.WriteInt( 2, 5 )
					net.WriteString( class )
				net.SendToServer()
			end
			
			if SERVER then
				AdvancedRobbery:SaveConfiguration()
			end
			
			tTool:NextToolFunction( 0 )
		end
	},
	{
		name = "Jewelry config menu",
		onSelectTool = function( tool, tTool )
			if CLIENT and IsValid( tool.EntPreview ) then
				timer.Simple( 0.1, function()
					if not IsValid( tool.EntPreview ) then return end
					tool.EntPreview:Remove()
				end)
			end
		end,
		onLeftClick = function( tool, tTool )
			if CLIENT then 
				OpenShowcaseConfigMenu()
			end
		end,
		onRightClick = function( tool, tTool )
		end
	}
}

for k, v in pairs( ListOfTools ) do
	table.insert( AdvancedRobbery.ListOfTools, v )
end

--[[
	END OF COMPATIBILITY PART
]]


Jewelry_Robbery = {}
Jewelry_Robbery.Config = {}
Jewelry_Robbery.Config.HealthAlarm = 1
Jewelry_Robbery.Config.HealthGlass = 100

-- include shared
include("jewelry_robbery/sh_lang.lua")
include("jewelry_robbery/shared/sh_def_config.lua")
include("jewelry_robbery/sh_config.lua")

if SERVER then
	
	-- resource.AddWorkshop("1601630971")
	
	-- AddCSLuaFile shared
	AddCSLuaFile("jewelry_robbery/sh_lang.lua")
	AddCSLuaFile("jewelry_robbery/shared/sh_def_config.lua")
	AddCSLuaFile("jewelry_robbery/sh_config.lua")
	
	-- AddCSLuaFile client
	AddCSLuaFile("jewelry_robbery/client/cl_jewelry_robbery.lua")
	AddCSLuaFile("jewelry_robbery/client/cl_notifications.lua")
	
	-- include server
	include("jewelry_robbery/server/sv_jewelry_robbery.lua")
	include("jewelry_robbery/server/sv_notifications.lua")


	-- Resources

	resource.AddWorkshop("1621662468")
	
elseif CLIENT then
	
	-- include client
	include("jewelry_robbery/client/cl_jewelry_robbery.lua")
	include("jewelry_robbery/client/cl_notifications.lua")

end
