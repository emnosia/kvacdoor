﻿Jewelry_Robbery.Config.Language = "fr"
Jewelry_Robbery.Config.Lang = {}

Jewelry_Robbery.Config.Lang[1] = {
	["en"] = "You have broken the alarm, the police will be adverted in",
	["fr"] = "Vous avez cassé une alarme, la police sera avertie dans",
	["ru"] = "Вы вывели сигнализацию из строя, полиция будет уведомлена через ",
}
Jewelry_Robbery.Config.Lang[2] = {
	["en"] = "You stole %s.",
	["fr"] = "Vous avez volé %s.",
	["ru"] = "Вы украли %s.",
}
Jewelry_Robbery.Config.Lang[3] = {
	["en"] = "Jewelery braking",
	["fr"] = "Braquage de bijouterie",
	["ru"] = "Витрина с драгоценностями",
}
Jewelry_Robbery.Config.Lang[4] = {
	["en"] = "A jewelery robbery has begun!",
	["fr"] = "Un braquage de bijouterie a commencé!",
	["ru"] = "Началось ограбление ювелирного!",
}
Jewelry_Robbery.Config.Lang[5] = {
	["en"] = "Break the glass !",
	["fr"] = "Cassez la vitre !",
	["ru"] = "Разбейте стекло !",
}
Jewelry_Robbery.Config.Lang[6] = {
	["en"] = "Time to wait",
	["fr"] = "Temps à attendre",
	["ru"] = "Нужно подождать",
}
Jewelry_Robbery.Config.Lang[7] = {
	["en"] = "You don't have enough place in your bag",
	["fr"] = "Vous n'avez pas assez de place dans votre sac",
	["ru"] = "У вас не хватает места в сумке",
}
