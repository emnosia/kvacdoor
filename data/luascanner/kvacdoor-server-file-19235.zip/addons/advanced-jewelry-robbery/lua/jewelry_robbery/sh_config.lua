﻿Jewelry_Robbery.DrawHUD = {
	["3D2D_glass_robber"] = true, -- this should be drawn? (true = yes) https://cdn.discordapp.com/attachments/471352432815898635/531095683068067840/unknown.png
	["3D2D_glass_police"] = true, -- this should be drawn? (true = yes) https://cdn.discordapp.com/attachments/471352432815898635/531097400358469633/unknown.png
	["police_icon_alarm"] = true, -- the icon which appears on the broken alarms should be drawn?
	["police_icon_glass"] = true, -- the icon which appears on the broken glass should be drawn?	
}

-- List of weapons that would damage jewelry glass. Supports Lua patterns(http://wiki.garrysmod.com/page/Patterns). For example if you want to add whole weapon base, put "weapon_base_[%w_]*".
Jewelry_Robbery.AvailableWeapons = {
	"m9k[%w_]*" --adds every M9K weapon
}