-- shared
if not NOMALUA then NOMALUA = {} end


function NOMALUA.ConsoleRender(bits)
	MsgC(unpack(bits))
end