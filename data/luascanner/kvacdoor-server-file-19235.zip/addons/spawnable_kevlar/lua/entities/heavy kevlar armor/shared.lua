DEFINE_BASECLASS( "base_gmodentity" )

ENT.PrintName		= "Heavy Kevlar Armor"
ENT.Author		    = "Reidmaster"
ENT.Information		= "Heavy Kevlar Armor"
ENT.Category		= "Kevlar Armor"

ENT.Editable		= false
ENT.Spawnable		= true
ENT.AdminOnly		= true