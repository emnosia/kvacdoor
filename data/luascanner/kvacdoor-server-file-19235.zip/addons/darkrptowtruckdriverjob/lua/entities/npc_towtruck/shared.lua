ENT.Base = "base_ai" 
ENT.Type = "ai"
ENT.PrintName = "TowTruck NPC"
ENT.Author = "Crap-Head"