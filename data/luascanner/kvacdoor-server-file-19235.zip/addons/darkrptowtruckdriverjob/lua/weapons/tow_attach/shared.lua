--[[
models/craphead_scripts/tow_truck/weapons/c_hook.mdl
models/craphead_scripts/tow_truck/weapons/w_hook.mdl

Recommended FOV 75

Sequences (30fps):
idle	ACT_VM_IDLE
use		ACT_VM_PRIMARYATTACK
draw	ACT_VM_DRAW

Hold type: melee2
--]]

if SERVER then
	AddCSLuaFile( "shared.lua" )
end

if CLIENT then
	SWEP.PrintName = CH_TowTruck.Config.Lang["Tower Equipment"][CH_TowTruck.Config.Language]
	SWEP.Slot = 3
	SWEP.SlotPos = 2
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = false
end

SWEP.Author = "Crap-Head" 
SWEP.Instructions = CH_TowTruck.Config.Lang["To tow: Park your tow truck in front of victims car.\nThen left click on the back of your tow truck.\nDo the same to un-attach vehicle again.\nTo mark towed: Right click on the vehicle to open menu."][CH_TowTruck.Config.Language]
SWEP.Category = "Crap-Head Scripts"

SWEP.ViewModelFOV = 75
SWEP.ViewModelFlip = false

SWEP.Spawnable = true
SWEP.AdminOnly = true
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

SWEP.ViewModel = "models/craphead_scripts/tow_truck/weapons/c_hook.mdl"
SWEP.WorldModel = "models/craphead_scripts/tow_truck/weapons/w_hook.mdl"

function SWEP:Initialize()
	self:SetWeaponHoldType("melee2")
end

function SWEP:Deploy()
    self:SetHoldType( "melee2" )
	self:SendWeaponAnim( ACT_VM_DRAW )
	timer.Simple( 1.5, function()
		if IsValid( self ) then
			self:SendWeaponAnim( ACT_VM_IDLE )
		end
	end )
end
function SWEP:PrimaryAttack()	
	self.Weapon:SetNextPrimaryFire( CurTime() + CH_TowTruck.Config.AttachVehicleDelay )
	
	local tr = self.Owner:GetEyeTrace()
	
	if SERVER then
		if tr.Entity:GetModel() != CH_TowTruck.Config.VehicleModel then
			DarkRP.notify( self.Owner, 1, 5, CH_TowTruck.Config.Lang["You must be looking at a tow truck to attach nearby vehicles!"][CH_TowTruck.Config.Language] )
			return 
		end
		
		local Vehicle = tr.Entity
		
		if self.Owner:IsTower() and Vehicle:GetModel() == CH_TowTruck.Config.VehicleModel then
			if !constraint.FindConstraints(Vehicle, "Rope")[1] and Vehicle.IsTowing then
				Vehicle.IsTowing = false
			end
			
			local pos = Vehicle:GetPos()
			local isClose = self.Owner:GetShootPos():Distance( pos + Vehicle:GetForward() * -133.3848 + Vehicle:GetUp() * 47.928 ) < 115
			if ( not Vehicle.LastUse or Vehicle.LastUse < CurTime() ) and isClose then
				Vehicle.LastUse = CurTime() + 2
				
				if not Vehicle.IsTowing then
					local trace = util.TraceLine( {start = pos + Vector(0, 0, 27), endpos = pos + Vehicle:GetForward() * -200 + Vector(0, 0, 27), filter = Vehicle} )
					local ent = trace.Entity
					
					if not IsValid( ent ) then
						local cars = ents.FindInBox( pos + Vehicle:GetRight() * 35 + Vehicle:GetForward() * -200, pos + Vehicle:GetRight() * -35 + Vehicle:GetUp() * 100 )
						DarkRP.notify(self.Owner, 1, 5, CH_TowTruck.Config.Lang["There is no vehicle behind the tow truck!"][CH_TowTruck.Config.Language] )
						
						for i=1, #cars do
							if cars[i] != Vehicle and cars[i]:IsVehicle() then
								ent = cars[i]
								break
							end
						end
					end
					
					if IsValid( ent ) and ent:IsVehicle() then
						if CH_TowTruck.Config.UseBlacklist then
							if table.HasValue( CH_TowTruck.Config.BlacklistedVehicles, ent:GetModel() ) then
								DarkRP.notify( self.Owner, 1, 5, CH_TowTruck.Config.Lang["You are not allowed to tow this vehicle!"][CH_TowTruck.Config.Language] )
								return
							end
						end
					
						local phys = ent:GetPhysicsObject()
						if IsValid( phys ) then
							if phys:GetMass() < 8000 then
								local carfront = ent:NearestPoint( ent:GetPos() + Vector(0, 0, 12.5) + ent:GetForward() * 200 )
								local carfronthookpos = ent:NearestPoint( ent:GetPos() + Vector(0, 0, 20) + ent:GetForward() * 115 )
								
								if carfront:Distance( pos + Vehicle:GetForward() * -133.3848 + Vehicle:GetUp() * 73.928 ) < 75 then
									self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
									
									timer.Simple( 1.3, function()
										local constraint, rope = constraint.Rope( Vehicle, ent, 0, 0, Vector(0, -133.3848, 73.9280), ent:WorldToLocal(carfronthookpos), 80, 0, 17000, 1.5, "cable/cable2", false )
										
										Vehicle.IsTowing = true
										ent:Fire( "HandBrakeOff", "", 0.5 )
										Vehicle:EmitSound( table.Random( CH_TowTruck.Config.HookAttachmentSound ), 100, math.random( 90, 110 ) )
										DarkRP.notify( self.Owner, 1, 5, CH_TowTruck.Config.Lang["Vehicle successfully attached!"][CH_TowTruck.Config.Language] )
										self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
									end )
								end
							end
						end
					end
				else
					local trace = util.TraceLine( {start = pos + Vector(0, 0, 27), endpos = pos + Vehicle:GetForward() * -200 + Vector(0, 0, 27), filter = Vehicle} )
					local ent = trace.Entity
					
					self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
					
					timer.Simple( 1.3, function()
						constraint.RemoveConstraints( Vehicle, "Rope" )
						Vehicle.IsTowing = false
						
						Vehicle:EmitSound( table.Random( CH_TowTruck.Config.HookAttachmentSound ), 100, math.random( 90, 110 ) )
						DarkRP.notify( self.Owner, 1, 5, CH_TowTruck.Config.Lang["Vehicle successfully unattached!"][CH_TowTruck.Config.Language] )
						self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
						if IsValid( ent ) then
							ent:Fire( "HandBrakeOn", "", 0.5 )
						end
					end )
				end
			end
			if isClose then
				return
			end
		end
	end
end

function SWEP:SecondaryAttack()
	self.Weapon:SetNextSecondaryFire( CurTime() + CH_TowTruck.Config.AttachVehicleDelay )
	if SERVER then
		local tr = self.Owner:GetEyeTrace()
		
		if tr.HitNonWorld then
			if SERVER then
				local vehicle = tr.Entity
				
				if self.Owner:GetPos():DistToSqr( vehicle:GetPos() ) >= 20000 then
					DarkRP.notify( self.Owner, 1, 5, CH_TowTruck.Config.Lang["You are too far away from the vehicle to open the fine menu."][CH_TowTruck.Config.Language] )
					return
				end
				
				if not vehicle:getDoorOwner() then
					DarkRP.notify( self.Owner, 1, 5, CH_TowTruck.Config.Lang["This vehicle has no owner!"][CH_TowTruck.Config.Language] )
					return 
				end
				
				net.Start("TOW_WarnOwner", self.Owner)
					net.WriteString( vehicle:getDoorOwner():Nick() )
					net.WriteString( vehicle:getDoorOwner():SteamID() )
					net.WriteEntity( vehicle )
				net.Send( self.Owner )
			end
		end
	end
end