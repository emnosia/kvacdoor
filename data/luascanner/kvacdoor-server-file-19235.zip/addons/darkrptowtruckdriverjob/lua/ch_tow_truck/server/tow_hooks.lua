function TOW_InitialieScript()
	timer.Simple( 5, function()
		TOW_TruckNPC_Spawn()
	end )
end
hook.Add( "InitPostEntity", "TOW_InitialieScript", TOW_InitialieScript )

function TOW_PlayerEnteredVehicle( ply, vehicle )
	if vehicle:GetModel() == CH_TowTruck.Config.VehicleModel then
		DarkRP.notify( ply, 1, 15, CH_TowTruck.Config.Lang["Back up in front of vehicles and press RIGHT MOUSE to attach/unattach the hook."][CH_TowTruck.Config.Language] )
	end

	if vehicle.HasBeenTowed then
		DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["This vehicle has an unpaid fine. Pay the fine to access the vehicle!"][CH_TowTruck.Config.Language] )
		ply:ExitVehicle()
		
		net.Start( "TOW_PayTowFine", ply )
		net.WriteDouble( vehicle.TowFine )
		net.WriteEntity( vehicle )
	net.Send( ply )
	end
end
hook.Add( "PlayerEnteredVehicle", "TOW_PlayerEnteredVehicle", TOW_PlayerEnteredVehicle )

function TOW_TowVehicleFromTruck( ply, key )
	local Vehicle = ply:GetVehicle()
	
	if ply:InVehicle() and Vehicle:GetClass() == "prop_vehicle_jeep" then
		if Vehicle:GetModel() == CH_TowTruck.Config.VehicleModel then
			if key == CH_TowTruck.Config.InTruckAttachButton then
				if ply:IsTower() then
					if !constraint.FindConstraints(Vehicle, "Rope")[1] and Vehicle.IsTowing then
						Vehicle.IsTowing = false
					end
					
					local pos = Vehicle:GetPos()
					local isClose = ply:GetShootPos():Distance( pos + Vehicle:GetForward() * -133.3848 + Vehicle:GetUp() * 47.928 ) < 152
					
					if ( not Vehicle.LastUse or Vehicle.LastUse < CurTime() ) and isClose then
						
						Vehicle.LastUse = CurTime() + 2
						
						if not Vehicle.IsTowing then
							local trace = util.TraceLine( {start = pos + Vector(0, 0, 27), endpos = pos + Vehicle:GetForward() * -200 + Vector(0, 0, 27), filter = Vehicle} )
							local ent = trace.Entity
							
							if not IsValid( ent ) then
								local cars = ents.FindInBox( pos + Vehicle:GetRight() * 35 + Vehicle:GetForward() * -200, pos + Vehicle:GetRight() * -35 + Vehicle:GetUp() * 100 )
								DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["There is no vehicle behind the tow truck!"][CH_TowTruck.Config.Language] )
								
								for i=1, #cars do
									if cars[i] != Vehicle and cars[i]:IsVehicle() then
										ent = cars[i]
										break
									end
								end
							end
							
							if IsValid( ent ) and ent:IsVehicle() then
								if CH_TowTruck.Config.UseBlacklist then
									if table.HasValue( CH_TowTruck.Config.BlacklistedVehicles, ent:GetModel() ) then
										DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["You are not allowed to tow this vehicle!"][CH_TowTruck.Config.Language] )
										return
									end
								end
							
								local phys = ent:GetPhysicsObject()
								if IsValid( phys ) then
									if phys:GetMass() < 8000 then
										local carfront = ent:NearestPoint( ent:GetPos() + Vector(0, 0, 12.5) + ent:GetForward() * 500 )
										if carfront:Distance( pos + Vehicle:GetForward() * -133.3848 + Vehicle:GetUp() * 73.928 ) < 75 then
											local constraint, rope = constraint.Rope( Vehicle, ent, 0, 0, Vector(0, -133.3848, 73.9280), ent:WorldToLocal(carfront), 60, 0, 17000, 1.5, "cable/cable2", false )
											Vehicle.IsTowing = true
											ent:Fire( "HandBrakeOff", "", 0.5 )
											DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["Vehicle successfully attached!"][CH_TowTruck.Config.Language] )
										end
									end
								end
							end
						else
							local trace = util.TraceLine( {start = pos + Vector(0, 0, 27), endpos = pos + Vehicle:GetForward() * -200 + Vector(0, 0, 27), filter = Vehicle} )
							local ent = trace.Entity
							
							if IsValid( ent ) and ent:IsVehicle() then
								constraint.RemoveConstraints( Vehicle, "Rope" )
								Vehicle.IsTowing = false
								ent:Fire( "HandBrakeOn", "", 0.5 )
								DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["Vehicle successfully unattached!"][CH_TowTruck.Config.Language] )
							end
						end
					end
					if isClose then
						return
					end
				end
			end
		end
	end
end
hook.Add("KeyPress", "TOW_TowVehicleFromTruck", TOW_TowVehicleFromTruck)

function TOWTRUCK_Disconnect( ply )
	if ply.HasTowTruck then
		for _, ent in pairs( ents.GetAll() ) do
			if ent:GetModel() == CH_TowTruck.Config.VehicleModel then
				if ent:GetNWInt( "Owner" ) == ply:EntIndex() then
					ent:Remove()
				end
			end
		end
	end
end
hook.Add( "PlayerDisconnected", "TOWTRUCK_Disconnect", TOWTRUCK_Disconnect )

function TOWTRUCK_JobChange( ply, before, after )
	if not ply:IsTower() then
		if ply.HasTowTruck then
			for _, ent in pairs( ents.FindByClass( "prop_vehicle_jeep" ) ) do
				if ent:GetNWInt("Owner") == ply:EntIndex() then
					if IsValid( ent ) then
						ent:Remove()
					end
				end
			end
		end
	end
end
hook.Add( "OnPlayerChangedTeam", "TOWTRUCK_JobChange", TOWTRUCK_JobChange )

function TOWTRUCK_CustomExit( ply, vehicle )
	if vehicle:GetModel() == CH_TowTruck.Config.VehicleModel then
		ply:SetPos( vehicle:GetPos() + Vector( -90, 125, 20 ) )
	end
end
hook.Add( "PlayerLeaveVehicle", "TOWTRUCK_CustomExit", TOWTRUCK_CustomExit )

local function TOWTRUCK_RespawnEntCleanup()
	print( "[TOW TRUCK] - Map cleaned up. Respawning the tow truck npc..." )

	timer.Simple( 1, function()
		TOW_TruckNPC_Spawn()
	end )
end
hook.Add( "PostCleanupMap", "TOWTRUCK_RespawnEntCleanup", TOWTRUCK_RespawnEntCleanup )