util.AddNetworkString( "TOW_WarnOwner" )
util.AddNetworkString( "TOW_TowTruck_Menu" )
util.AddNetworkString( "TOWCL_PlaceFine" )
util.AddNetworkString( "TOW_PayTowFine" )
util.AddNetworkString( "TOWTRUCK_RemoveTowTruck" )

local PMETA = FindMetaTable( "Player" )
local CurTowTrucks = 0

local function TOW_TowTruck_Position( ply )
	if not file.Exists( "craphead_scripts/tow_system/".. string.lower(game.GetMap()) .."/towtruck_location.txt", "DATA" ) then
		file.Write( "craphead_scripts/tow_system/".. string.lower(game.GetMap()) .."/towtruck_location.txt", "0;-0;-0;0;0;0", "DATA" )
	end
	
	if ply:IsAdmin() then
		local HisVector = string.Explode( " ", tostring( ply:GetPos() ) )
		local HisAngles = string.Explode( " ", tostring( ply:GetAngles() ) )
		
		file.Write( "craphead_scripts/tow_system/".. string.lower( game.GetMap() ) .."/towtruck_location.txt", ""..(HisVector[1])..";"..(HisVector[2])..";"..(HisVector[3])..";"..(HisAngles[1])..";"..(HisAngles[2])..";"..(HisAngles[3]).."", "DATA")
		ply:ChatPrint( CH_TowTruck.Config.Lang["New position for the tow truck has been successfully set. The new position is now in effect!"][CH_TowTruck.Config.Language] )
	else
		ply:ChatPrint( CH_TowTruck.Config.Lang["Only administrators can perform this action!"][CH_TowTruck.Config.Language] )
	end
end
concommand.Add( "towtruck_setpos", TOW_TowTruck_Position )

function PMETA:IsTower()
	return CH_TowTruck.Config.TowTruckTeams[ self:Team() ] or false
end

function DEV_CheckIfTower( ply )
	print( ply:IsTower() )
end
concommand.Add( "check_tower", DEV_CheckIfTower )

util.AddNetworkString( "TowTruck_CreateTowTruck" )
net.Receive( "TowTruck_CreateTowTruck", function( length, ply )
	if not ply:IsTower() then
		DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["You are not allowed to do this as a"][CH_TowTruck.Config.Language] .. " ".. team.GetName( ply:Team() ) .."!" )
		return
	end
	
	if ply.HasTowTruck then
		DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["You already own a tow truck!"][CH_TowTruck.Config.Language] )
		return
	end
	
	if CurTowTrucks == CH_TowTruck.Config.MaxTrucks then
		DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["The limitation of maximum tow trucks has been reached!"][CH_TowTruck.Config.Language] )
		return
	end
	
	DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["You have successfully retrieved a tow truck!"][CH_TowTruck.Config.Language] )
	
	local PositionFile = file.Read("craphead_scripts/tow_system/".. string.lower(game.GetMap()) .."/towtruck_location.txt", "DATA")
	local ThePosition = string.Explode( ";", PositionFile )
	local TheVector = Vector(ThePosition[1], ThePosition[2], ThePosition[3])
	local TheAngle = Angle(tonumber(ThePosition[4]), ThePosition[5], ThePosition[6])

	local TowTruck = ents.Create( "prop_vehicle_jeep" )
	TowTruck:SetKeyValue( "vehiclescript", CH_TowTruck.Config.VehicleScript )
	TowTruck:SetPos( TheVector )
	TowTruck:SetAngles( TheAngle )
	TowTruck:SetRenderMode(RENDERMODE_TRANSADDFRAMEBLEND)
	TowTruck:SetModel( CH_TowTruck.Config.VehicleModel )
	TowTruck:Spawn()
	TowTruck:Activate()
	TowTruck:SetNWInt( "Owner", ply:EntIndex() ) 
	TowTruck:SetHealth( CH_TowTruck.Config.Health )
	TowTruck:keysOwn( ply )
	TowTruck.PhysgunPickup = false
	
	ply.HasTowTruck = true
	CurTowTrucks = CurTowTrucks + 1
end )

net.Receive( "TOWTRUCK_RemoveTowTruck", function( length, ply) 
	if not ply:IsTower() then
		DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["You are not allowed to do this as a"][CH_TowTruck.Config.Language] .." ".. team.GetName( ply:Team() ) .."!" )
		return
	end
	
	if ply.HasTowTruck then
		for k, ent in pairs( ents.GetAll() ) do
			if ent:GetModel() == CH_TowTruck.Config.VehicleModel then
				if ent:GetNWInt( "Owner") == ply:EntIndex() then
					ent:Remove()
					DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["Your tow truck has been removed!"][CH_TowTruck.Config.Language] )
				end
			end
		end
	else
		DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["You don't have a tow truck!"][CH_TowTruck.Config.Language] )
	end
end )

util.AddNetworkString( "TOW_SubmitWarning" )
net.Receive( "TOW_SubmitWarning", function(length, ply)
	local PlayerToWarn = net.ReadString()
	local TowFine = math.Clamp( net.ReadDouble(), 0, CH_TowTruck.Config.MaxFine )
	local Tower = ply
	local Vehicle = net.ReadEntity()
	local doorData = Vehicle:getDoorData()
	
	if TowFine < 0 then
		return
	end
	
	if not ply:IsTower() then
		DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["You are not allowed to do this as a"][CH_TowTruck.Config.Language] .." ".. team.GetName( ply:Team() ) .."!" )
		return
	end
	
	if Tower:GetPos():DistToSqr( Vehicle:GetPos() ) >= 20000 then
		DarkRP.notify( Tower, 1, 5, CH_TowTruck.Config.Lang["You are too far away from the vehicle to place a fine."][CH_TowTruck.Config.Language] )
		return
	end
	
	for k, v in pairs( player.GetAll() ) do
		if v:SteamID() == PlayerToWarn then
			if Vehicle.HasBeenTowed then
				DarkRP.notify( Tower, 1, 5, CH_TowTruck.Config.Lang["This vehicle has already been marked as successfully towed."][CH_TowTruck.Config.Language] )
				return
			end
			
			if Player( doorData.owner ):SteamID() == Tower:SteamID() then
				DarkRP.notify( Tower, 1, 5, CH_TowTruck.Config.Lang["It's not possible to fine your own vehicle!"][CH_TowTruck.Config.Language] )
				return
			end
			
			DarkRP.notify( v, 1, 5, CH_TowTruck.Config.Lang["Your vehicle has been towed."][CH_TowTruck.Config.Language] )
			if TowFine == 0 then
				DarkRP.notify( v, 1, 5, CH_TowTruck.Config.Lang["You can pick it up free of charge."][CH_TowTruck.Config.Language] )
			else
				DarkRP.notify( v, 1, 5, CH_TowTruck.Config.Lang["You can pick it up for"][CH_TowTruck.Config.Language] .." ".. DarkRP.formatMoney( TowFine ) )
			end
			DarkRP.notify( v, 1, 5, CH_TowTruck.Config.Lang["The location of your vehicle has been marked on the map!"][CH_TowTruck.Config.Language] )
			
			Vehicle.HasBeenTowed = true
			Vehicle.TowFine = TowFine
			Vehicle.OriginalTower = Tower
			
			net.Start("TOWCL_PlaceFine", Player( doorData.owner ))
				net.WriteEntity( Vehicle )
				net.WriteString( Player( doorData.owner ):SteamID() )
				net.WriteDouble( TowFine )
			net.Send( Player( doorData.owner ) )
		end
	end
end )

util.AddNetworkString( "TOW_PayTheFine" )
net.Receive( "TOW_PayTheFine", function(length, ply)
	local Vehicle = net.ReadEntity()
	local original_tower = Vehicle.OriginalTower
	
	local tow_fine = tonumber( Vehicle.TowFine )
	
	if tow_fine < 0 then
		return
	end
	
	if ply:getDarkRPVar("money") >= tow_fine then
		ply:addMoney( tow_fine * -1 )
		
		if IsValid( original_tower ) then
			original_tower:addMoney( tow_fine )
			DarkRP.notify( original_tower, 1, 5, ply:Nick().. " ".. CH_TowTruck.Config.Lang["has paid a fine of"][CH_TowTruck.Config.Language] .." ".. DarkRP.formatMoney( tow_fine ) )
			DarkRP.notify( original_tower, 1, 5, CH_TowTruck.Config.Lang["The money has been added to your wallet."][CH_TowTruck.Config.Language] )
		end
		
		if CH_TowTruck.Config.UsingMayorSystem then -- Using my mayor system and enabled in config
			MAYOR_EarnMoney( ( tow_fine / 100 ) * CH_TowTruck.Config.PercentageToMayor )
		end
	else
		DarkRP.notify(ply, 1, 5, CH_TowTruck.Config.Lang["You cannot afford to pay your tow fine of"][CH_TowTruck.Config.Language] .." ".. DarkRP.formatMoney( tow_fine ) )
		return
	end
	DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["You have paid your tow fine of"][CH_TowTruck.Config.Language] .." ".. DarkRP.formatMoney( tow_fine ) )
	DarkRP.notify( ply, 1, 5, CH_TowTruck.Config.Lang["Your vehicle is now usable again."][CH_TowTruck.Config.Language] )
	
	Vehicle.HasBeenTowed = false
	Vehicle.TowFine = -1
	Vehicle.OriginalTower = nil
	
	net.Start( "TOWCL_PlaceFine", ply )
		net.WriteEntity( Vehicle )
		net.WriteString( "n/a" )
		net.WriteDouble( "0" )
	net.Send( ply )
end )

function TOWTRUCK_JobChangeRemove( ent )
	if ent:GetModel() == CH_TowTruck.Config.VehicleModel then
		local towtruck_owner = player.GetByID( ent:GetNWInt( "Owner" ) )
		
		towtruck_owner.HasTowTruck = false
		CurTowTrucks = CurTowTrucks - 1
	end
end
hook.Add( "EntityRemoved", "TOWTRUCK_JobChangeRemove", TOWTRUCK_JobChangeRemove )