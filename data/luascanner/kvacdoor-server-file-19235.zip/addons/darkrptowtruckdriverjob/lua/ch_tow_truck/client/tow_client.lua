surface.CreateFont("ArrestFont", {
	font = "Tahoma", 
	size = ScreenScale( 6.5 ), 
	weight = ScreenScale( 250 )
})

surface.CreateFont("Trebuchet20", {
	font = "Trebuchet MS", 
	size = ScreenScale( 7.3 ), 
	weight = ScreenScale( 300 )
})

surface.CreateFont("Trebuchet22", {
	font = "Trebuchet MS", 
	size = ScreenScale( 7.3 ), 
	weight = ScreenScale( 300 )
})

surface.CreateFont("CentralFontLarge", {
	font = "Tahoma", 
	size = ScreenScale( 10 ), 
	weight = ScreenScale( 200 )
})

net.Receive( "TOW_TowTruck_Menu", function()
	local GUI_Truck_Frame = vgui.Create( "DFrame" )
	GUI_Truck_Frame:SetTitle("")
	GUI_Truck_Frame:SetSize( ScreenScale( 300 ), ScreenScale( 80 ) )
	GUI_Truck_Frame:Center()
	GUI_Truck_Frame:SetDraggable( false )
	GUI_Truck_Frame.Paint = function(self)
		draw.RoundedBox( 0, 5, 5, self:GetWide() - 10, self:GetTall() - 10, Color( 42, 42, 42, 200 ) )
		draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 100 ) )
		
		-- draw.RoundedBox( 0, 25, 25, ScreenScale( 285 ), ScreenScale( 65 ), Color( 42, 42, 42, 100 ) )
	end
	GUI_Truck_Frame:MakePopup()
	GUI_Truck_Frame:ShowCloseButton( false )
	
	
	local GUI_Main_Exit = vgui.Create("DButton")
	GUI_Main_Exit:SetParent(GUI_Truck_Frame)
	GUI_Main_Exit:SetSize( ScreenScale( 5.3 ), ScreenScale( 5.3 ) )
	GUI_Main_Exit:SetPos( ScreenScale( 292 ), ScreenScale( 3 ) )
	GUI_Main_Exit:SetText("")
	GUI_Main_Exit.Paint = function()
	surface.SetMaterial(Material("icon16/cross.png"))
	surface.SetDrawColor(200,200,0,200)
	surface.DrawTexturedRect(0,0,GUI_Main_Exit:GetWide(),GUI_Main_Exit:GetTall())
	end
	GUI_Main_Exit.DoClick = function()
		GUI_Truck_Frame:Remove()
	end
	
	local VehIcon = vgui.Create( "DModelPanel", GUI_Truck_Frame )
	VehIcon:SetPos( -130, ScreenScale( 8 ) )
	VehIcon:SetSize( ScreenScale( 200 ), ScreenScale( 65 ) )
	VehIcon:SetModel( CH_TowTruck.Config.VehicleModel )
	VehIcon:GetEntity():SetAngles( Angle( -10, -5, 16 ) )
	
	local mn, mx = VehIcon.Entity:GetRenderBounds()
	local size = 0
		
	size = math.max( size, math.abs( mn.x ) + math.abs( mx.x ) )
	size = math.max( size, math.abs( mn.y ) + math.abs( mx.y ) )
	size = math.max( size, math.abs( mn.z ) + math.abs( mx.z ) )
	VehIcon:SetFOV( 55 )
	VehIcon:SetCamPos( Vector( size, size, size ) )
	VehIcon:SetLookAt( (mn + mx) * 0.5 )
	function VehIcon:LayoutEntity( Entity ) return end
	
	
	local VehName = vgui.Create( "DLabel", GUI_Truck_Frame )
	VehName:SetPos( ScreenScale( 162.5 ), ScreenScale( 15 ) )
	VehName:SetFont( "CentralFontLarge" )
	VehName:SetColor( Color( 255, 255, 255, 255 ) )
	VehName:SetText( "Tow Truck Central" )
	VehName:SizeToContents()
			
	local VehUnderline = vgui.Create( "DPanel", GUI_Truck_Frame )
	VehUnderline:SetPos( ScreenScale( 162.5 ), ScreenScale( 27 ) )
	VehUnderline:SetSize( ScreenScale( 74 ), ScreenScale( 1.7 ) )
	VehUnderline.Paint = function()
		draw.RoundedBoxEx(0,1,1,VehUnderline:GetWide()-2,VehUnderline:GetTall()-2,Color( 200, 200, 200, 230 ), false, false, false, false)
	end
	
	local VehUnderline2 = vgui.Create( "DPanel", GUI_Truck_Frame )
	VehUnderline2:SetPos( ScreenScale( 162.5 ), ScreenScale( 55 ) )
	VehUnderline2:SetSize( ScreenScale( 74 ), ScreenScale( 1.7 ) )
	VehUnderline2.Paint = function()
		draw.RoundedBoxEx(0,1,1,VehUnderline2:GetWide()-2,VehUnderline2:GetTall()-2,Color( 200, 200, 200, 230 ), false, false, false, false)
	end
			
	local VehDesc = vgui.Create( "DLabel", GUI_Truck_Frame )
	VehDesc:SetPos( ScreenScale( 132.5 ), ScreenScale( 30 ) )
	VehDesc:SetFont( "Trebuchet22" )
	VehDesc:SetColor( Color( 230, 230, 230, 230 ) )
	VehDesc:SetText( "As a tow truck driver you can retrieve a tow truck here.\nYou can park in front of a vehicle and use the tow attach\nweapon to attach vehicles to the hook of your tow truck." )
	VehDesc:SizeToContents()
	
	local VehRetrieveTruck = vgui.Create( "DButton", GUI_Truck_Frame )
	VehRetrieveTruck:SetPos( ScreenScale( 130 ), ScreenScale( 60 ) )
	VehRetrieveTruck:SetSize( ScreenScale( 66.6 ), ScreenScale( 10 ) )
	VehRetrieveTruck:SetText("")
	VehRetrieveTruck.Paint = function()
	surface.SetDrawColor(60, 60, 60, 80)
	surface.DrawRect(0, 0, VehRetrieveTruck:GetWide(), VehRetrieveTruck:GetTall())

	surface.SetDrawColor(0,0,0,255)
	surface.DrawOutlinedRect(0, 0, VehRetrieveTruck:GetWide(), VehRetrieveTruck:GetTall())

	local struc = {}
	struc.pos = {}
	struc.pos[1] = ScreenScale( 33.3 )  
	struc.pos[2] = ScreenScale( 5 )
	struc.color = Color( 255, 255, 255, 255 )
	struc.text = "Retrieve Tow Truck" 
	struc.font = "Trebuchet22"
	struc.xalign = TEXT_ALIGN_CENTER
	struc.yalign = TEXT_ALIGN_CENTER
	draw.Text( struc )
	end
	VehRetrieveTruck.DoClick = function()
		net.Start("TowTruck_CreateTowTruck")
		net.SendToServer()
		
		GUI_Truck_Frame:Remove()
	end
	
	local VehRemoveTruck = vgui.Create( "DButton", GUI_Truck_Frame )
	VehRemoveTruck:SetPos( ScreenScale( 200 ), ScreenScale( 60 ) )
	VehRemoveTruck:SetSize( ScreenScale( 66.6 ), ScreenScale( 10 ) )
	VehRemoveTruck:SetText("")
	VehRemoveTruck.Paint = function()
	surface.SetDrawColor(60, 60, 60, 80)
	surface.DrawRect(0, 0, VehRemoveTruck:GetWide(), VehRemoveTruck:GetTall())

	surface.SetDrawColor(0,0,0,255)
	surface.DrawOutlinedRect(0, 0, VehRemoveTruck:GetWide(), VehRemoveTruck:GetTall())

	local struc = {}
	struc.pos = {}
	struc.pos[1] = ScreenScale( 33.3 )  
	struc.pos[2] = ScreenScale( 5 )
	struc.color = Color( 255, 255, 255, 255 )
	struc.text = "Remove Tow Truck" 
	struc.font = "Trebuchet22"
	struc.xalign = TEXT_ALIGN_CENTER
	struc.yalign = TEXT_ALIGN_CENTER
	draw.Text( struc )
	end
	VehRemoveTruck.DoClick = function()
		net.Start("TOWTRUCK_RemoveTowTruck")
		net.SendToServer()
		
		GUI_Truck_Frame:Remove()
	end
end)

net.Receive( "TOW_WarnOwner", function()
	local VehicleOwnerName = net.ReadString()
	local VehicleOwner = net.ReadString()
	local TheVehicle = net.ReadEntity()

	if GUI_TowWarn_Frame then 
		if GUI_TowWarn_Frame:IsValid() then 
			return false 
		end 
	end

	GUI_TowWarn_Frame = vgui.Create( "DFrame" )
	GUI_TowWarn_Frame:SetTitle( "" )
	GUI_TowWarn_Frame:SetSize( ScreenScale( 100 ), ScreenScale( 70 ) )
	GUI_TowWarn_Frame:Center()
	GUI_TowWarn_Frame.Paint = function(self)
		draw.RoundedBox( 0, 5, 5, self:GetWide() - 10, self:GetTall() - 10, Color( 42, 42, 42, 200 ) )
		draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 100 ) )

		-- Draw the top title.
		draw.SimpleText("Vehicle Impound", "ArrestFont", ScreenScale( 27 ), 17.5, Color( 255, 255, 255, 200 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	GUI_TowWarn_Frame:MakePopup()
	GUI_TowWarn_Frame:ShowCloseButton( false )

	local TOW_ExitMenu = vgui.Create("DButton", GUI_TowWarn_Frame)
	TOW_ExitMenu:SetSize( ScreenScale( 5.3 ), ScreenScale( 5.3 ) )
	TOW_ExitMenu:SetPos( ScreenScale( 92 ), ScreenScale( 3 ) )
	TOW_ExitMenu:SetText("")
	TOW_ExitMenu.Paint = function()
		surface.SetMaterial(Material("icon16/cross.png"))
		surface.SetDrawColor(200,200,0,200)
		surface.DrawTexturedRect(0,0,TOW_ExitMenu:GetWide(),TOW_ExitMenu:GetTall())
	end
	TOW_ExitMenu.DoClick = function()
		GUI_TowWarn_Frame:Remove()
	end		

	local TOW_VehicleOwner = vgui.Create( "DLabel", GUI_TowWarn_Frame )
	TOW_VehicleOwner:SetFont("ArrestFont")
	TOW_VehicleOwner:SetText( "Vehicle Owner" )
	TOW_VehicleOwner:SetPos( ScreenScale( 30 ), ScreenScale( 15 ) )
	TOW_VehicleOwner:SizeToContents()
	
	local GUI_Sender_Entry = vgui.Create("DTextEntry", GUI_TowWarn_Frame)
	GUI_Sender_Entry:SetText(VehicleOwnerName)
	GUI_Sender_Entry:SetEditable(false)
	GUI_Sender_Entry:SetFont("Trebuchet18")
	GUI_Sender_Entry:SetSize( 200, 25 )
	GUI_Sender_Entry:SetPos( ScreenScale( 17.5 ), ScreenScale( 22 ) )
	
	local TOW_FineAmount = vgui.Create( "DLabel", GUI_TowWarn_Frame )
	TOW_FineAmount:SetFont("ArrestFont")
	TOW_FineAmount:SetText( "Tow Fine" )
	TOW_FineAmount:SetPos( ScreenScale( 37.5 ), ScreenScale( 35.5 ) )
	TOW_FineAmount:SizeToContents()

	local GUI_Fine_Entry = vgui.Create("DTextEntry", GUI_TowWarn_Frame)
	GUI_Fine_Entry:SetText("0")
	GUI_Fine_Entry:SetFont("Trebuchet18")
	GUI_Fine_Entry:SetNumeric( true )
	GUI_Fine_Entry:SetSize( 200, 25 )
	GUI_Fine_Entry:SetPos( ScreenScale( 17.5 ), ScreenScale( 42.5 ) )
	
	local GUI_ReplyButton = vgui.Create("DButton")
	GUI_ReplyButton:SetParent(GUI_TowWarn_Frame)
	GUI_ReplyButton:SetPos( ScreenScale( 25 ), ScreenScale( 55 ) )
	GUI_ReplyButton:SetSize( ScreenScale( 50 ), ScreenScale( 8 ) )
	GUI_ReplyButton:SetTextColor( Color( 0, 0, 0, 255 ) )
	GUI_ReplyButton:SetText("")
	GUI_ReplyButton.DoClick = function()
		if tonumber(GUI_Fine_Entry:GetValue()) < 0 then
			LocalPlayer():ChatPrint("Please enter positive value!")
			return
		end
		
		if GUI_Fine_Entry:GetValue() == "" then
			LocalPlayer():ChatPrint("Please enter a price for the fine!")
			return
		end
	
		net.Start("TOW_SubmitWarning")
			net.WriteString( VehicleOwner )
			net.WriteDouble( math.Clamp( tonumber( GUI_Fine_Entry:GetValue() ), 0, CH_TowTruck.Config.MaxFine ) )
			net.WriteEntity( TheVehicle )
		net.SendToServer()

		GUI_TowWarn_Frame:Remove()
	end
	GUI_ReplyButton.Paint = function( self )
		surface.SetDrawColor(60, 60, 60, 80)
		surface.DrawRect(0, 0, self:GetWide(), self:GetTall())

		surface.SetDrawColor(0,0,0,220)
		surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())

		local struc = {}
		struc.pos = {}
		struc.pos[1] = ScreenScale( 25 )  
		struc.pos[2] = ScreenScale( 4 )
		struc.color = Color( 255, 255, 255, 255 )
		struc.text = "Confirm Tow Fine" 
		struc.font = "Trebuchet22"
		struc.xalign = TEXT_ALIGN_CENTER
		struc.yalign = TEXT_ALIGN_CENTER
		draw.Text( struc )
	end
end)

net.Receive( "TOW_PayTowFine", function()
	local FinePrice = net.ReadDouble()
	local TheVehicle = net.ReadEntity()

	if GUI_TowFine_Frame then 
		if GUI_TowFine_Frame:IsValid() then 
			return false 
		end 
	end

	GUI_TowFine_Frame = vgui.Create( "DFrame" )
	GUI_TowFine_Frame:SetTitle("")
	GUI_TowFine_Frame:SetSize( ScreenScale( 100 ), ScreenScale( 50 ) )
	GUI_TowFine_Frame:Center()
	GUI_TowFine_Frame.Paint = function(self)
		draw.RoundedBox( 0, 5, 5, self:GetWide() - 10, self:GetTall() - 10, Color( 42, 42, 42, 200 ) )
		draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 100 ) )

		-- Draw the top title.
		draw.SimpleText("Tow Fine", "ArrestFont", 55, 17.5, Color( 255, 255, 255, 200 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	GUI_TowFine_Frame:MakePopup()
	GUI_TowFine_Frame:ShowCloseButton( false )
	
	local TOW_VehicleIsTowed = vgui.Create( "DLabel", GUI_TowFine_Frame )
	TOW_VehicleIsTowed:SetFont("ArrestFont")
	TOW_VehicleIsTowed:SetText( "Your vehicle has been towed" )
	TOW_VehicleIsTowed:SetPos( ScreenScale( 12.5 ), ScreenScale( 13 ) )
	TOW_VehicleIsTowed:SizeToContents()
	
	local TOW_TowingPrice = vgui.Create( "DLabel", GUI_TowFine_Frame )
	TOW_TowingPrice:SetFont("ArrestFont")
	TOW_TowingPrice:SetText( "Towing Fine: ".. DarkRP.formatMoney( FinePrice ) )
	TOW_TowingPrice:SetPos( ScreenScale( 25 ), ScreenScale( 22.5 ) )
	TOW_TowingPrice:SizeToContents()
	
	local AS_ArrestBail = vgui.Create("DButton", GUI_TowFine_Frame)	
	AS_ArrestBail:SetSize( ScreenScale( 44 ), ScreenScale( 9 ) )
	AS_ArrestBail:SetPos( ScreenScale( 5 ), ScreenScale( 32.5 ) )
	AS_ArrestBail:SetText("")
	AS_ArrestBail.Paint = function(self)
		surface.SetDrawColor(60, 60, 60, 80)
		surface.DrawRect(0, 0, self:GetWide(), self:GetTall())

		surface.SetDrawColor(0,0,0,220)
		surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())

		local struc = {}
		struc.pos = {}
		struc.pos[1] = ScreenScale( 22 )  
		struc.pos[2] = ScreenScale( 4.5 )
		struc.color = Color( 255, 255, 255, 255 )
		struc.text = "Pay ".. DarkRP.formatMoney( FinePrice )
		struc.font = "Trebuchet22"
		struc.xalign = TEXT_ALIGN_CENTER
		struc.yalign = TEXT_ALIGN_CENTER
		draw.Text( struc )
	end
	
	AS_ArrestBail.DoClick = function()
		net.Start("TOW_PayTheFine")
			net.WriteEntity( TheVehicle )
		net.SendToServer()
		
		GUI_TowFine_Frame:Remove()
	end
	
	local AS_BailExit = vgui.Create("DButton", GUI_TowFine_Frame)	
	AS_BailExit:SetSize( ScreenScale( 44 ), ScreenScale( 9 ) )
	AS_BailExit:SetPos( ScreenScale( 51.5 ), ScreenScale( 32.5 ) )
	AS_BailExit:SetText("")
	AS_BailExit.Paint = function(self)
		surface.SetDrawColor(60, 60, 60, 80)
		surface.DrawRect(0, 0, self:GetWide(), self:GetTall())

		surface.SetDrawColor(0,0,0,220)
		surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())

		local struc = {}
		struc.pos = {}
		struc.pos[1] = ScreenScale( 22 )  
		struc.pos[2] = ScreenScale( 4.5 )
		struc.color = Color( 255, 255, 255, 255 )
		struc.text = "Don't Pay" 
		struc.font = "Trebuchet22"
		struc.xalign = TEXT_ALIGN_CENTER
		struc.yalign = TEXT_ALIGN_CENTER
		draw.Text( struc )
	end
	
	AS_BailExit.DoClick = function()
		GUI_TowFine_Frame:Remove()
	end
end)

net.Receive( "TOWCL_PlaceFine", function()
	TheVehicle = net.ReadEntity()
	TheVehicle.TheOwner = net.ReadString()
	TheVehicle.TheFine = net.ReadDouble()
end)

local vehtowed_text = "Vehicle Towed"
local col_red = Color( 200, 0, 0, 200 )
local col_green = Color( 0, 200, 0, 200 )
local col_white = Color( 255, 255, 255, 200 )

function TOW_DisplayTowedVehicle()
	for _, veh in pairs( ents.FindByClass( "prop_vehicle_jeep" ) ) do
		if veh.TheOwner and veh.TheOwner == LocalPlayer():SteamID() then	
			local pos = veh:GetPos():ToScreen()
			local dis_to_car = "Distance: ".. math.Round( veh:GetPos():Distance( LocalPlayer():GetPos() ) )
			local car_fine = DarkRP.formatMoney( veh.TheFine )
				
			surface.SetFont( "Trebuchet24" )
			local x,y = surface.GetTextSize( vehtowed_text )
					
			surface.SetTextPos( pos.x - x / 2, pos.y - 40 )
			surface.SetTextColor( col_red )
			surface.DrawText( vehtowed_text )
					
			surface.SetFont( "UiBold" )
			local x,y = surface.GetTextSize( "Tow Fine: ".. car_fine )
					
			surface.SetTextPos( pos.x - x / 2, pos.y - 15 )
			surface.SetTextColor( col_green )
			surface.DrawText( "Tow Fine: ".. car_fine )
					
			local x,y = surface.GetTextSize( dis_to_car )
					
			surface.SetTextPos( pos.x - x / 2, pos.y )
			surface.SetTextColor( col_white )
			surface.DrawText( dis_to_car )
		end
	end
end
hook.Add("HUDDrawTargetID", "TOW_DisplayTowedVehicle", TOW_DisplayTowedVehicle)