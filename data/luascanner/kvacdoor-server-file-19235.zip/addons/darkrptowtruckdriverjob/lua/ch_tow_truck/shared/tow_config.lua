CH_TowTruck = CH_TowTruck or {}
CH_TowTruck.Config = CH_TowTruck.Config or {}

-- SET LANGUAGE
-- Available languages: English: en - French: fr - German: de - Danish: da
CH_TowTruck.Config.Language = "fr" -- Set the language of the script.

-- General Config
timer.Simple( 10, function()
	CH_TowTruck.Config.TowTruckTeams = { -- The DarkRP team name that defines the tow truck driver. Here we use the team we create in tow_darkrpadds.lua
		[TEAM_TOWER]=true,
	}
end )

CH_TowTruck.Config.VehicleModel = "models/sickness/towtruckdr.mdl" -- The model of the tow truck. Defaults to the tow truck from sickness models.
CH_TowTruck.Config.MaxTrucks = 2 -- Maximum amount of tow trucks allowed at one time. [Default = 2]
CH_TowTruck.Config.VehicleScript = "scripts/vehicles/tow.txt" -- The vehicle script for the tow truck. Defaults to the one from sickness models.
CH_TowTruck.Config.Health = 100 -- The health of the tow truck. This only really matters if you have a vehicle damage script [Default = 100]
CH_TowTruck.Config.NPCModel = "models/monk.mdl" -- The model of the npc to retrieve a tow truck.

CH_TowTruck.Config.AttachVehicleDelay = 1.5 -- Amount of seconds delay using the tow attach weapon (left/right clicking) 
CH_TowTruck.Config.InTruckAttachButton = IN_ATTACK2 -- The button you use from inside the truck to hook nearby cars (Default = RIGHT CLICK). Here is a full list: https://wiki.garrysmod.com/page/Enums/IN  

CH_TowTruck.Config.MaxFine = 1500 -- The maximum fine a tower can put on a vehicle. [Default = 500]

CH_TowTruck.Config.HookAttachmentSound = { -- This is a list of door knocks that will be chosen at random when knocking a door.
	"physics/metal/metal_canister_impact_hard1.wav",
	"physics/metal/metal_canister_impact_hard2.wav", -- This is the default DarkRP normally uses
	"physics/metal/metal_canister_impact_hard3.wav" -- THE LAST LINE SHOULD NOT HAVE A COMMA AT THE END. BE AWARE OF THIS WHEN EDITING THIS!
}

-- List of blacklisted vehicle models that you don't want to be tow-able.
CH_TowTruck.Config.UseBlacklist = true -- If you want the below blacklist to be enabled. Default true (enabled)

CH_TowTruck.Config.BlacklistedVehicles = {
	"models/sickness/gtabus.mdl",
	"models/sickness/evocitybus.mdl",
	"models/sickness/phantomdr.mdl",
	"models/sickness/international_2674.mdl" -- THE LAST TEAM SHOULD NOT HAVE A COMMA
}

-- Support for DarkRP Mayor System - Economy, Realistic Events & More https://www.gmodstore.com/market/view/3131
CH_TowTruck.Config.UsingMayorSystem = false -- If you own my DarkRP Mayor System you can enable this - https://www.gmodstore.com/market/view/3131
CH_TowTruck.Config.PercentageToMayor = 50 -- How many percentage of the tow fine should go to the mayor funds?