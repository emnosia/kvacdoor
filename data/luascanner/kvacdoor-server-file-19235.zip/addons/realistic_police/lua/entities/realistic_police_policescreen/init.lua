--[[
 _____            _ _     _   _        _____      _ _             _____           _                 
|  __ \          | (_)   | | (_)      |  __ \    | (_)           / ____|         | |                
| |__) |___  __ _| |_ ___| |_ _  ___  | |__) |__ | |_  ___ ___  | (___  _   _ ___| |_ ___ _ __ ___  
|  _  // _ \/ _` | | / __| __| |/ __| |  ___/ _ \| | |/ __/ _ \  \___ \| | | / __| __/ _ \ '_ ` _ \ 
| | \ \  __/ (_| | | \__ \ |_| | (__  | |  | (_) | | | (_|  __/  ____) | |_| \__ \ ||  __/ | | | | |
|_|  \_\___|\__,_|_|_|___/\__|_|\___| |_|   \___/|_|_|\___\___| |_____/ \__, |___/\__\___|_| |_| |_|
                                                                                                                                         
--]]

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")
ENT.AutomaticFrameAdvance = true 

local function GetCameras(Players)
    local Count = 0 
    for k,v in pairs(ents.FindByClass("realistic_police_camera")) do 
        if not IsValid(v:CPPIGetOwner()) then 
			if IsValid(v) then 
				Count = Count + 1
			end   
        end 
    end 
    return Count 
end 

function ENT:Initialize()
	self:SetModel( "models/props/cs_office/tv_plasma.mdl" )
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetNWInt("CameraId", 1)
	local RealisticPolicePhys = self:GetPhysicsObject()
	RealisticPolicePhys:EnableMotion(false)
	RealisticPolicePhys:Wake()
end

function ENT:Use(activator)
	if self:GetNWInt("CameraId") < GetCameras(self:CPPIGetOwner()) then 
		self:SetNWInt("CameraId", self:GetNWInt("CameraId") + 1) 
	else 
		self:SetNWInt("CameraId", 1) 
	end  
end 