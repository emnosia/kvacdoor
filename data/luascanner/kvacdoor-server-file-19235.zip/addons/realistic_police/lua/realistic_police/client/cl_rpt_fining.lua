--[[
 _____            _ _     _   _        _____      _ _             _____           _                 
|  __ \          | (_)   | | (_)      |  __ \    | (_)           / ____|         | |                
| |__) |___  __ _| |_ ___| |_ _  ___  | |__) |__ | |_  ___ ___  | (___  _   _ ___| |_ ___ _ __ ___  
|  _  // _ \/ _` | | / __| __| |/ __| |  ___/ _ \| | |/ __/ _ \  \___ \| | | / __| __/ _ \ '_ ` _ \ 
| | \ \  __/ (_| | | \__ \ |_| | (__  | |  | (_) | | | (_|  __/  ____) | |_| \__ \ ||  __/ | | | | |
|_|  \_\___|\__,_|_|_|___/\__|_|\___| |_|   \___/|_|_|\___\___| |_____/ \__, |___/\__\___|_| |_| |_|
                                                                                                                                         
--]]

local function GetAmountByName(String)
    local Amount = 0 
    for k,v in pairs(Realistic_Police.FiningPolice) do 
        if v.Name == String then 
            Amount = v.Price 
        end 
    end 
    return Amount 
end

local function GetCategory()
    local Table = {}
    for k,v in pairs(Realistic_Police.FiningPolice) do 
        if not table.HasValue(Table, v.Category) then 
            table.insert(Table, v.Category)
        end 
    end
    return Table 
end 

local function CheckedBox(Boolen)
    local Count = 0
    for k,v in pairs(Realistic_Police.FiningPolice) do 
        if v.Vehicle == Boolen then 
            if IsValid(RPTCheckbox[k]) then 
                if RPTCheckbox[k]:GetChecked() then 
                    Count = Count + 1 
                end
            end 
        end 
    end 
    return Count 
end 

function Realistic_Police.OpenFiningMenu(Boolen)
    local RpRespX, RpRespY = ScrW(), ScrH()

    local RPTValue = 0
    local RPTTarget = 300
    local speed = 10
    local RPTActivate = false 

    if IsValid(RPTFFrame) then RPTFFrame:Remove() end 

    RPTFFrame = vgui.Create("DFrame")
	RPTFFrame:SetSize(RpRespX*0.28, RpRespY*0.602)
    RPTFFrame:Center()
	RPTFFrame:ShowCloseButton(false)
	RPTFFrame:SetDraggable(false)
    RPTFFrame:MakePopup()
	RPTFFrame:SetTitle("")
    RPTFFrame.Paint = function(self,w,h)
        RPTValue = Lerp( speed * FrameTime( ), RPTValue, RPTTarget )

        surface.SetDrawColor( Color(Realistic_Police.Colors["black25"].r, Realistic_Police.Colors["black25"].g, Realistic_Police.Colors["black25"].b, RPTValue) )
        surface.DrawRect( 0, 0, w, h )

        surface.SetDrawColor( Color(Realistic_Police.Colors["black15"].r, Realistic_Police.Colors["black15"].g, Realistic_Police.Colors["black15"].b, RPTValue) )
        surface.DrawRect( 0, 0, w + 10, h*0.074 )

        surface.SetDrawColor( Realistic_Police.Colors["gray60"] )
        surface.DrawRect( RpRespX*0.005,  RpRespY*0.04, w*0.97, h*0.918 )

        surface.SetDrawColor( Realistic_Police.Colors["black15200"] )
        surface.DrawOutlinedRect( 0, 0, w, h )

        draw.DrawText(Realistic_Police.Lang[50][Realistic_Police.Langage], "rpt_font_9", RpRespX*0.005, RpRespY*0.007, Color(Realistic_Police.Colors["gray220"].r, Realistic_Police.Colors["gray220"].g, Realistic_Police.Colors["gray220"].b, RPTValue), TEXT_ALIGN_LEFT)
    end 

    local RPTScroll = vgui.Create("DScrollPanel", RPTFFrame)
    RPTScroll:SetSize(RpRespX*0.27, RpRespY*0.496)
    RPTScroll:SetPos(RpRespX*0.005, RpRespY*0.04)
    RPTScroll.Paint = function(self,w,h)
        surface.SetDrawColor( Realistic_Police.Colors["gray60"] )
        surface.DrawRect( 0, 0, w, h )
    end
    local sbar = RPTScroll:GetVBar()
    sbar:SetSize(0,0)

    RPTCheckbox = {}
    for k,v in pairs(Realistic_Police.FiningPolice) do 
        if v.Vehicle == Boolen then 
            local DButton1 = vgui.Create("DButton", RPTScroll)
            DButton1:SetSize(0,RpRespY*0.05)
            DButton1:SetText(v.Name.." ("..DarkRP.formatMoney(v.Price)..")")
            DButton1:SetFont("rpt_font_7")
            DButton1:SetTextColor(Realistic_Police.Colors["white"])
            DButton1:Dock(TOP)
            DButton1:DockMargin(0,5,0,0)
            DButton1.Paint = function(self,w,h) 
                if self:IsHovered() then 
                    surface.SetDrawColor( Realistic_Police.Colors["black25150"] )
                    surface.DrawRect( 5, 0, w-10, h )
                else 
                    surface.SetDrawColor( Realistic_Police.Colors["black25"] )
                    surface.DrawRect( 5, 0, w-10, h )
                end 
            end
            DButton1.DoClick = function()
                if RPTCheckbox[k]:GetChecked() then 
                    RPTCheckbox[k]:SetValue(false)
                else 
                    if CheckedBox(Boolen) < Realistic_Police.MaxPenalty then 
                        RPTCheckbox[k]:SetValue(true)
                    else 
                        RealisticPoliceNotify(Realistic_Police.Lang[58][Realistic_Police.Langage])
                    end 
                end 
            end 
            RPTCheckbox[k] = vgui.Create( "DCheckBox", DButton1 )
            RPTCheckbox[k]:SetPos( RpRespX*0.01, RpRespY*0.02 ) 
            RPTCheckbox[k]:SetValue( false )
            RPTCheckbox[k].OnChange = function(val)
                if CheckedBox(Boolen) > Realistic_Police.MaxPenalty then 
                    RealisticPoliceNotify(Realistic_Police.Lang[58][Realistic_Police.Langage])
                    self:SetValue( false )
                end 
            end
        end 
    end 

    local DButtonStop = vgui.Create("DComboBox", RPTFFrame)
    DButtonStop:SetSize(RpRespX*0.135, RpRespY*0.05)
    DButtonStop:SetPos(RpRespX*0.005, RpRespY*0.5375)
    DButtonStop:SetText(Realistic_Police.Lang[49][Realistic_Police.Langage])
    DButtonStop:SetFont("rpt_font_7")
    DButtonStop:SetTextColor(Realistic_Police.Colors["white"])
    DButtonStop:SetContentAlignment(5)
    DButtonStop.Paint = function(self,w,h)
        surface.SetDrawColor( Realistic_Police.Colors["black25"] )
        surface.DrawRect( 5, 0, w-10, h )
    end 
    for k,v in pairs(GetCategory()) do 
        DButtonStop:AddChoice(v)
    end 
    DButtonStop.OnSelect = function( _, _, value)
        RPTScroll:Clear()
        for k,v in pairs(Realistic_Police.FiningPolice) do 
            if v.Category == value then 
                if v.Vehicle == Boolen then 
                    local DButton1 = vgui.Create("DButton", RPTScroll)
                    DButton1:SetSize(0,RpRespY*0.05)
                    DButton1:SetText(v.Name.." ("..DarkRP.formatMoney(v.Price)..")")
                    DButton1:SetFont("rpt_font_7")
                    DButton1:SetTextColor(Realistic_Police.Colors["white"])
                    DButton1:Dock(TOP)
                    DButton1:DockMargin(0,5,0,0)
                    DButton1.Paint = function(self,w,h) 
                        if self:IsHovered() then 
                            surface.SetDrawColor( Realistic_Police.Colors["black25150"] )
                            surface.DrawRect( 5, 0, w-10, h )
                        else 
                            surface.SetDrawColor( Realistic_Police.Colors["black25"] )
                            surface.DrawRect( 5, 0, w-10, h )
                        end 
                    end
                    DButton1.DoClick = function()
                        if RPTCheckbox[k]:GetChecked() then 
                            RPTCheckbox[k]:SetValue(false)
                        else 
                            if CheckedBox(Boolen) < Realistic_Police.MaxPenalty then 
                                RPTCheckbox[k]:SetValue(true)
                            else 
                                RealisticPoliceNotify(Realistic_Police.Lang[58][Realistic_Police.Langage])
                            end 
                        end 
                    end 
                    RPTCheckbox[k] = vgui.Create( "DCheckBox", DButton1 )
                    RPTCheckbox[k]:SetPos( RpRespX*0.01, RpRespY*0.02 ) 
                    RPTCheckbox[k]:SetValue( false )
                end 
            end 
        end 
    end

    local DButtonAccept = vgui.Create("DButton", RPTFFrame)
    DButtonAccept:SetSize(RpRespX*0.135, RpRespY*0.05)
    DButtonAccept:SetPos(RpRespX*0.14, RpRespY*0.5375)
    DButtonAccept:SetText(Realistic_Police.Lang[48][Realistic_Police.Langage])
    DButtonAccept:SetFont("rpt_font_7")
    DButtonAccept:SetTextColor(Realistic_Police.Colors["white"])
    DButtonAccept.Paint = function(self,w,h)
        surface.SetDrawColor( Realistic_Police.Colors["black25"] )
        surface.DrawRect( 5, 0, w-10, h )
    end 
    DButtonAccept.DoClick = function()
        if CheckedBox(Boolen) != 0 then
            local StringToSend = ""
            for k,v in pairs(Realistic_Police.FiningPolice) do 
                if v.Vehicle == Boolen then 
                    if IsValid(RPTCheckbox[k]) then 
                        if RPTCheckbox[k]:GetChecked() then 
                            StringToSend = StringToSend.."§"..v.Name
                        end 
                    end 
                end 
            end 
            net.Start("RealisticPolice:FiningSystem")
                net.WriteString("SendFine")
                net.WriteString(StringToSend)
            net.SendToServer()
            RPTFFrame:SlideUp(0.7)
        else 
            RealisticPoliceNotify(Realistic_Police.Lang[59][Realistic_Police.Langage])
        end 
    end 

    local RPTClose = vgui.Create("DButton", RPTFFrame)
    RPTClose:SetSize(RpRespX*0.03, RpRespY*0.028)
    RPTClose:SetPos(RPTFFrame:GetWide()*0.878, RPTFFrame:GetTall()*0.0068)
    RPTClose:SetText("")
    RPTClose.Paint = function(self,w,h) 
        surface.SetDrawColor( Realistic_Police.Colors["red"] )
        surface.DrawRect( 0, 0, w, h )
    end 
    RPTClose.DoClick = function()
        RPTFFrame:Remove()
        Realistic_Police.Clic()
        net.Start("RealisticPolice:FiningSystem")
            net.WriteString("StopFine")
        net.SendToServer()
    end
end

net.Receive("RealisticPolice:FiningSystem", function()
    local Table = net.ReadTable() or {}
    local RpRespX, RpRespY = ScrW(), ScrH()

    local RPTValue = 0
    local RPTTarget = 300
    local speed = 10
    local RPTActivate = false 
    local Amount = 0 

    for k,v in pairs(Realistic_Police.FiningPolice) do 
        if table.HasValue(Table, v.Name) then 
            Amount = Amount + v.Price
        end 
    end     

    if IsValid(RPTFFrame) then RPTFFrame:Remove() end 

    RPTFFrame = vgui.Create("DFrame")
	RPTFFrame:SetSize(RpRespX*0.28, RpRespY*0.602)
    RPTFFrame:Center()
	RPTFFrame:ShowCloseButton(false)
	RPTFFrame:SetDraggable(false)
	RPTFFrame:SetTitle("")
    RPTFFrame:MakePopup()
    RPTFFrame.Paint = function(self,w,h)
        RPTValue = Lerp( speed * FrameTime( ), RPTValue, RPTTarget )
        surface.SetDrawColor( Color(Realistic_Police.Colors["black25"].r, Realistic_Police.Colors["black25"].g, Realistic_Police.Colors["black25"].b, RPTValue) )
        surface.DrawRect( 0, 0, w, h )

        surface.SetDrawColor( Color(Realistic_Police.Colors["black15"].r, Realistic_Police.Colors["black15"].g, Realistic_Police.Colors["black15"].b, RPTValue) )
        surface.DrawRect( 0, 0, w + 10, h*0.074 )

        surface.SetDrawColor( Realistic_Police.Colors["gray60"] )
        surface.DrawRect( RpRespX*0.005,  RpRespY*0.04, w*0.97, h*0.918 )

        surface.SetDrawColor( Realistic_Police.Colors["black15200"] )
        surface.DrawOutlinedRect( 0, 0, w, h )
        
        draw.DrawText(Realistic_Police.Lang[50][Realistic_Police.Langage], "rpt_font_9", RpRespX*0.005, RpRespY*0.007, Color(Realistic_Police.Colors["gray220"].r, Realistic_Police.Colors["gray220"].g, Realistic_Police.Colors["gray220"].b, RPTValue), TEXT_ALIGN_LEFT)
    end 

    local RPTScroll = vgui.Create("DScrollPanel", RPTFFrame)
    RPTScroll:SetSize(RpRespX*0.27, RpRespY*0.496)
    RPTScroll:SetPos(RpRespX*0.005, RpRespY*0.04)
    RPTScroll.Paint = function(self,w,h)
        surface.SetDrawColor( Realistic_Police.Colors["gray60"] )
        surface.DrawRect( 0, 0, w, h )
    end
    local sbar = RPTScroll:GetVBar()
    sbar:SetSize(0,0)
    local RPTCheckbox = {}
    for k,v in pairs(Table) do 
        DButton1 = vgui.Create("DButton", RPTScroll)
        DButton1:SetSize(0,RpRespY*0.05)
        DButton1:SetText(v.." ("..DarkRP.formatMoney(GetAmountByName(v))..")")
        DButton1:SetFont("rpt_font_7")
        DButton1:SetTextColor(Realistic_Police.Colors["white"])
        DButton1:Dock(TOP)
        DButton1:DockMargin(0,5,0,0)
        DButton1.Paint = function(self,w,h) 
            surface.SetDrawColor( Realistic_Police.Colors["black25"] )
            surface.DrawRect( 5, 0, w-10, h )
        end
    end 

    local DButtonBuy = vgui.Create("DButton", RPTFFrame)
    DButtonBuy:SetSize(RpRespX*0.27, RpRespY*0.05)
    DButtonBuy:SetPos(RpRespX*0.005, RpRespY*0.5375)
    DButtonBuy:SetText(Realistic_Police.Lang[47][Realistic_Police.Langage].." : "..DarkRP.formatMoney(Amount))
    DButtonBuy:SetFont("rpt_font_7")
    DButtonBuy:SetTextColor(Realistic_Police.Colors["white"])
    DButtonBuy.Paint = function(self,w,h)
        surface.SetDrawColor( Realistic_Police.Colors["green"] )
        surface.DrawRect( 5, 0, w-10, h )

        surface.SetDrawColor( Realistic_Police.Colors["green"] )
        surface.DrawOutlinedRect( 5, 0, w-10, h )
    end 
    DButtonBuy.DoClick = function() 
        if LocalPlayer():getDarkRPVar("money") >= Amount then 
            net.Start("RealisticPolice:FiningSystem")
                net.WriteString("BuyFine")
            net.SendToServer()
            RPTFFrame:SlideUp(0.7)
        else 
            RealisticPoliceNotify(Realistic_Police.Lang[46][Realistic_Police.Langage])
        end
    end     

    local RPTClose = vgui.Create("DButton", RPTFFrame)
    RPTClose:SetSize(RpRespX*0.03, RpRespY*0.028)
    RPTClose:SetPos(RPTFFrame:GetWide()*0.878, RPTFFrame:GetTall()*0.0068)
    RPTClose:SetText("")
    RPTClose.Paint = function(self,w,h) 
        surface.SetDrawColor( Realistic_Police.Colors["red"] )
        surface.DrawRect( 0, 0, w, h )
    end 
    RPTClose.DoClick = function()
        RPTFFrame:Remove()
        Realistic_Police.Clic()
        net.Start("RealisticPolice:FiningSystem")
            net.WriteString("RefuseFine")
        net.SendToServer()
    end 
end ) 
