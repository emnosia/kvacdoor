AddCSLuaFile()

SWEP.PrintName = "StunGun"
SWEP.Author = "Kobralost"
SWEP.Purpose = ""

SWEP.Slot = 0
SWEP.SlotPos = 4

SWEP.Spawnable = true

SWEP.Category = "Realistic Police"

SWEP.ViewModel = Model("models/realistic_police/taser/c_taser.mdl")
SWEP.WorldModel = Model("models/realistic_police/taser/w_taser.mdl")
SWEP.ViewModelFOV = 60
SWEP.UseHands = true

SWEP.Primary.TakeAmmo = 1 
SWEP.Primary.ClipSize = 1  
SWEP.Primary.Ammo = "Pistol" 
SWEP.Primary.DefaultClip = 100 

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.DrawAmmo = true

SWEP.HitDistance = 125

function SWEP:Deploy()
	local Owner = self:GetOwner()
	self:SendWeaponAnim( ACT_VM_DRAW )
	-- Play the idle animation next the primary attack
	timer.Create("rpt_animation"..self:GetOwner():EntIndex(), self:SequenceDuration(), 1, function()	
		if IsValid(self) && IsValid(Owner) then 		
			if Owner:GetActiveWeapon() == self then
				self:SendWeaponAnim( ACT_VM_IDLE )
			end 
		end 
	end ) 
end 

function SWEP:PrimaryAttack() 
	local Owner = self:GetOwner()
	local ply = Owner:GetEyeTrace().Entity

	Owner.AntiSpam = Owner.AntiSpam or CurTime()
	if Owner.AntiSpam > CurTime() then return end 
	Owner.AntiSpam = CurTime() + 3 
	
	-- Check if the stungun is reload 
	if self:Clip1() == 0 then return end 

	self:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
	 
	-- Play the idle animation next the primary attack
	timer.Create("rpt_animation"..self:GetOwner():EntIndex(), self:SequenceDuration(), 1, function()	
		if IsValid(self) && IsValid(Owner) then 		
			if Owner:GetActiveWeapon() == self then
				self:SendWeaponAnim( ACT_VM_IDLE )
			end 
		end 
	end ) 

	-- Play the effect data where you shoot 
	local tr = util.TraceLine(util.GetPlayerTrace( self.Owner ))

	local effect = EffectData()
	effect:SetOrigin( tr.HitPos )
	effect:SetStart( self.Owner:GetShootPos() )
	effect:SetAttachment( 1 )
	effect:SetEntity( self )
	util.Effect( "ToolTracer", effect )
	
	-- Take a bullet of primary ammo 
	self:TakePrimaryAmmo(self.Primary.TakeAmmo) 
	self:SetNextPrimaryFire( CurTime() + 1 )
	self.Weapon:EmitSound("rptstungunshot2.mp3")

	if IsValid(ply) && ply:IsPlayer() then 

		-- Check if the player is near the player 
		if Owner:GetPos():DistToSqr(ply:GetPos()) < 600^2 then
			if SERVER then 
				if not Realistic_Police.CantBeStun[team.GetName(ply:Team())] then 
					ply:EmitSound( "ambient/voices/m_scream1.wav" )
					Realistic_Police.Tazz(ply)	
					Realistic_Police.ResetBonePosition(Realistic_Police.ManipulateBoneCuffed, ply)
					Realistic_Police.ResetBonePosition(Realistic_Police.ManipulateBoneSurrender, ply)	
					ply:EmitSound("rptstungunmain.mp3")
				end 
			end
		end 
	end 
end 

function SWEP:Reload()
	local Owner = self:GetOwner()

	Owner.AntiSpamR = Owner.AntiSpamR or CurTime()
	if Owner.AntiSpamR > CurTime() then return end 
	Owner.AntiSpamR = CurTime() + 3 

	if self:Clip1() == 0 then 

		-- Player the reload sound of the stungun 
		self:SendWeaponAnim( ACT_VM_RELOAD )
		self.Weapon:EmitSound("rptstungunreload.mp3")

		-- Delete the debug timer for the animation 
		if timer.Exists("rpt_animation"..self:GetOwner():EntIndex()) then 
			timer.Remove("rpt_animation"..self:GetOwner():EntIndex())
		end 

		-- Play the idle animation next the primary attack
		timer.Create("rpt_animation"..self:GetOwner():EntIndex(), self:SequenceDuration(), 1, function()	
			if IsValid(self) && IsValid(Owner) then 		
				if Owner:GetActiveWeapon() == self then
					self:SetClip1( self.Primary.ClipSize )
					self:SendWeaponAnim( ACT_VM_IDLE )
				end 
			end 
		end ) 
	end 
end 

function SWEP:SecondaryAttack() end 
