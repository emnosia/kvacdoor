--[[---------------------------------------------------------------------------
DarkRP custom entities
---------------------------------------------------------------------------

This file contains your custom entities.
This file should also contain entities from DarkRP that you edited.

Note: If you want to edit a default DarkRP entity, first disable it in darkrp_config/disabled_defaults.lua
    Once you've done that, copy and paste the entity to this file and edit it.

The default entities can be found here:
https://github.com/FPtje/DarkRP/blob/master/gamemode/config/addentities.lua

For examples and explanation please visit this wiki page:
https://darkrp.miraheze.org/wiki/DarkRP:CustomEntityFields

Add entities under the following line:
---------------------------------------------------------------------------]]
	DarkRP.createEntity("ACOG 4X", {
		ent = "fas2_att_acog",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_acog"
	})

	DarkRP.createEntity("COMPM4", {
		ent = "fas2_att_compm4",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_compm4"
	})

	DarkRP.createEntity("ELCAN C79", {
		ent = "fas2_att_c79",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_c79"
	})

	DarkRP.createEntity("ECOTECH 553", {
		ent = "fas2_att_eotech",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_eotech"
	})

	DarkRP.createEntity("FOREGRIP", {
		ent = "fas2_att_foregrip",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_foregrip"
	})

	DarkRP.createEntity("HARRIS BIPOD", {
		ent = "fas2_att_harrisbipod",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_harrisbipod"
	})

	DarkRP.createEntity("LEUPOLD MK4", {
		ent = "fas2_att_leupold",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_leupold"
	})

	DarkRP.createEntity("M21 20RND MAG", {
		ent = "fas2_att_m2120mag",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_m2120mag"
	})

	DarkRP.createEntity("MP5K 30RND MAG", {
		ent = "fas2_att_mp5k30mag",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_mp5k30mag"
	})

	DarkRP.createEntity("PSO 1", {
		ent = "fas2_att_pso1",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_pso1"
	})

	DarkRP.createEntity("SG55X 30RND MAG", {
		ent = "fas2_att_sg55x30mag",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_sg55x30mag"
	})

	DarkRP.createEntity("SKS 20RND MAG", {
		ent = "fas2_att_sks20mag",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_sks20mag"
	})

	DarkRP.createEntity("SKS 30RND MAG", {
		ent = "fas2_att_sks30mag",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_sks30mag"
	})

	DarkRP.createEntity("SUPPRESSOR", {
		ent = "fas2_att_suppressor",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_suppressor"
	})

	DarkRP.createEntity("TRITIUM SIGHTS", {
		ent = "fas2_att_tritiumsights",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_tritiumsights"
	})

	DarkRP.createEntity("UZI Wooden Stock", {
		ent = "fas2_att_uziwoodenstock",
		model = "models/Items/BoxSRounds.mdl",
		price = 350,
		max = 1,
		category = "Commerce General",
		cmd = "givefas2_att_uziwoodenstock"
	})

	DarkRP.createEntity("KeyPad Cracker", {
		ent = "keypad_cracker",
		model = "models/weapons/w_c4.mdl",
		price = 4000,
		max = 1,
		category = "DarkNet General",
		cmd = "givekeypad_cracker"
	})

	DarkRP.createEntity("Brise Vitre", {
		ent = "jewelry_robbery_hammer",
		model = "models/sterling/ajr_hammer_w.mdl",
		price = 3500,
		max = 1,
		category = "DarkNet General",
		cmd = "givejewelry_robbery_hammer"
	})
 
	DarkRP.createEntity("Sac à dos", {
		ent = "jewelryrobbery_bag_1",
		model = "models/sterling/ajr_backpack.mdl",
		price = 2500,
		max = 1,
		category = "DarkNet General",
		cmd = "givejewelryrobbery_bag_1"
	})

	DarkRP.createEntity("Kit de crochetage", {
		ent = "lockpick",
		model = "models/weapons/w_crowbar.mdl",
		price = 3500,
		max = 1,
		category = "DarkNet General",
		cmd = "givelockpick"
	})

	DarkRP.createEntity("Printer Debutant", {
		ent = "boost_printer",
		model = "models/props_c17/consolebox01a.mdl",
		price = 2000,
		max = 2,
		category = "DarkNet Printer",
		cmd = "buyblueprinter"
	})

	DarkRP.createEntity("Printer Novice ", {
		ent = "boost_printer_red",
		model = "models/props_c17/consolebox01a.mdl",
		price = 5000,
		max = 2,
		category = "DarkNet Printer",
		cmd = "buyredprinter"
	})

	DarkRP.createEntity("Printer Intermediaire", {
		ent = "boost_printer_green",
		model = "models/props_c17/consolebox01a.mdl",
		price = 10000,
		max = 2,
		category = "DarkNet Printer",
		cmd = "buygreenprinter"
	})
	
	DarkRP.createEntity("★VIP★Printer Pro", {
		ent = "boost_printer_yellow",
		model = "models/props_c17/consolebox01a.mdl",
		price = 15000,
		max = 3,
		category = "DarkNet Printer",
		customCheck = function(ply) return CLIENT or table.HasValue({"VIP", "superadmin", "ModoTestVIP", "ModerateurVIP", "Moderateur+VIP", "Chef moderateurVIP", "AdministrateurVIP",}, ply:GetNWString("usergroup"))
		end,
		CustomCheckFailMsg = "VIP Uniquement",
		cmd = "buyyellowprinter"
	})

	DarkRP.createEntity("★VIP★Printer Expert", {
		ent = "boost_printer_purple",
		model = "models/props_c17/consolebox01a.mdl",
		price = 20000,
		max = 3,
		category = "DarkNet Printer",
		customCheck = function(ply) return CLIENT or table.HasValue({"VIP", "superadmin", "ModoTestVIP", "ModerateurVIP", "Moderateur+VIP", "Chef moderateurVIP", "AdministrateurVIP",}, ply:GetNWString("usergroup"))
		end,
		CustomCheckFailMsg = "VIP Uniquement",
		cmd = "buypurpleprinter"
	})

	DarkRP.createEntity("Refroidissement", {
		ent = "boost_cooling",
		model = "models/Items/battery.mdl",
		price = 100,
		max = 3,
		category = "Commerce General",
		cmd = "buycoolingcell"
	})

	DarkRP.createEntity("Batterie", {
		ent = "boost_battery",
		model = "models/Items/car_battery01.mdl",
		price = 150,
		max = 3,
		category = "Commerce General",
		cmd = "buybattery"
	})