--[[---------------------------------------------------------------------------
DarkRP custom food
---------------------------------------------------------------------------

This file contains your custom food.
This file should also contain food from DarkRP that you edited.

THIS WILL ONLY LOAD IF HUNGERMOD IS ENABLED IN darkrp_config/disabled_defaults.lua.
IT IS DISABLED BY DEFAULT.

Note: If you want to edit a default DarkRP food, first disable it in darkrp_config/disabled_defaults.lua
    Once you've done that, copy and paste the food item to this file and edit it.

The default food can be found here:
https://github.com/FPtje/DarkRP/blob/master/gamemode/modules/hungermod/sh_init.lua#L33

Add food under the following line:
---------------------------------------------------------------------------]]

DarkRP.createFood("Shake Choco", {
    model = "models/chocolateshake01/chocolateshake01.mdl",
    energy = 25,
    price = 25
})

DarkRP.createFood("Penne Pasta", {
    model = "models/pennepasta01/pennepasta01.mdl",
    energy = 50,
    price = 50
})

DarkRP.createFood("Spaghetti Bolo", {
    model = "models/bowlofspaghetti01/bowlofspaghetti01.mdl",
    energy = 50,
    price = 50
})

DarkRP.createFood("Mac N Cheese", {
    model = "models/macncheese01/macncheese01.mdl",
    energy = 50,
    price = 50
})

DarkRP.createFood("Alfredo Fettuccine", {
    model = "models/alfredo01/alfredo01.mdl",
    energy = 50,
    price = 50
})

DarkRP.createFood("Pizza Pepe", {
    model = "models/peppizza02/peppizza02.mdl",
    energy = 75,
    price = 75
})