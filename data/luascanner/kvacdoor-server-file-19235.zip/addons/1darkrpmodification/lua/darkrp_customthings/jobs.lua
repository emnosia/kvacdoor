--[[---------------------------------------------------------------------------
DarkRP custom jobs
---------------------------------------------------------------------------
This file contains your custom jobs.
This file should also contain jobs from DarkRP that you edited.

Note: If you want to edit a default DarkRP job, first disable it in darkrp_config/disabled_defaults.lua
      Once you've done that, copy and paste the job to this file and edit it.

The default jobs can be found here:
https://github.com/FPtje/DarkRP/blob/master/gamemode/config/jobrelated.lua

For examples and explanation please visit this wiki page:
https://darkrp.miraheze.org/wiki/DarkRP:CustomJobFields

Add your custom jobs under the following line:
---------------------------------------------------------------------------]]

TEAM_CITIZEN = DarkRP.createJob("Citoyen", {
    color = Color(0, 255, 180, 255),
    model = {
        "models/smalls_civilians/pack1/puffer_male_07_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_01_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_02_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_03_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_04_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_05_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_09_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_01_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_02_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_03_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_04_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_05_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_07_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_09_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_01_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_02_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_03_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_04_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_06_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_07_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_01_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_02_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_03_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_04_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_06_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_07_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_01_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_02_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_03_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_04_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_06_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_07_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_07_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_01_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_02_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_03_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_04_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_06_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_07_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_01_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_02_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_03_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_04_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_06_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_07_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_01_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_02_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_03_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_04_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_06_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_07_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_01_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_02_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_03_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_04_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_06_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_07_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_01_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_02_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_03_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_04_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_05_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_06_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_07_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_08_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_09_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_01_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_02_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_03_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_04_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_05_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_06_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_07_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_08_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_09_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_01_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_02_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_03_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_04_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_05_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_06_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_07_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_08_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_sweatpants/male_09_hoodiesweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_01_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_02_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_03_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_04_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_05_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_06_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_07_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_08_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_09_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_01_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_02_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_03_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_04_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_05_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_06_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_07_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_08_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_09_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_01_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_02_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_03_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_04_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_05_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_06_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_07_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_08_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_09_leather_jacket_pm.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {},
    command = "citizen",
    max = 0,
    salary = GAMEMODE.Config.normalsalary * 2,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Citoyen",
})

TEAM_SECU = DarkRP.createJob("Agent de Sécurité", {
    color = Color(0, 255, 180, 255),
    model = {
        "models/player/portal/male_01_security.mdl",
        "models/player/portal/male_02_security.mdl",
        "models/player/portal/male_03_security.mdl",
        "models/player/portal/male_04_security.mdl",
        "models/player/portal/male_05_security.mdl",
        "models/player/portal/male_06_security.mdl",
        "models/player/portal/male_07_security.mdl",
        "models/player/portal/male_08_security.mdl",
        "models/player/portal/male_09_security.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {"stunstick", "weaponchecker", "weapon_rpt_stungun"},
    command = "secu",
    max = 6,
    salary = GAMEMODE.Config.normalsalary * 4,
    admin = 0,
    vote = false,
    hasLicense = true,
    category = "Citoyen",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_SECU then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_MUSIC = DarkRP.createJob("Musicien", {
    color = Color(0, 255, 180, 255),
    model = {
        "models/smalls_civilians/pack1/hoodie_male_05_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_01_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_02_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_03_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_04_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_07_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_09_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_01_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_02_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_03_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_04_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_05_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_07_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_09_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_01_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_02_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_03_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_04_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_06_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_07_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_01_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_02_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_03_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_04_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_06_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_07_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_01_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_02_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_03_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_04_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_06_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_07_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_07_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_01_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_02_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_03_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_04_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_06_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_07_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_01_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_02_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_03_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_04_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_06_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_07_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_01_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_02_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_03_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_04_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_06_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_07_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_01_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_02_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_03_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_04_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_06_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_07_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_01_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_02_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_03_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_04_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_05_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_06_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_07_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_08_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_09_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_01_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_02_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_03_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_04_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_05_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_06_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_07_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_08_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_09_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_01_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_02_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_03_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_04_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_05_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_06_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_07_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_08_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_sweatpants/male_09_hoodiesweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_01_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_02_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_03_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_04_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_05_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_06_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_07_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_08_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_09_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_01_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_02_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_03_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_04_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_05_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_06_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_07_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_08_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_09_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_01_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_02_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_03_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_04_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_05_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_06_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_07_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_08_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_09_leather_jacket_pm.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {"guitar"},
    command = "music",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 3,
    admin = 0,
    vote = false,
    hasLicense = false,
    category = "Citoyen",
})

TEAM_BANK = DarkRP.createJob("Banquier", {
    color = Color(0, 255, 180, 255),
    model = "models/player/breen.mdl",
    description = [[➜Clic-gauche pour validé]],
    weapons = {},
    command = "bank",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 3,
    admin = 0,
    vote = false,
    hasLicense = false,
    category = "Citoyen",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_BANK then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_POLICE = DarkRP.createJob("Officier [FCPD]", {
    color = Color(0, 90, 255, 255),
    model = {
        "models/kerry/ppd_1_01.mdl",
        "models/kerry/ppd_1_02.mdl",
        "models/kerry/ppd_1_04.mdl",
        "models/kerry/ppd_1_05.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {"fas2_ots33", "stunstick", "weapon_rpt_stungun", "weapon_rpt_handcuff", "wep_jack_job_drpradio", "lockpick", "keypad_cracker", "weapon_rpt_finebook"},
    command = "cp",
    max = 10,
    salary = GAMEMODE.Config.normalsalary * 4,
    admin = 0,
    vote = false,
    hasLicense = true,
    customCheck = function(ply)
        if ply:GetUTimeTotalTime() >= 10800 then
        return true
        end
        end,
        CustomCheckFailMsg = "Vous devez jouer " .. string.NiceTime( 10800 ) .." pour pouvoir prendre ce metier.",
    category = "Flux City Police Department [FCPD]",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_POLICE then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_SERG = DarkRP.createJob("Sergent [FCPD]", {
    color = Color(0, 90, 255, 255),
    model = {
        "models/kerry/ppd_3_02.mdl",
        "models/kerry/ppd_3_01.mdl",
        "models/kerry/ppd_3_04.mdl",
        "models/kerry/ppd_3_05.mdl",
        "models/kerry/ppd_3_06.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {"fas2_ots33", "fas2_mp5sd6", "stunstick", "weapon_rpt_stungun", "weapon_rpt_handcuff", "wep_jack_job_drpradio", "lockpick", "keypad_cracker", "weapon_rpt_finebook"},
    command = "cp1",
    max = 3,
    salary = GAMEMODE.Config.normalsalary * 5,
    admin = 0,
    vote = true,
    hasLicense = true,
    NeedToChangeFrom = TEAM_POLICE,
    customCheck = function(ply)
        if ply:GetUTimeTotalTime() >= 25200 then
        return true
        end
        end,
        CustomCheckFailMsg = "Vous devez jouer " .. string.NiceTime( 25200 ) .." pour pouvoir prendre ce metier.",
    category = "Flux City Police Department [FCPD]",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_SERG then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_SERGCHEF = DarkRP.createJob("Sergent-Chef [FCPD]", {
    color = Color(0, 90, 255, 255),
    model = {
        "models/kerry/ppd_3_05.mdl",
        "models/kerry/ppd_3_02.mdl",
        "models/kerry/ppd_3_01.mdl",
        "models/kerry/ppd_3_04.mdl",
        "models/kerry/ppd_3_06.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {"fas2_ots33", "fas2_mp5sd6", "stunstick", "weapon_rpt_stungun", "weapon_rpt_handcuff", "wep_jack_job_drpradio", "lockpick", "keypad_cracker", "weapon_rpt_finebook"},
    command = "cp2",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 5,
    admin = 0,
    vote = true,
    hasLicense = true,
    NeedToChangeFrom = TEAM_POLICE,
    customCheck = function(ply)
        if ply:GetUTimeTotalTime() >= 57600 then
        return true
        end
        end,
        CustomCheckFailMsg = "Vous devez jouer " .. string.NiceTime( 57600 ) .." pour pouvoir prendre ce metier.",
    category = "Flux City Police Department [FCPD]",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_SERGCHEF then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_LIEUT = DarkRP.createJob("Lieutenant [FCPD]", {
    color = Color(0, 90, 255, 255),
    model = {
        "models/kerry/ag_player/male_01.mdl",
        "models/kerry/ag_player/male_04.mdl",
        "models/kerry/ag_player/male_05.mdl",
        "models/kerry/ag_player/male_07.mdl",
        "models/kerry/ag_player/male_09.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {"fas2_ots33", "fas2_mp5sd6", "fas2_rk95", "stunstick", "weapon_rpt_stungun", "weapon_rpt_handcuff", "wep_jack_job_drpradio", "lockpick", "keypad_cracker", "weapon_rpt_finebook"},
    command = "cp3",
    max = 3,
    salary = GAMEMODE.Config.normalsalary * 6,
    admin = 0,
    vote = true,
    hasLicense = true,
    NeedToChangeFrom = TEAM_POLICE,
    customCheck = function(ply)
        if ply:GetUTimeTotalTime() >= 86400 then
        return true
        end
        end,
        CustomCheckFailMsg = "Vous devez jouer " .. string.NiceTime( 86400 ) .." pour pouvoir prendre ce metier.",
    category = "Flux City Police Department [FCPD]",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_LIEUT then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_LIEUTCHEF = DarkRP.createJob("Lieutenant-Chef [FCPD]", {
    color = Color(0, 90, 255, 255),
    model = {
        "models/kerry/ag_player/male_07.mdl",
        "models/kerry/ag_player/male_01.mdl",
        "models/kerry/ag_player/male_04.mdl",
        "models/kerry/ag_player/male_05.mdl",
        "models/kerry/ag_player/male_09.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {"fas2_ots33", "fas2_mp5sd6", "fas2_rk95", "stunstick", "weapon_rpt_stungun", "weapon_rpt_handcuff", "wep_jack_job_drpradio", "lockpick", "keypad_cracker", "weapon_rpt_finebook"},
    command = "cp4",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 6,
    admin = 0,
    vote = true,
    hasLicense = true,
    NeedToChangeFrom = TEAM_POLICE,
    customCheck = function(ply)
        if ply:GetUTimeTotalTime() >= 172800 then
        return true
        end
        end,
        CustomCheckFailMsg = "Vous devez jouer " .. string.NiceTime( 172800 ) .." pour pouvoir prendre ce metier.",
    category = "Flux City Police Department [FCPD]",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_LIEUTCHEF then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_CHIEF = DarkRP.createJob("Capitaine [FCPD]", {
    color = Color(0, 90, 255, 255),
    model = {
        "models/kerry/ag_player/male_07_cheff.mdl",
        "models/kerry/ag_player/male_01_cheff.mdl",
        "models/kerry/ag_player/male_02_cheff.mdl",
        "models/kerry/ag_player/male_04_cheff.mdl",
        "models/kerry/ag_player/male_05_cheff.mdl",
        "models/kerry/ag_player/male_06_cheff.mdl",
        "models/kerry/ag_player/male_08_cheff.mdl",
        "models/kerry/ag_player/male_09_cheff.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {"fas2_ots33", "fas2_mp5sd6", "fas2_rk95", "fas2_m4a1", "stunstick", "weapon_rpt_stungun", "weapon_rpt_handcuff", "wep_jack_job_drpradio", "lockpick", "keypad_cracker", "weapon_rpt_finebook"},
    command = "chief",
    max = 1,
    salary = GAMEMODE.Config.normalsalary * 7,
    admin = 0,
    vote = true,
    hasLicense = true,
    chief = true,
    NeedToChangeFrom = TEAM_POLICE,
    customCheck = function(ply)
        if ply:GetUTimeTotalTime() >= 259200 then
        return true
        end
        end,
        CustomCheckFailMsg = "Vous devez jouer " .. string.NiceTime( 259200 ) .." pour pouvoir prendre ce metier.",
    category = "Flux City Police Department [FCPD]",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_CHIEF then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_FBI = DarkRP.createJob("★VIP★F.I.B [FCPD]", {
    color = Color(0, 90, 255, 255),
    model = {
        "models/kerry/ag_player/male_07_fbi.mdl",
        "models/kerry/ag_player/male_01_fbi.mdl",
        "models/kerry/ag_player/male_02_fbi.mdl",
        "models/kerry/ag_player/male_04_fbi.mdl",
        "models/kerry/ag_player/male_05_fbi.mdl",
        "models/kerry/ag_player/male_06_fbi.mdl",
        "models/kerry/ag_player/male_08_fbi.mdl",
        "models/kerry/ag_player/male_09_fbi.mdl"
    },
    description = [[➜Clic-gauche pour validé]],
    weapons = {"fas2_ots33", "fas2_rk95", "stunstick", "weapon_rpt_stungun", "weapon_rpt_handcuff", "wep_jack_job_drpradio", "lockpick", "keypad_cracker", "weapon_rpt_finebook"},
    command = "fbi",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 7,
    admin = 0,
    vote = true,
    hasLicense = true,
    NeedToChangeFrom = TEAM_POLICE,
	customCheck = function(ply) return ply:IsUserGroup("VIP") or ply:IsUserGroup("superadmin") or ply:IsUserGroup("ModoTestVIP") or ply:IsUserGroup("ModerateurVIP") or ply:IsUserGroup("Moderateur+VIP") or ply:IsUserGroup("Chef moderateurVIP") or ply:IsUserGroup("AdministrateurVIP") end,
	CustomCheckFailMsg = "Vous avez besoins d'être VIP pour choisir ce métier.",
    category = "Flux City Police Department [FCPD]",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_FBI then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_SWAT = DarkRP.createJob("★VIP★S.W.A.T [FCPD]", {
    color = Color(0, 90, 255, 255),
    model = "models/kerry/ag_player/swat.mdl",
    description = [[➜Clic-gauche pour validé]],
    weapons = {"fas2_ots33", "fas2_m4a1", "stunstick", "weapon_rpt_stungun", "weapon_rpt_handcuff", "wep_jack_job_drpradio", "lockpick", "keypad_cracker", "weapon_rpt_finebook"},
    command = "swat",
    max = 4,
    salary = GAMEMODE.Config.normalsalary * 7,
    admin = 0,
    vote = true,
    hasLicense = true,
    NeedToChangeFrom = TEAM_POLICE,
	customCheck = function(ply) return ply:IsUserGroup("VIP") or ply:IsUserGroup("superadmin") or ply:IsUserGroup("ModoTestVIP") or ply:IsUserGroup("ModerateurVIP") or ply:IsUserGroup("Moderateur+VIP") or ply:IsUserGroup("Chef moderateurVIP") or ply:IsUserGroup("AdministrateurVIP") end,
	CustomCheckFailMsg = "Vous avez besoins d'être VIP pour choisir ce métier.",
    category = "Flux City Police Department [FCPD]",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_SWAT then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_PROTECT = DarkRP.createJob("Sécurité Présidentielle", {
    color = Color(180, 0, 0, 255),
    model = {
        "models/kerry/ppd_2_02.mdl",
        "models/kerry/ppd_2_01.mdl",
        "models/kerry/ppd_2_04.mdl",
        "models/kerry/ppd_2_05.mdl",
        "models/kerry/ppd_2_06.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {"stunstick", "weaponchecker", "fas2_mp5sd6", "wep_jack_job_drpradio", "weapon_rpt_stungun"},
    command = "protect",
    max = 4,
    salary = GAMEMODE.Config.normalsalary * 4,
    admin = 0,
    vote = false,
    hasLicense = true,
    customCheck = function(ply)
        if ply:GetUTimeTotalTime() >= 7200 then
        return true
        end
        end,
        CustomCheckFailMsg = "Vous devez jouer " .. string.NiceTime( 7200 ) .." pour pouvoir prendre ce metier.",
    category = "Gouvernement de Flux City",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_PROTECT then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_MEDIC = DarkRP.createJob("EMS", {
    color = Color(180, 0, 0, 255),
    model = {
        "models/kerry/ag_paramedic/male_03.mdl",
        "models/kerry/ag_paramedic/male_01.mdl",
        "models/kerry/ag_paramedic/male_02.mdl",
        "models/kerry/ag_paramedic/male_04.mdl",
        "models/kerry/ag_paramedic/male_05.mdl",
        "models/kerry/ag_paramedic/male_06.mdl",
        "models/kerry/ag_paramedic/male_07.mdl",
        "models/kerry/ag_paramedic/male_08.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
    weapons = {"med_kit"},
    command = "medic",
    max = 4,
    salary = GAMEMODE.Config.normalsalary * 4,
    admin = 0,
    vote = false,
    hasLicense = false,
    medic = true,
    category = "Gouvernement de Flux City",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_MEDIC then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_MAYOR = DarkRP.createJob("Président", {
    color = Color(180, 0, 0, 255),
    model = "models/player/emmanuel_macron.mdl",
    description = [[➜Clic-gauche pour validé]],
    weapons = {},
    command = "mayor",
    max = 1,
    salary = GAMEMODE.Config.normalsalary * 7,
    admin = 0,
    vote = true,
    hasLicense = false,
    mayor = true,
    customCheck = function(ply)
        if ply:GetUTimeTotalTime() >= 10800 then
        return true
        end
        end,
        CustomCheckFailMsg = "Vous devez jouer " .. string.NiceTime( 10800 ) .." pour pouvoir prendre ce metier.",
    category = "Gouvernement de Flux City",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_MAYOR then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_TOWER = DarkRP.createJob("Garagiste/Réparateur", {
    color = Color(255, 190, 0, 255),
    model = "models/player/mechanic.mdl",
    description = [[➜Clic-gauche pour validé]],
    weapons = {"sv_wrench", "tow_attach"},
    command = "tower",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 3,
    admin = 0,
    vote = false,
    hasLicense = false,
    category = "Commercant",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_TOWER then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_GUN = DarkRP.createJob("Commerçant d'Armes", {
    color = Color(255, 190, 0, 255),
    model = "models/minson97/bo2/hudson/hudson_commando.mdl",
    description = [[➜Clic-gauche pour validé]],
    weapons = {},
    command = "gundealer",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 3,
    admin = 0,
    vote = false,
    hasLicense = false,
    customCheck = function(ply)
        if ply:GetUTimeTotalTime() >= 7200 then
        return true
        end
        end,
        CustomCheckFailMsg = "Vous devez jouer " .. string.NiceTime( 7200 ) .." pour pouvoir prendre ce metier.",
    category = "Commercant",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_GUN then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

TEAM_GUNVIP = DarkRP.createJob("★VIP★Commerçant Noir", {
    color = Color(255, 190, 0, 255),
    model = "models/minson97/bo2/hudson/hudson_commando.mdl",
    description = [[➜Clic-gauche pour validé]],
    weapons = {},
    command = "gundealervip",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 4,
    admin = 0,
    vote = false,
    hasLicense = false,
    category = "Commercant",
	customCheck = function(ply) return ply:IsUserGroup("VIP") or ply:IsUserGroup("superadmin") or ply:IsUserGroup("ModoTestVIP") or ply:IsUserGroup("ModerateurVIP") or ply:IsUserGroup("Moderateur+VIP") or ply:IsUserGroup("Chef moderateurVIP") or ply:IsUserGroup("AdministrateurVIP") end,
	CustomCheckFailMsg = "Vous avez besoins d'être VIP pour choisir ce métier.",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_GUNVIP then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

if not DarkRP.disabledDefaults["modules"]["hungermod"] then
    TEAM_COOK = DarkRP.createJob("Restaurateur", {
        color = Color(255, 190, 0, 255),
        model = "models/fearless/chef1.mdl",
        description = [[➜Clic-gauche pour validé]],
        weapons = {},
        command = "cook",
        max = 4,
        salary = GAMEMODE.Config.normalsalary * 3,
        admin = 0,
        vote = false,
        hasLicense = false,
        cook = true,
	    category = "Commercant",
        PlayerDeath = function(ply)
            if ply:Team() == TEAM_COOK then
                ply:changeTeam( TEAM_CITIZEN, true )
            end
        end,
    })
end

--[[---------------------------------------------------------------------------
Define which team joining players spawn into and what team you change to if demoted
---------------------------------------------------------------------------]]
GAMEMODE.DefaultTeam = TEAM_CITIZEN
--[[---------------------------------------------------------------------------
Define which teams belong to civil protection
Civil protection can set warrants, make people wanted and do some other police related things
---------------------------------------------------------------------------]]
GAMEMODE.CivilProtection = {
    [TEAM_POLICE] = true,
    [TEAM_CHIEF] = true,
    [TEAM_MAYOR] = true,
}
--[[---------------------------------------------------------------------------
Jobs that are hitmen (enables the hitman menu)
---------------------------------------------------------------------------]]

