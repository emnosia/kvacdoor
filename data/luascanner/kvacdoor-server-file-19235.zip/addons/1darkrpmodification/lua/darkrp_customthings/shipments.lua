--[[---------------------------------------------------------------------------
DarkRP custom shipments and guns
---------------------------------------------------------------------------

This file contains your custom shipments and guns.
This file should also contain shipments and guns from DarkRP that you edited.

Note: If you want to edit a default DarkRP shipment, first disable it in darkrp_config/disabled_defaults.lua
    Once you've done that, copy and paste the shipment to this file and edit it.

The default shipments and guns can be found here:
https://github.com/FPtje/DarkRP/blob/master/gamemode/config/addentities.lua

For examples and explanation please visit this wiki page:
https://darkrp.miraheze.org/wiki/DarkRP:CustomShipmentFields


Add shipments and guns under the following line:
---------------------------------------------------------------------------]]

AddCustomShipment("AK-47 x1", {
model = "models/weapons/w_rif_m4a1.mdl",
entity = "fas2_ak47",
price = 7500,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Assault", 
})

AddCustomShipment("G36C x1", {
model = "models/weapons/w_rif_m4a1.mdl",
entity = "fas2_g36c",
price = 6500,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Assault", 
})

AddCustomShipment("AK-74 x1", {
model = "models/weapons/w_rif_m4a1.mdl",
entity = "fas2_ak74",
price = 8500,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Assault", 
})

AddCustomShipment("M4A1 x1", {
model = "models/weapons/w_rif_m4a1.mdl",
entity = "fas2_m4a1",
price = 8000,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Assault", 
})

AddCustomShipment("FAMAS x1", {
model = "models/weapons/w_rif_m4a1.mdl",
entity = "fas2_famas",
price = 5500,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Assault", 
})

AddCustomShipment("MP5A5 x1", {
model = "models/weapons/w_smg_ump45.mdl",
entity = "fas2_mp5a5",
price = 4500,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Mitraillette",  
})

AddCustomShipment("SG552 x1", {
model = "models/weapons/w_smg_ump45.mdl",
entity = "fas2_sg552",
price = 5000,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Mitraillette",  
})

AddCustomShipment("PP-19 Bizon x1", {
model = "models/weapons/w_smg_ump45.mdl",
entity = "fas2_pp19",
price = 4000,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Mitraillette",  
})

AddCustomShipment("MAC11 x1", {
model = "models/weapons/w_smg_ump45.mdl",
entity = "fas2_mac11",
price = 3500,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Mitraillette",  
})

AddCustomShipment("Uzi x1", {
model = "models/weapons/w_smg_ump45.mdl",
entity = "fas2_uzi",
price = 3000,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Mitraillette", 
})

AddCustomShipment("Desert Eagle x1", {
model = "models/weapons/w_pist_glock18.mdl",
entity = "fas2_deagle",
price = 2500,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Pistolet", 
})

AddCustomShipment("P226 x1", {
model = "models/weapons/w_pist_glock18.mdl",
entity = "fas2_p226",
price = 1700,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Pistolet", 
})

AddCustomShipment("Glock 20 x1", {
model = "models/weapons/w_pist_glock18.mdl",
entity = "fas2_glock20",
price = 2000,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Pistolet", 
})

AddCustomShipment("M1911 x1", {
model = "models/weapons/w_pist_glock18.mdl",
entity = "fas2_m1911",
price = 1800,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Pistolet", 
})

AddCustomShipment("OTS-33 x1", {
model = "models/weapons/w_pist_glock18.mdl",
entity = "fas2_ots33",
price = 2700,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Pistolet", 
})

AddCustomShipment("Taser x1", {
model = "models/realistic_police/taser/w_taser.mdl",
entity = "weapon_rpt_stungun",
price = 1000,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Autre", 
})

AddCustomShipment("Couteau x1", {
model = "models/weapons/w_knife_t.mdl",
entity = "fas2_dv2",
price = 1500,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Autre", 
})

AddCustomShipment("Machette x1", {
model = "models/weapons/w_knife_t.mdl",
entity = "fas2_machete",
price = 1500,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Autre", 
})

AddCustomShipment("Kevlar Light x1", {
model = "models/combine_vests/bluevest.mdl",
entity = "light kevlar armor",
price = 5000,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Autre", 
})

AddCustomShipment("Kevlar Medium x1", {
model = "models/combine_vests/bluevest.mdl",
entity = "medium kevlar armor",
price = 7500,
amount = 1,
separate = false,
pricesep = 500,
noship = false,
allowed = {TEAM_GUN, TEAM_GUNVIP},
category = "Autre", 
})