zyb = zyb or {}
zyb.f = zyb.f or {}
function zyb.f.LoadAllFiles(fdir)
	local files, dirs = file.Find(fdir .. "*", "LUA")

	for _, afile in ipairs(files) do
		if string.match(afile, ".lua") then
			if SERVER then
				AddCSLuaFile(fdir .. afile)
			end

			include(fdir .. afile)
		end
	end

	for _, dir in ipairs(dirs) do
		zyb.f.LoadAllFiles(fdir .. dir .. "/")
	end
end

zyb.f.LoadAllFiles("zerosyeastbeast/")
zyb.f.LoadAllFiles("zyb_languages/")
