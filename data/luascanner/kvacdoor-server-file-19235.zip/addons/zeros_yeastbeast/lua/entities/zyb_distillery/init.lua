AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:SpawnFunction(ply, tr)
	if (not tr.Hit) then return end
	local SpawnPos = tr.HitPos + tr.HitNormal * 1
	local ent = ents.Create(self.ClassName)
	local angle = ply:GetAimVector():Angle()
	angle = Angle(0, angle.yaw, 0)
	angle:RotateAroundAxis(angle:Up(), 180)
	ent:SetAngles(angle)
	ent:SetPos(SpawnPos)
	ent:Spawn()
	ent:Activate()
	zyb.f.SetOwner(ent, ply)
	return ent
end

function ENT:Initialize()
	self:SetModel(self.Model)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(CONTINUOUS_USE)
	local phys = self:GetPhysicsObject()

	if (phys:IsValid()) then
		phys:Wake()
		phys:EnableMotion(true)
	end

	self:UseClientSideAnimation()

	// Is the entity busy
	self.IsBusy = false

	// Last time it burned fuel
	self.LastFuelBurn = -1

	// Last time of cook think
	self.LastCookThink = -1

	// Is it getting depressurized
	self.Depressuring = false

	// Last time it got depressurized
	self.LastDepressuring = -1

	// Last input from the user
	self.LastInput = -1
end

function ENT:StartTouch(other)
	if not IsValid(other) then return end
	if zyb.f.CollisionCooldown(other) then return end
	if self.IsBusy then return end
	if not IsValid(self:GetCooler()) then return end
	if not IsValid(self:GetCondenser()) then return end


	if other:GetClass() == "zyb_fermbarrel" and other:GetStage() == 3 and self:GetYeastStew() < zyb.config.Distillery.YeastStewAmount then
		self:AddYeastStew(other)
	elseif other:GetClass() == "zyb_fuel" and self:GetFuel() < zyb.config.Distillery.FuelAmount then
		self:AddWood(other)
	end
end

function ENT:AddWood(wood)
	self:SetFuel(math.Clamp(self:GetFuel() + zyb.config.Wood.Amount, 0, zyb.config.Distillery.FuelAmount))
	wood:Remove()
end

function ENT:AddYeastStew(barrel)
	self.IsBusy = true
	zyb.f.PlayAnimation(self, "cap_open", 2)

	barrel:SetHideUI(true)

	barrel:SetBodygroup(2, 0)

	DropEntityIfHeld(barrel)
	local ang = self:GetAngles()
	ang:RotateAroundAxis(self:GetRight(), 180)
	ang:RotateAroundAxis(self:GetUp(), 180)
	barrel:SetAngles(ang)
	barrel:SetPos(self:GetPos() + self:GetUp() * 110 + self:GetForward() * 32)
	barrel:SetParent(self)

	barrel:SetFilling(true)

	zyb.f.CreateEffectTable("yb_mash", nil, barrel, barrel:GetAngles(), barrel:GetPos() + barrel:GetUp() * 35 , nil)

	local emptySpace = zyb.config.Distillery.YeastStewAmount - self:GetYeastStew()
	local InBarrel = barrel:GetYeastStew()

	local fillAmount = 0

	if emptySpace > InBarrel then
		// If the empty space in the distillery is bigger then the amount that we have in the barrel then we use the full amount of the barrel as fillamount
		fillAmount = InBarrel
	else
		// If not then we use the empty space
		fillAmount = emptySpace
	end

	timer.Simple(3, function()

		barrel:SetParent(nil)
		barrel:SetPos(self:GetPos() + self:GetUp() * 110 + self:GetForward() * 40)
		barrel:SetAngles(self:GetAngles())
		barrel:PhysicsInit(SOLID_VPHYSICS)
		barrel:SetMoveType(MOVETYPE_VPHYSICS)
		barrel:SetSolid(SOLID_VPHYSICS)

		local phys = barrel:GetPhysicsObject()
		if (phys:IsValid()) then
			phys:Wake()
			phys:EnableMotion(true)
		end

		self:SetYeastStew(self:GetYeastStew() + fillAmount )

		barrel:SetYeastStew(barrel:GetYeastStew() - fillAmount)

		emptySpace = zyb.config.Distillery.YeastStewAmount - self:GetYeastStew()
		InBarrel = barrel:GetYeastStew()

		if InBarrel <= 0 then
			// If the barrel is empty then we reset it
			barrel:ResetBarrel()
		else
			// Otherwhise we just close it
			barrel:SetBodygroup(2, 1)
			barrel:SetBodygroup(1, 0)
		end

		zyb.f.RemoveEffectNamed(barrel, "yb_mash", nil)

		barrel:SetHideUI(false)

		barrel:SetFilling(false)

		zyb.f.PlayAnimation(self, "cap_close", 2)

		self.IsBusy = false
	end)
end

function ENT:AddCooler(cooler)
	cooler:SetBodygroup(2,1)
	self:SetCooler(cooler)
end

function ENT:AddCondenser(condenser)
	condenser:SetBodygroup(1,1)
	self:SetCondenser(condenser)
	condenser.Cooler = self:GetCooler()
	self:GetCooler().Condenser = condenser
end

function ENT:Think()
	self:CookingProcess()
	self:ReleaseSteam()
end

function ENT:ReleaseSteam()
	if self.Depressuring == false then return end

	if CurTime() > self.LastInput then
		self:SetDepressuring(false)
		self.Depressuring = false
	else
		if CurTime() > self.LastDepressuring then
			self:SetPressureLevel(math.Clamp(self:GetPressureLevel() - 5, 0, 100))
			self.LastDepressuring = CurTime() + 0.25
		end
	end
end

function ENT:CookingProcess()
	if CurTime() < self.LastCookThink then return end
	self.LastCookThink = CurTime() + 1
	local cooler = self:GetCooler()
	local condenser = self:GetCondenser()

	if IsValid(cooler) and IsValid(condenser) then
		local fuel = self:GetFuel()
		local yeastStew = self:GetYeastStew()

		// Here we burn wood every 5 seconds
		if CurTime() > self.LastFuelBurn and fuel > 0 and yeastStew > 0 then
			self:SetFuel(self:GetFuel() - zyb.config.Distillery.FuelUsage)
			self.LastFuelBurn = CurTime() + 3
		end

		// Here we increase / decrease the temperatur
		local PressureLevel = self:GetPressureLevel()

		if fuel > 0 and yeastStew > 0 then
			self:SetPressureLevel(math.Clamp(PressureLevel + 1, 0, 100))
		else
			self:SetPressureLevel(math.Clamp(PressureLevel - 1, 0, 100))
		end

		// If we dont have reached the work temperatur then we stop here
		if PressureLevel < 20 then return end

		// If the pressure gets to high then the boiler explodes
		if PressureLevel > 99 then
			self:BoilerExplosion()
			return
		end

		if yeastStew <= 0 then return end

		if PressureLevel > 90 then
			self:SetYeastStew(math.Clamp(yeastStew - zyb.config.Distillery.BurnAmount, 0, 1000000))
		end


		local YeastStewSteam = cooler:GetYeastStewSteam()
		if YeastStewSteam >= zyb.config.Cooler.YeastSteamAmount then return end
		local workAmount = zyb.config.Distillery.ProcessAmount

		// If the distillery has the perfect heat then we increase the produce steam
		if PressureLevel > 40 and PressureLevel < 80 then
			workAmount = workAmount * zyb.config.Distillery.PerfectHeatBoni
		end

		self:SetYeastStew(math.Clamp(yeastStew - workAmount, 0, 1000000))
		cooler:SetYeastStewSteam(YeastStewSteam + (workAmount * zyb.config.Distillery.DistillAmount))
	end
end

function ENT:BoilerExplosion()
	self.IsBusy = true

	zyb.f.CreateEffectTable("yb_explosion", "zyb_explosion", self, Angle(0, 0, 0), self:GetPos() + self:GetUp() * 50, nil)
	zyb.f.CreateEffectTable("yb_explosion_spill", nil, self, Angle(0, 0, 0), self:GetPos() , 2)

	zyb.f.PlayAnimation(self, "cap_open", 8)

	self:SetYeastStew(0)
	self:SetFuel(0)
	self:SetPressureLevel(0)

	local cooler = self:GetCooler()

	if IsValid(cooler) then
		cooler:SetYeastStewSteam(0)
		cooler:SetWeakMoonShine(0)
		cooler:SetWaterTemperatur(0)
	end

	timer.Simple(2, function()
		if IsValid(self) then
			zyb.f.PlayAnimation(self, "cap_close", 2)

			self.IsBusy = false
		end
	end)
end

function ENT:AcceptInput(key, ply)
	if ((self.lastUsed or CurTime()) <= CurTime()) and (key == "Use" and IsValid(ply) and ply:IsPlayer() and ply:Alive() and zyb.f.InDistance(ply:GetPos(), self:GetPos(), 100)) then
		self.lastUsed = CurTime() + 0.15

		if self:OnPressureValve(ply) and self:GetPressureLevel() > 0 then
			self.LastInput = CurTime() + 0.15
			self:SetDepressuring(true)
			self.Depressuring = true
		end
	end
end

function ENT:OnTakeDamage(dmg)
	zyb.f.Entity_OnTakeDamage(self,dmg)
end
