AddCSLuaFile()
DEFINE_BASECLASS("zyb_distillery_constructionkit")
ENT.Type = "anim"
ENT.Base = "zyb_distillery_constructionkit"
ENT.AutomaticFrameAdvance = true
ENT.Model = "models/zerochain/props_yeastbeast/yb_crate.mdl"
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.PrintName = "ConstructionKit - Condenser"
ENT.Category = "Zeros YeastBeast"
ENT.RenderGroup = RENDERGROUP_OPAQUE

ENT.ConstructionID = 1
