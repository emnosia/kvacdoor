Zeros Yeastbeast

Extract the zeros_yeastbeast folder do your addons located at 
"\Steam\steamapps\common\GarrysMod\garrysmod\addons"

All Configurations can be done in the zyb_config.lua which is located at 
"addons\zeros_yeastbeast\lua\zerosyeastbeast\sh"

Edit what you need in the config, save the file and restart your server.


Why am i seeing only errors or Purble Textures.
You need to make sure you have the content pack isntalled and enabled.

Workshop content:
https://steamcommunity.com/sharedfiles/filedetails/?id=1626509911