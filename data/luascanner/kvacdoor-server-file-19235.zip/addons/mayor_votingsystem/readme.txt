Thanks for purchasing the Mayor Voting System!
-----------------------------------------
There's not much here, since this addon was built from the ground up to be super configurable and easy to customize!

Installation
---------------
Unzip the download, and put Mayor Voting System into the addons folder
If you use FastDL on your server, add the materials/resource folders to your FastDL directory
Resources inside the addon are added automatically

Configuration
--------------
Configure core mayor voting settings and options.  -- lua/sh_votingconfig.lua
Configure mayor voting UI settings.  -- lua/sh_votingconfig.lua
Configure mayor voting UI theme (fonts,colors etc.) -- lua/sh_votingconfig.lua

NPC Setup
--------------
Configure NPC player model, title etc.  -- lua/sh_votingconfig.lua
SuperAdmin Command mayor_vote_placenpc -- This will place the NPC in your exact position and angle, and nocclip you so you can move away.
To remove the NPC, use the remover toolgun and you will see a confirmation message.

Need more help?
Steam: http://steamcommunity.com/id/chuteuk/
Skype: Chuteuk