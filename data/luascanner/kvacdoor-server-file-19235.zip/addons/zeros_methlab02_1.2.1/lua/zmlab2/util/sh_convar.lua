if CLIENT then
    zclib.Convar.Create("zmlab2_cl_vfx_dynamiclight", "1", {FCVAR_ARCHIVE})
    zclib.Convar.Create("zmlab2_cl_sfx_volume", "1", {FCVAR_ARCHIVE})
    zclib.Convar.Create("zmlab2_cl_drawui", "1", {FCVAR_ARCHIVE})
    zclib.Convar.Create("zmlab2_cl_particleeffects", "1", {FCVAR_ARCHIVE})
end
