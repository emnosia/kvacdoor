zmlab2 = zmlab2 or {}

function zmlab2.Print(msg)
	print("[Zero´s Methlab 2] " .. msg)
end
