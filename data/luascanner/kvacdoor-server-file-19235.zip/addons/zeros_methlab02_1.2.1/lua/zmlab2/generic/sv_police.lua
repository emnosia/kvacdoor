if not SERVER then return end

for k,v in pairs(zmlab2.config.Police.Jobs) do
    zclib.Police.Add(k)
end
