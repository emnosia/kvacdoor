TEAM_ZMLAB2_COOK = DarkRP.createJob("Fabriquant de Cristal", {
    color = Color(0, 255, 180, 255),
    model = {
        "models/smalls_civilians/pack2/male/leatherjacket/male_07_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_01_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_02_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_03_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_04_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_05_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_06_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_08_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack2/male/leatherjacket/male_09_leather_jacket_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_01_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_02_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_03_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_04_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_05_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_07_pm.mdl",
        "models/smalls_civilians/pack1/puffer_male_09_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_01_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_02_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_03_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_04_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_06_pm.mdl",
        "models/smalls_civilians/pack1/zipper_female_07_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_01_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_02_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_03_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_04_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_06_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloverjeans/female_07_hoodiepulloverjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_01_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_02_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_03_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_04_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_06_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_07_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiepulloversweats/female_07_hoodiepulloversweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_01_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_02_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_03_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_04_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_06_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedjeans/female_07_hoodiezippedjeans_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_01_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_02_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_03_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_04_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_06_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/hoodiezippedsweats/female_07_hoodiezippedsweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_01_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_02_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_03_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_04_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_06_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkajeans/female_07_parkajeans_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_01_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_02_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_03_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_04_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_06_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/female/parkasweats/female_07_parkasweats_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_01_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_02_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_03_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_04_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_05_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_06_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_07_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_08_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/baseballtee/male_09_baseballtee_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_01_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_02_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_03_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_04_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_05_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_06_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_07_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_08_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/flannel/male_09_flannel_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_01_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_02_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_03_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_04_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_05_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_06_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_07_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_jeans/male_08_hoodiejeans_pm.mdl",
        "models/smalls_civilians/pack2/male/hoodie_sweatpants/male_09_hoodiesweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_01_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_02_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_03_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_04_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_05_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_06_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_07_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_08_jacketopen_pm.mdl",
        "models/smalls_civilians/pack2/male/jacket_open/male_09_jacketopen_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_01_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_02_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_03_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_04_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_05_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_07_pm.mdl",
        "models/smalls_civilians/pack1/hoodie_male_09_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_01_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_02_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_03_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_04_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_05_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_06_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_07_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_08_jacketvneck_sweatpants_pm.mdl",
        "models/smalls_civilians/pack2/male/jacketvneck_sweatpants/male_09_jacketvneck_sweatpants_pm.mdl"
    },
    description = [[➜Clic-droit pour choisir skin ➜Clic-gauche pour validé]],
	weapons = {},
	command = "zmlab2_MethCook",
	max = 4,
    salary = GAMEMODE.Config.normalsalary * 2,
	admin = 0,
	vote = false,
    category = "Citoyen",
	hasLicense = false,
    customCheck = function(ply)
        if ply:GetUTimeTotalTime() >= 7200 then
        return true
        end
        end,
        CustomCheckFailMsg = "Vous devez jouer " .. string.NiceTime( 7200 ) .." pour pouvoir prendre ce metier.",
    PlayerDeath = function(ply)
        if ply:Team() == TEAM_ZMLAB2_COOK then
            ply:changeTeam( TEAM_CITIZEN, true )
        end
    end,
})

DarkRP.createCategory{
	name = "MethCook",
	categorises = "entities",
	startExpanded = true,
	color = Color(0, 125, 255, 255),
	canSee = function(ply) return true end,
	sortOrder = 103
}

DarkRP.createEntity("Tent Kit", {
	ent = "zmlab2_tent",
	model = "models/zerochain/props_methlab/zmlab2_tentkit.mdl",
	price = 1000,
	max = 1,
	cmd = "buytent",
	allowTools = true,
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Equipment Crate", {
	ent = "zmlab2_equipment",
	model = "models/zerochain/props_methlab/zmlab2_chest.mdl",
	price = 1000,
	max = 1,
	cmd = "buyequipment",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

// Below is all the other stuff that usally gets bought via the Equipment / Storage Entity

/*
DarkRP.createEntity("Palette", {
	ent = "zmlab2_item_palette",
	model = "models/zerochain/props_methlab/zmlab2_palette.mdl",
	price = 1000,
	max = 1,
	cmd = "buyPalette",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Automatic Icebreaker", {
	ent = "zmlab2_item_autobreaker",
	description = "Upgrades the packing table to automaticly cracks and packs ice.",
	model = "models/zerochain/props_methlab/zmlab2_autobreaker.mdl",
	price = 5000,
	max = 1,
	cmd = "buyautobreaker",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Acid", {
	ent = "zmlab2_item_acid",
	model = "models/zerochain/props_methlab/zmlab2_acid.mdl",
	price = 1000,
	max = 6,
	cmd = "buyAcid",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Aluminum", {
	ent = "zmlab2_item_aluminium",
	model = "models/zerochain/props_methlab/zmlab2_aluminium.mdl",
	price = 1000,
	max = 6,
	cmd = "buyAluminium",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Liquid Oxygen", {
	ent = "zmlab2_item_lox",
	model = "models/zerochain/props_methlab/zmlab2_lox.mdl",
	price = 1000,
	max = 6,
	cmd = "buylox",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Methylamine", {
	ent = "zmlab2_item_methylamine",
	model = "models/zerochain/props_methlab/zmlab2_methylamine.mdl",
	price = 1000,
	max = 6,
	cmd = "buyMethylamine",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Filler", {
	ent = "zmlab2_machine_filler",
	model = "models/zerochain/props_methlab/zmlab2_filler.mdl",
	price = 1000,
	max = 1,
	cmd = "buyfiller",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Filter", {
	ent = "zmlab2_machine_filter",
	model = "models/zerochain/props_methlab/zmlab2_filter.mdl",
	price = 1000,
	max = 1,
	cmd = "buyFilter",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Frezzer", {
	ent = "zmlab2_machine_frezzer",
	model = "models/zerochain/props_methlab/zmlab2_frezzer.mdl",
	price = 1000,
	max = 1,
	cmd = "buyFrezzer",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Furnace", {
	ent = "zmlab2_machine_furnace",
	model = "models/zerochain/props_methlab/zmlab2_furnance.mdl",
	price = 1000,
	max = 1,
	cmd = "buyFurnace",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Mixer", {
	ent = "zmlab2_machine_mixer",
	model = "models/zerochain/props_methlab/zmlab2_mixer.mdl",
	price = 1000,
	max = 1,
	cmd = "buyMixer",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Ventilation", {
	ent = "zmlab2_machine_ventilation",
	model = "models/zerochain/props_methlab/zmlab2_ventilation.mdl",
	price = 1000,
	max = 1,
	cmd = "buyVentilation",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Storage", {
	ent = "zmlab2_storage",
	model = "models/zerochain/props_methlab/zmlab2_storage.mdl",
	price = 1000,
	max = 1,
	cmd = "buyStorage",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})

DarkRP.createEntity("Packing Table", {
	ent = "zmlab2_table",
	model = "models/zerochain/props_methlab/zmlab2_table.mdl",
	price = 1000,
	max = 1,
	cmd = "buyTable",
	allowed = TEAM_ZMLAB2_COOK,
	category = "MethCook"
})
*/
