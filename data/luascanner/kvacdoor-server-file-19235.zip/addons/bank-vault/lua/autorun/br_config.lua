--I moved everything  to one file.
-- Drawing 3D2D things distance.
BR_DrawDistance = 256;

-- Bank vault name.
BR_BankName = "FluxCity Bank";
-- Bank vault name color.
BR_BankNameColor = Color(96, 158, 219);
--Money income per citizen.
BR_MoneyIncome = 250;
--Money stored on start.
BR_MoneyStored = 25000;
--Money income timer in seconds.
BR_IncomeTime = 30;
--Money expense timer in seconds.
BR_ExpenseTime = 180;
--Payment part from stored money in %.
BR_PaymentAmount = 0;
--Max payment part from stored money in %.
BR_MaxPaymentAmount = 0;
--Can mayor change payment amount?
BR_MayorPayment = false;
--Bank robbery music.
BR_RobberyMusic = "hl2_song20_submix0.mp3"
--Robber who starts robbery says 'Let's Go!'
BR_RobberyInitiator = true;
--Amount of cops required to rob the bank vault.
BR_CopsRequired = 3;
--Make wanted everyone who close to it.
BR_RobberyWanted = true;
--Combine styled report.
BR_RobberyReport = true;
--Choose money color.
BR_MoneyColor = Color(96, 158, 219, 200);
--Set up money name.
BR_MoneyName = "FluxCity Bank";
--Set up money name color.
BR_MoneyNameColor = Color(255, 255, 255, 200);
--Choose money case color.
BR_MoneyCaseColor = Color(96, 158, 219, 200);
--Players can't pocket money case. Don't set it to 'false'.
BR_MoneyCaseNoPocket = true;
--If true - money cases can be destroyed with damage
BR_MoneyCaseDamage = false;
--If true - money cases can be returned back to vault.
BR_MoneyCaseReturn = true;
--Set up money case name.
BR_MoneyCaseName = "FluxCity Bank";
--Set up money case name color.
BR_MoneyCaseNameColor = Color(96, 158, 219, 200);
--Should it be locked if stays near vault?
BR_MoneyCaseLock = false;
--Lock distance.
BR_MoneyCaseLockDistance = 2048;
--Open time while robbery on.
BR_OpenTime = 60;
--Cooldown time after robbery.
BR_CooldownTime = 300; -- 1 hour btw
--Minimal money rob amount.
BR_MinMoneyAmount = 1000;
--Maximum money rob amount.
BR_MaxMoneyAmount = 50000;
--Minimal money case rob amount.
BR_MinMoneyCaseAmount = 5500;
--Maximum money case rob amount.
BR_MaxMoneyCaseAmount = 6000;
--Set up name for robbery boss.
BR_RobberyBoss = "Ivan";
--Set up phrases for robbery boss.
BR_RobberyPhrases = {
"Nice, nice!",
"Well done!",
"Keep robbing!",
"Good job!",
"Hurry up man, hurry up!",
"Keep it going, comeone!",
"Almost done guys!",
"We're almost finished!"
}

-- 'vault_spawn <name>' will spawn bank vault at your target position, vault fron text will be faced to you.
-- 'vault_remove <name>' removes bank vault.